import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-add',
  templateUrl: './fund-add.component.html',
  styleUrls: ['./fund-add.component.scss']
})
export class FundAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
