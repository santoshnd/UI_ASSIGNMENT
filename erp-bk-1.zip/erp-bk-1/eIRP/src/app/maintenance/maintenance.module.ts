import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundAddComponent } from './fund-options/fund/fund-add/fund-add.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [FundAddComponent]
})
export class MaintenanceModule { }
