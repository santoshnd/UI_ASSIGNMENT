import { Component } from '@angular/core';

import { DomSanitizer } from '@angular/platform-browser';

// import { NGXLogger } from 'ngx-logger';

export class IState {
  name: string;
  abbrev: string;

}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'] // ,
  // providers: [NGXLogger]
})
export class AppComponent {
  title = 'Angular Test Application';
  selectedState: IState = {name: 'Colorado', abbrev: 'CO'};
  states: IState[] = [
    { name: 'Arizona', abbrev: 'AZ' },
    { name: 'California', abbrev: 'CA' },
    { name: 'Colorado', abbrev: 'CO' },
    { name: 'New York', abbrev: 'NY' },
    { name: 'Pennsylvania', abbrev: 'PA' }
  ];

  constructor(/* private logger: NGXLogger, */ dm: DomSanitizer) {

  }

  /* ******* DOM Sanitizer security POC ************************************
   // For example, a user/attacker-controlled value from a URL.
   htmlSnippet = 'Template <script>alert("0wned")</script> <b>Syntax</b>';
   *********************************************************************** */

  onSubmit() {
    // alert('Submit Clicked !');

    /*
      console.log('test log-1');
      this.logger.debug('Your log message goes here');
      console.log('test log-2');
      this.logger.debug('Multiple', 'Argument', 'support');
      console.log('test log-3');
      */

      alert(this.selectedState.name);
  }

}
