import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formb',
  templateUrl: './formb.component.html',
  styleUrls: ['./formb.component.scss']
})
export class FormbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
