import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FundAddComponent } from './maintenance/fund-options/fund/fund-add/fund-add.component';
import {FormbComponent } from './directives/formb/formb.component';


const routes: Routes = [
  { path: 'fund-add', component: FundAddComponent },
  { path: 'formb', component: FormbComponent },
  { path: '', redirectTo: '/fund-add', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})

export class AppRoutingModule {


}
