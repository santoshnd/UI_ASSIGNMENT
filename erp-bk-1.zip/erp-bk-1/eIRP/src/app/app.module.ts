import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

import {MaintenanceModule} from './maintenance/maintenance.module';
import { FormbComponent } from './directives/formb/formb.component';
import { AppRoutingModule } from './app-routing.module';


// import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

@NgModule({
  declarations: [
    AppComponent,
    FormbComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MaintenanceModule,
    AppRoutingModule // ,
    // LoggerModule.forRoot({serverLoggingUrl: '/api/logs', level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
