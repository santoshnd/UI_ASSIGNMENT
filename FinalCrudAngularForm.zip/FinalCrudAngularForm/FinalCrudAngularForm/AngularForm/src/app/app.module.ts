import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
 import {Route, RouterModule, Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormOneComponent } from './form-one/form-one.component';
import {FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {SelectRequiredValidatorDirective} from './Shared/select-required-validator.directive';
import {EmployeeService} from './employees/employee.service';
import {EmployeeListResolverService} from './employees/employee-list-resolver.service';
import { ListEmployeesComponent } from './employees/list-employees.component';
 import { DisplayEmployeeComponent } from './employees/display-employee.component';
 import { EmployeeFilterPipe } from './employees/employee-filter.pipe';
import { AddComponentComponent } from './New/add-component.component';
import {CreateEmployeeCanDeactivateGuardService} from './employees/create-employee-can-deactivate-guard.service';
import { EmployeeDetailsComponent } from './employees/employee-details.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { EmployeeDetailsGuardService } from './employees/employee-details-guard.service';

// import {NgbDatepicker} from '@ng-bootstrap/ng-bootstrap';
const appRoutes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'edit/:id', component: FormOneComponent, canDeactivate: [CreateEmployeeCanDeactivateGuardService]},
  {path: 'list', component: ListEmployeesComponent , resolve: {employeeList: EmployeeListResolverService}},
  {path: 'employees/:id', component: EmployeeDetailsComponent, canActivate: [EmployeeDetailsGuardService]},
  {path: 'notfound', component: PageNotFoundComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FormOneComponent,
    SelectRequiredValidatorDirective ,
   ListEmployeesComponent,
   DisplayEmployeeComponent,
     EmployeeFilterPipe,
     AddComponentComponent,
     EmployeeDetailsComponent,
     PageNotFoundComponent,
      ],
    imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
    AngularFontAwesomeModule,
    HttpClientModule,
    RouterModule.forRoot( appRoutes, {enableTracing: true}),
  ],
  providers: [EmployeeService, CreateEmployeeCanDeactivateGuardService, EmployeeListResolverService, EmployeeDetailsGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
