import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-component',
  templateUrl: './add-component.component.html',
  styleUrls: ['./add-component.component.css']
})
export class AddComponentComponent implements OnInit {
   isAddComponent = false;
  constructor() { }

  ngOnInit() {
  }

  // onClick() {
  //   this.isAddComponent = true;
  // }

}
