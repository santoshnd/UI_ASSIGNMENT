import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Department } from './models/department.model';
import { Employee } from './models/employee.model';
import { EmployeeService } from '../employees/employee.service';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-form-one',
  templateUrl: './form-one.component.html',
  styleUrls: ['./form-one.component.css']
})
export class FormOneComponent implements OnInit {
  @ViewChild('employeeForm') public createEmployeeForm: NgForm;
  previewPhoto = false;
  cardTitle: string;
  constructor(private _employeeService: EmployeeService, private _router: Router, private _route: ActivatedRoute) {

  }
  employee: Employee;

  // password:null,
  // confirmPassword:null


  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'IT' },
    { id: 3, name: 'HR' },
    { id: 4, name: 'Payroll' },
    { id: 5, name: 'Admin' },
  ];
  ngOnInit() {
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getEmployee(id);
   });
}

 private getEmployee(id: number) {
  if (id === 0) {
    this.employee = {
      id: null,
      name: null,
      gender: null,
      email: null,
      phoneNumber: null,
      dateOfBirth: null,
      department: 'select',
      isActive: null,
      photoPath: null,
      contactPreference: null,
    };
    this.cardTitle = 'Create Employee';
    this.createEmployeeForm.reset();
  } else {
    this.cardTitle = 'Edit Employee';
    this._employeeService.getEmployee(id).subscribe(
     (employee) => this.employee = employee,
     (err: any) => console.log(err)
    );
  }
}
saveEmployee(): void {
  if (this.employee.id == null) {
    this._employeeService.addEmployee(this.employee).subscribe(
      (data: Employee) => {
        console.log(data);
        this.createEmployeeForm.reset();
        this._router.navigate(['list']);
      },
      (error: any) => console.log(error)
    );
  } else {
    this._employeeService.updateEmployee(this.employee).subscribe(
      () => {
        this.createEmployeeForm.reset();
        this._router.navigate(['list']);
      },
      (error: any) => console.log(error)
    );
  }
 }


togglePhotoPreview() {
  this.previewPhoto = !this.previewPhoto;
}
  // onClick() {
  //   this._router.navigate(['list']);
  // }
  // onAddForm() {
  //   this._router.navigate(['addForm']);
  // }
}




