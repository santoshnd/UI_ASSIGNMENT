import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {FormOneComponent} from '../form-one/form-one.component';

@Injectable()

export class CreateEmployeeCanDeactivateGuardService implements CanDeactivate<FormOneComponent> {
    canDeactivate(component: FormOneComponent ):  boolean {
        if (component.createEmployeeForm.dirty) {
            return confirm('Are you sure you want to discard your changes?');
        }
        return true;
    }
}
