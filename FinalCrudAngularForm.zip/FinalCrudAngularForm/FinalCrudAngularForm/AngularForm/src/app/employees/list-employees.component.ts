import { Component, OnInit } from '@angular/core';
import {Employee} from '../form-one/models/employee.model';

import {Router, ActivatedRoute} from '@angular/router';
import { ResolveEmployeeList } from './resolved-employeelist.model';
@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  employees: Employee[];
  error: string;
  // filteredEmployees:Employee[];
   searchTerm: string;
  // get searchTerm():string{
  //   return this._searchTerm;
  // }
  // set searchTerm(value:string){
  //   this._searchTerm=value;
  //   this.filteredEmployees = this.filteredEmployees(value)
  // }

  // filteredEmployees(searchString:string){
  //   return this.employees.filter(employee => employee.name.toLowerCase().indexOf(searchString.toLowerCase()) !== -1);
  // }

  constructor( private _router: Router, private _route: ActivatedRoute) {
   const resolvedData: Employee[] | string = this.employees = this._route.snapshot.data['employeeList'];
 if (Array.isArray(resolvedData)) {
   this.employees = resolvedData;
 } else {
   this.error = resolvedData;
  }
  }

  ngOnInit() {
      // this._employeeService.getEmployees().subscribe(empList => this.employees = empList);
  }


  // onClick(employeeId:number){
  //   this._router.navigate(['/employees', employeeId]);
  // }

}
