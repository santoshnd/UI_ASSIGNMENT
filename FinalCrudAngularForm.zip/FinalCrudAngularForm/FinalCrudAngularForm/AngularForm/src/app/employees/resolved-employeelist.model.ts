import {Employee} from '../form-one/models/employee.model';

export class ResolveEmployeeList {
    constructor(public employeeList: Employee[], public error: any = null) {}
}
