import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { CsConfigService } from './app/shared/services/csConfig.service';
import { Config } from './app/shared/config/config.service';
import { LangService } from './app/shared/services/lang-service';

if (environment.production) {
  enableProdMode();
}
CsConfigService.loadInstance('assets/configs/csConfig.json').then(() => {
  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch(err => console.log(err));
});
Config.loadXML('assets/configs/appConfig.json').then(() => {
  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch(err => console.log(err));
});
LangService.loadInstanceLang('assets/json/mock/lang/customerCare_EN.json').then(() => {
  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch(err => console.log(err));
}); 
