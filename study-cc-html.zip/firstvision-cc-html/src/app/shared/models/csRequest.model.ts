class CSRequest {
    
}