
// export class CSMessage {
//     public static SERVICE: string = "SERVICE";
//     public static PAGE: string = "PAGE";
//     public static CLIENT: string = "CLIENT";
//     public static ASYNC: string = "ASYNC";
//     public static MANIFEST: string = "MANIFEST";
//     public static FUNCTIONS: string = "FUNCTIONS";
//     public static SESSIONMGR: string = "SESSIONMGR";
//     public static LOOKUP: string = "LOOKUP";
//     private _parameters: any[] = new Array();
//     private _header: any;
//     private _message: any;


//     constructor(pageName: string, processName: string, minimumData: string = "true") {
//         this._message.header.page.name = pageName;
//         this._message.header.process.processName = processName;
//         this._message.header.request.minimumData = minimumData;
//     }

//     setMessage(pageName, processName, minimumData) {
//     }

//     public addParameter(fieldName: string, value: Object, isModified: boolean = true, dfiRole: string = null): CSParameter {
//         var parameter: CSParameter = new CSParameter(fieldName, value != null ? value.toString() : "", isModified);
//         if (dfiRole)
//             parameter.dfiRole = dfiRole;

//         if (this.indexOf(fieldName) > -1)
//             this.replaceParameter(fieldName, value, isModified, dfiRole);
//         else
//             this._parameters.push(parameter);

//         return parameter;
//     }

//     public replaceParameter(fieldName: string, value: Object, isModified: boolean = true, dfiRole: string = null): CSParameter {
//         var parameter: CSParameter = new CSParameter(fieldName, value != null ? value.toString() : "", isModified);
//         if (dfiRole)
//             parameter.dfiRole = dfiRole;

//         var index: number = this.indexOf(fieldName);

//         if (index > -1)
//             this._parameters.splice(index, 1, parameter);

//         return parameter;
//     }

//     private indexOf(fieldName: string): number {
//         var i: number = -1;
//         var index: number = -1;
//         for each(var param: CSParameter in this._parameters)
//         {
//             i++;
//             if (param.fieldName == fieldName) {
//                 index = i;
//                 break;
//             }
//         }
//         return index;
//     }

//     public getParameters(): any[] {
//         return this._parameters;
//     }

//     public toString(): string {
//         var output: XML = this._message.copy();

//         for each(var parameter: CSParameter in this._parameters)
//         {
//             var field: XML =
//                 "<field>\r\n\t\t\t\t\t\t<fieldName>{parameter.fieldName}</fieldName>\r\n\t\t\t\t\t\t<value>{parameter.value}</value>\r\n\t\t\t\t\t\t<isModified>{parameter.isModified}</isModified>\r\n\t\t\t\t\t</field>";

//             if (parameter.dfiRole)
//                 field.@dfiRole = parameter.dfiRole;

//             output.msgOut[0].appendChild(field);
//         }

//         // the default "xmlns" is left out of initial message definition so that we can correctly
//         // traverse xml in flex, just before we send message to server we add to output for server.
//         output.@xmlns = "http://com/fd/firstvision/vx/input";

//         return output.toXMLString();
//     }

//     public get copySequence(): string { return this._message.header.page.@copySequence; }
//     public set copySequence(val: string) { this._message.header.page.@copySequence = val; }

//     public get numberOfRecords(): string { return this._message.header.page.@nbrOfRecords; }
//     public set numberOfRecords(val: string) { this._message.header.page.@nbrOfRecords = val; }

//     public get requestID(): string { return this._message.header.request.@id; }
//     public set requestID(val: string) { this._message.header.request.@id = val; }

//     public get requestType(): string { return this._message.header.request.@type; }
//     public set requestType(val: string) { this._message.header.request.@type = val; }

//     public get minimumData(): string { return this._message.header.request.@minimumData; }
//     public set minimumData(val: string) { this._message.header.request.@minimumData = val; }

//     public get pageAction(): string { return this._message.header.page.@action; }
//     public set pageAction(val: string) { this._message.header.page.@action = val; }

//     public get processName(): string { return this._message.header.process.@processName; }
//     public get pageName(): string { return this._message.header.page.@name; }
//     public set pageName(val: string) { this._message.header.page.@name = val; }
// }
