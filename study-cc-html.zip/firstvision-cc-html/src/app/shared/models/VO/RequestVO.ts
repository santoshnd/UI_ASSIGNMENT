import { Injectable } from "@angular/core";
@Injectable()

export class RequestVO {
        
        /* Required Properties */
        pageId:String;
        processId:String;
        action:String;

        /* Optional Properties */
        nbrOfRecords:String;
        removeMatchRec:String;
        restrictToInput:String;
        requestId:String;
        fieldList:any;
        toFieldList:any;
        requestType:String;
        pageName:String;
        processName:String;
        ruleSetId:String;
        sequence:String;	
        camFlag:Boolean;	
        camId:String;

        // crbpId:String;
        keyFieldList:any[];
        nextPage:String;
        nextProcess:String;
        copySequence:String;
        parentProcessId:String;
        fromKeyFieldList:any[];
}
