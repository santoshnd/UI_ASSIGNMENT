import { Injectable } from "@angular/core";
@Injectable()
export class FieldVO{

            fieldName:String;
		    preValue:String;
		    value:String;
		    type:String;
		    isModified:String;
		    isTBSControl:String;
		    role:String;
		    dfiRole:String;
        // chnage done for Portfolio Viewer- Search view
        
		    criteria:String;
		    connector:String;
}