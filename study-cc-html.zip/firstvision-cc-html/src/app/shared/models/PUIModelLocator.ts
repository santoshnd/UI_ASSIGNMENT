import { Injectable } from "@angular/core";
@Injectable()

export class PUIModelLocator {
    clientId: String = "aaa";
    operationalArea: String;
    component: String;
    clientName: String;
    CRID: String;
    CRBPID: String;
    bpName: String;
    directoryDetailCollection: any[];
    fromDirectoryDetailCollection: any[];
    dateFormat: String;
    timeFormat: String;
    dateTimeFormat: String;
    updateCRVO: any;
    entitlementKey: Boolean;
    entitlementKeyAPP: Boolean;
    isSystemBusinessProcess: Boolean;
    showBrowseResult: Boolean;
    getCRList: Function;

}
