export class CSState {

  // Make sure when using int or boolean values that the default value is 0 for int and false for boolean.
  // The reset method will set these default values when called.

  // public members
  static client = '';
  static tabs: any;
  static dateFormat: String = '';
  // public static currencyAttributes =CurrencyAttributes;
  static accountNumber = '';
  static cardNumber = '';
  static cardName = '';
  static accountOrgNumber = '';
  static customerNumber = '';
  static customerOrgNumber = '';
  static numberOfCards = '';
  static letterOrg = '';
  static ACSFlag = '';
  static accountLogo = '';
  static logoCardType = '';
  static blkCode1 = '';
  static blkCode2 = '';
  static blkCode1Priority = 0;
  static blkCode2Priority = 0;
  static blkCode1Label = '';
  static blkCode2Label = '';
  static ddPaymentType = '';
  static noteAdded = false;
  static planNumber = '';
  static recordNumber = '';
  static isLTSActive = true;

  // The following fields are Org calendar dates in Julian format
  static orgDateToday = 0;
  static orgDateLastProcessed = 0;
  static orgDateNextProcess = 0;

  static selectedTransaction: any;

  // The following variables should be updated only by the Demographics tab
  static demoCardOrg = '';
  static demoCardNbr = '';
  static demoCardSeq: String = '';
  // Following variables used for Quemanager ASM Repid and org
  static asmOrg: String = '';
  static asmRepId: String = '';
  // Following variable used for LoanOverview
  static recNbr: String = '';
  static planNbr: String = '';
  static accontDataList: any;
  static schemeDataList: any;
  // this flag is used for only Anualstatement message is shown or not shown. 
  static onFlag: Boolean = false;
  static accountSelectedIndex: Number = 0;
  static schemeSelectedIndex: Number = 0;
  static testNumver: String;
  static accountLMSOrgNumber: String;
  static transferAccount: String;
  static status: String;
  static cardTechnology: String;
  static productGraduationAllowed: String;
  static billingCyle: String;
  static orgDescription: String;
  static autoRefName: String;
  static autoRefPhoneNumber: String;
  static autoRefOrg: String;
  static autoRefRepId: String;
  static isAutoReferral: Boolean;
  static showDefaultTab: any = '';
}
