
export class CSDynamicParameters {
    //--------------------------------------------------------------------------
    // "private" constructor
    //--------------------------------------------------------------------------
    object = [];
    constructor() { }

    /**
     * adds a dynamic variable to the class and sets its value
     * 
     * @param name Name of variable being added to this class. 
     * @param value Value to be assigned to the new variable. 
     */
    public setVariable(name: string, value: any): void {
        this.object[name] = value;
    }

    /**
     * retrieves a dynamic variable and returns it as a string
     * 
     * @param name Name of variable being added to this class. 
     * 
     * @return String or  null if no variable. 
     */
    public getVariableAsString(name: any): string {
        let result: string = null;
        if (this.hasOwnProperty(name)) {
            result = this.object[name];
        }

        return result;
    }


    /**
     * retrieves a dynamic variable and returns it as a Number
     * 
     * @param name Name of variable being added to this class. 
     * 
     * @return Number or NaN. 
     */
    public getVariableAsNumber(name: string): number {
        let result: number = NaN;
        if (this.hasOwnProperty(name)) {
            result = Number(this.object[name]);
        }

        return result;
    }


    /**
     * retrieves a dynamic variable and returns it as a Boolean
     * 
     * @param name Name of variable being added to this class. 
     * 
     * @return true/false. false is the default even if field didn't exist. 
     */
    public getVariableAsBoolean(name: string): boolean {
        let result: boolean = false;
        if (this.object.hasOwnProperty(name)) {
            var test: string = this.object[name];
            switch (test.toLowerCase()) {
                case "true":
                    result = true;
                    break;
                case "false":
                    result = false;
                    break;

            }
        }

        return result;
    }

    /**
     * This function will take a result xml that has 1 group and a list of fields
     * and will load each field as a dynamic class variable based on the xml fileds
     * @id value. assigns the xml fields value to the variable.
     * 
     * @param parameters result xml from a BP call. 
     */
    public loadParameters(parameters: any): void {
        const nameList = parameters.group[0].field;
        nameList.forEach(element => {
            this.setVariable(element.id, element.value.text);
        });
    }

    /**
     * Overrided method for loadParameters
     * @param parameters result xml from a BP call. 
     */
    public loadFields(fieldList: any): void {
        let value: string = null;
        let name: string = null;
        fieldList.forEach(element => {
            name = element.id;
            value = element.value.text;
            this.setVariable(name, value);
        });
    }

    /**
     * removes a dynamic variable
     * 
     * @param name Name of variable being removed from this class. 
     *  
     */
    public removeVariable(name: string): void {
        const index = this.object.find(x => x === name);
        if (index) {
            this.object.splice(index, 1);
        }
    }


    public reset(): void {
        this.object = [];
    }

}
