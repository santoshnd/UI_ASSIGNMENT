export class CSState {
  // Make sure when using number or boolean values that the default value is 0 for number and false for boolean.
  // The reset method will set these default values when called.

  // public members
  isReversalAllowed: boolean = true;
  nextDate: string;
  nextDays: string;

  client: string = "";
  tabs: any;

  dateFormat: string = "MM/DD/YYYY";
  //currencyAttributes: = new CurrencyAttributes();

  accountNumber: string = "";
  storeNumber: string = "";//TODO
  accountOrgNumber: string = "";
  customerNumber: string = "";
  customerOrgNumber: string = "";
  numberOfCards: string = "";
  letterOrg: string = "";
  ACSFlag: string = "";
  accountLogo: string = "";
  logoCardType: string = "";
  blkCode1: string = "";
  blkCode2: string = "";
  blkCode1Priority: number = 0;
  blkCode2Priority: number = 0;
  blkCode1Label: string = "";
  blkCode2Label: string = "";

  //Orbitall Praduct Graduation and Transfer Variable
  pendingDueDateIndicator: number = 0;

  accountPCTORG: string = "";
  accountPCTLOGO: string = "";
  accountPCTID: string = "";
  accountCurrBalance: number = 0;
  islamicTransfer: number = 0;

  ddPaymentType: string = "";
  noteAdded: boolean = false;
  isLTSActive: boolean = true;
  isSkipPaymentAllowed: boolean = true;
  isOptInOptOutAllowed: boolean = true;
  isLMSActive: boolean = false;
  isMobileDeviceIdEnable: boolean = true;
  // The following fields are Org calendar dates in Julian format
  orgDateToday: number = 0;
  orgDateLastProcessed: number = 0;
  orgDateNextProcess: number = 0;
  orgDateNextProcessDte: Date = new Date();

  selectedTransaction: any;
  selectedQueueItem: any;

  // The following variables should be updated only by the Demographics tab
  demoCardOrg = '';
  demoCardNbr = '';
  demoCardSeq = '';
  // Following variable used for LoanOverview
  recNbr: string = "";
  planNbr: string = "";

  accontDataList: any;
  schemeDataList: any;
  // this flag is used for only Anualstatement message is shown or not shown. 
  isInformationFlag: boolean = false;

  accountSelectedIndex: Number = 0;
  schemeSelectedIndex: Number = 0;


  testNumver: string;
  accountLMSOrgNumber: string;
  transferAccount: string;
  status: string;
  cardTechnology: string;
  productGraduationAllowed: string;
  billingCyle: string;
  orgDescription: string;

  autoRefName: string;
  autoRefPhoneNumber: string;
  autoRefOrg: string;
  autoRefRepId: string;
  isAutoReferral: boolean;
  showDefaultTab: string = "";
  /**
   * Defined for store state if OMS is active or not
   */
  isOMSActive: boolean = false;
  isRelationshipActive: boolean = false;
}
