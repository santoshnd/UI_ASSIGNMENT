export class CurrencyAttributes {
  private _currencyCode = "USD";
  private _currencyNOD = 2;
  private _percentNOD = 7;
  private _peritemNOD = 5;
  private _currSymbol = "$";
  private _negativeFormat = 'A';
  private _digitGroupSymbol = ',';
  private _digitGroupNumber = 3;
  private _decimalSymbol = '.';
  private _rewardsPercentNOD = 7;
  private _rewardsCurrencyNOD = 2;
  private _rewardsPerItemNOD = 5;

  constructor(values: any) {
    this.loadAttributes(values);
  }

  public loadAttributes(values: any): void {
    if (values) {
      this._currencyCode = values.currencyCode[0];
      this._currencyNOD = values.currencyNOD[0];
      this._percentNOD = values.percentNOD[0];
      this._peritemNOD = values.peritemNOD[0];
      this._currSymbol = values.currSymbol[0];
      this._negativeFormat = values.negativeFormat[0];
      this._digitGroupSymbol = values.digitGroupSymbol[0];
      this._digitGroupNumber = values.digitGroupNumber[0];
      this._decimalSymbol = values.decimalSymbol[0];
    }
  }

  public get currencyCode(): string {
    return this._currencyCode;
  }

  public get currencyNOD(): number {
    return this._currencyNOD;
  }

  public get percentNOD(): number {
    return this._percentNOD - 2;
  }

  public get peritemNOD(): number {
    return this._peritemNOD;
  }

  public get currSymbol(): string {
    return this._currSymbol;
  }

  public get negativeFormat(): string {
    return this._negativeFormat;
  }

  public get digitGroupSymbol(): string {
    return this._digitGroupSymbol;
  }

  public get digitGroupNumber(): number {
    return this._digitGroupNumber;
  }

  public get decimalSymbol(): string {
    return this._decimalSymbol;
  }
  public get rewardsPercentNOD(): number {
    return this._rewardsPercentNOD;
  }
  public get rewardsCurrencyNOD(): number {
    return this._rewardsCurrencyNOD;
  }
  public get rewardsPerItemNOD(): number {
    return this._rewardsPerItemNOD;
  }
  public set rewardsPercentNOD(perNOD: number) {
    this._rewardsPercentNOD = perNOD;
  }
  public set rewardsCurrencyNOD(curNOD: number) {
    this._rewardsCurrencyNOD = curNOD;
  }
  public set rewardsPerItemNOD(perItemNOD: number) {
    this._rewardsPerItemNOD = perItemNOD;
  }
}
