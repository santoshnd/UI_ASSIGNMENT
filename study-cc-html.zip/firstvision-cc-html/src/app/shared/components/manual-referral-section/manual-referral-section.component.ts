import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-manual-referral-section',
  templateUrl: './manual-referral-section.component.html',
  styleUrls: ['./manual-referral-section.component.scss']
})
export class ManualReferralSectionComponent implements OnInit {

referCheck = false;
errorDateMsg: any;
errorRepMsg: string;
repTextInput: any;
selectedDate: any;
dateFormat: string;
showRepError: Boolean = false;
showDateError: Boolean = false;
// preferences:Preferences;
showReferralItems: Boolean = false;
showReferralItemsCheck: Boolean = true;
showReferralDate: Boolean;
// translationUtil: TranslationUtil ;
rangeStartDate: Date = new Date();
startDte: Date;
disableRange: any;
@Output() referralFlag = new EventEmitter<any>();

constructor(private datePipe: DatePipe) { }

  ngOnInit() {
    this.dateFormat = 'MMddyyyy';
   // startDte= FormatterUtil.formatJulianToGregorianDate(CSState.orgDateNextProcess.toString(), CSState.dateFormat);
     this.startDte = new Date(2018, 3, 10);
  }
  validateDate(date) {
    if (date) {
        this.selectedDate = this.datePipe.transform(new Date() , this.dateFormat );
    } else {
    return '0';
    }

    if (this.selectedDate === 0) { // If selectedDate is "0" then skip further validation.
          return true;
    }  // assume success
    const julianDate = this.datePipe.transform(this.startDte , this.dateFormat );
    if (this.selectedDate < julianDate) {
    this.showReviewDateError('Selected date is not within valid range.');
    return false; // failed
    }
    return true; // success
  }
  getSelectedRepID(): String {
    return String(this.repTextInput).substr(3, 6);
  }
  getSelectedRepORG(): String {
    return String(this.repTextInput).substr(0, 3);
  }
  validateRepSelection(): Boolean {
    this.resetRepError();
    const isNumric: Boolean = this.validateNumericChar(String(this.repTextInput).substr(0, 3));
    const isAlphaNumric: Boolean = this.validateAlphaNumericChar(String(this.repTextInput).substr(3, 6));
    const isSixChar: Boolean = this.invalidateEntry();
    if (isNumric && isAlphaNumric && isSixChar) {
    return true;
    }
    return false;
  }
  validateNumericChar(refID: string): Boolean {
    const validateWholeNumber: RegExp = /^[0-9]*$/;
    if (!(validateWholeNumber.test(refID))) {
    this.showReferralRepError('INVALID ENTRY FOR REPRESENTATIVE ID');
    return false;
    } else {
      return true;
    }
  }
  validateAlphaNumericChar(refID: string): Boolean {
    const validateAlphaNumeric: RegExp = /^[a-zA-Z0-9]*$/;
    if (validateAlphaNumeric.test(refID)) {
    return true;
    } else {
      this.showReferralRepError('INVALID ENTRY FOR REPRESENTATIVE ID');
      return false;
    }
  }
  invalidateEntry(): Boolean {
      const numChar: any = this.repTextInput;
      if (numChar.length < 6 ) {
      this.showReferralRepError('INVALID ENTRY FOR REPRESENTATIVE ID');
      return false;
      } else {
        return true;
      }
  }
  showReferralRepError(msg: string): void {
      this.showRepError = true;
      document.getElementById('repTextInput').style.borderColor = '#B60000';
      this.errorRepMsg = msg; // translationUtil.translateText(msg);
  }
  resetRepError(): void {
  this.showRepError = false;
  document.getElementById('repTextInput').style.borderColor = '#AAB3B3';
  this.errorRepMsg = '';
  }
  showReviewDateError(msg) {
  // highlight and show error icon on review date error condition
     this.showDateError = true;
     this.errorDateMsg = msg; // translationUtil.translateText(msg);
     document.getElementById('errorDate').style.borderColor = '#B60000';
  }
  resetReviewDateError(): void {
    this.showDateError = false;
    document.getElementById('errorDate').style.borderColor = '#AAB3B3';
    this.errorDateMsg = '';
  }
  upperCase(): void {
    this.repTextInput = this.repTextInput.toString().toUpperCase();
  }
  updateCheckedOptions(referralcheck) {
    this.referCheck = referralcheck.target.checked;
    if (this.referCheck === true) {
      this.showReferralDate = true;
      this.referralFlag.emit(this.referCheck);
    } else {
      this.showReferralDate = false ;
      this.referralFlag.emit(this.referCheck);
    }
    if (!this.referCheck) {
    this.resetRepError();
    this.resetReviewDateError();
    this.repTextInput = '';
    // 	this.referralReviewDate = "";
    return;
    }
  }
}
