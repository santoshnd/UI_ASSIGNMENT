import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualReferralSectionComponent } from './manual-referral-section.component';

describe('ManualReferralSectionComponent', () => {
  let component: ManualReferralSectionComponent;
  let fixture: ComponentFixture<ManualReferralSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualReferralSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualReferralSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
