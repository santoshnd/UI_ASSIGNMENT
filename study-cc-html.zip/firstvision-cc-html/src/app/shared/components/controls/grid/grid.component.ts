import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { RowArgs } from '@progress/kendo-angular-grid';
import { DataService } from '../../../services/data.service';
import { ServerFactory } from '../../../services/serverFactor.service';
import { Subscription } from 'rxjs';
import { EventServiceService } from '../../../services/event-service.service';

@Component({
  selector: 'app-grid',
  template: `
  <kendo-grid [data]="view"   (cellClick)="onClick($event)">
               <kendo-grid-column
                *ngFor="let column of columns"
                [field]="column.field"
                [title]="column.title"
                [hidden]="column.hidden"
                [kendoGridSelectBy]="mySelectionKey"
                [selectedKeys]="mySelection"
               >
            </kendo-grid-column>
        </kendo-grid>
  `,
  styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit {
  eventValue: any;
  dataItem: any;
  @Input() layoutNode: any;
  @Input() layoutIndex: number[];
  @Input() dataIndex: number[];
  @Input() component: string;
  @Input() widgetTitle: string;
  @Input() processName: string;
  @Input() pageName: string;
  @Input() configurations: any;
  @Input() gridData: any;
  groups:any;
  columns : any;
  view : any;
  mySelection: string[] = [];
  subscription: Subscription;
  @Output() gridRowClick : EventEmitter<boolean> = new EventEmitter<boolean>();
  constructor( private dataService: DataService , private eventservice:EventServiceService ) { }

  ngOnInit() {
  }
  ngOnChanges(changes) {
    
    
    this.bindGrid( this.gridData); 
   }
 onClick(event){
   
   this.dataItem = event.dataItem;
  this.gridRowClick.emit(this.dataItem);
 }
  bindGrid(data){
    this.columns=data.vxRoot.group[0].groups[0].columns;
    this.view = data.vxRoot.group[0].groups[0].data;
  }
 
}


