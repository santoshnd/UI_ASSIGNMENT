import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';
@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.scss']
})
export class ImageComponent extends BaseComponent {

}
