import { Component, OnInit, Output } from '@angular/core';
import { BaseComponent } from '../base-component';
import { EventEmitter } from '@angular/core';

import { Subscription } from 'rxjs/Subscription';
import { EventServiceService } from '../../../services/event-service.service';

@Component({
  selector: 'app-button',
  template: `
  <button type="button" id={{context?.id}} (click)="getEvent($event)" >{{context?.value}}</button>
  `,
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent extends BaseComponent {

  constructor(private eventservice: EventServiceService) {
    super();
  }
  getEvent(event) {
    this.eventservice.changeEvent({ type: 'button', eventType: 'headerClick', data: event });
  }

}
