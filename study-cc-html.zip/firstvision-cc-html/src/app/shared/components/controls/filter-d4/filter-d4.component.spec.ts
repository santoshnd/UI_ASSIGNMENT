import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterD4Component } from './filter-d4.component';

describe('FilterD4Component', () => {
  let component: FilterD4Component;
  let fixture: ComponentFixture<FilterD4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilterD4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterD4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
