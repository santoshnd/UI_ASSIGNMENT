import { Component, OnInit } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-filter-d4',
  templateUrl: './filter-d4.component.html',
  styleUrls: ['./filter-d4.component.scss']
})
export class FilterD4Component extends BaseComponent implements OnInit {
  header: { [k: string]: any } = {};
  fieldValues: { 'fieldName': string; 'isModified': string; 'value': string; }[];
  url = '';
  filterOptions = [];
  constructor(private accountService: AccountFolderService) {
    super();
  }

  ngOnInit() {
    this.setRequestValues();
    this.getFilterD4Data();
  }

  setRequestValues() {
    this.url = 'assets/json/mock/creditCardPlanListing.json';
    this.fieldValues = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.hasColon = this.context.hasColon;
    this.setRequestHeader(this.context.link);
  }

  getFilterD4Data() {
    this.accountService.getServiceData(this.url, this.fieldValues, this.header);
    this.accountService.rewardData$.subscribe(data => { this.filterOptions = data.group.rows.row; });
  }

  setRequestHeader(params: any): void {
    this.header['name'] = params.pageName;
    this.header['page_action'] = params.action;
    this.header['process_processName'] = params.processName;
    this.header['request_id'] = params.page_id;
    this.header['request_minimumData'] = 'false';
    this.header['request_type'] = 'PAGE';
  }

}
