import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listbox',
  template: `

  `,
  styleUrls: ['./listbox.component.scss']
})
export class ListboxComponent implements OnInit {
  name: string = 'Ringo';
  names: string[] = ["John", "Paul", "George", "Ringo"]

  ngOnInit() {
  }


  constructor() {

  }
}
