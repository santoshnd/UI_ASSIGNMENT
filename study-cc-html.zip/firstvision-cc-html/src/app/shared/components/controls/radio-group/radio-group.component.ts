import { Component, OnInit } from "@angular/core";

@Component({
  selector: "radio-group",
  template: `
    <label class="">{{context.label}}</label>

    <div *ngFor="let radio of context.valueList.item">
    <div class="k-form-field">
        <input type="radio" id="{{context.id+radio.code}}" class="k-radio"
        required="context.reqIndicator?true:" [checked]="radio.code == context.value" [value]="radio.code"
        (change)="onSelectionChange($event)"
        name="radioGroup"/>
        <label class="k-radio-label" for="{{context.id+radio.code}}">{{radio.text}}</label>
    </div>
    </div>
    <br>
    `
})
export class RadioGroupComponent implements OnInit {
  context: any;
  ngOnInit() {
   this.context= {
      text:'RadioButtonGroup',
      id: "AMRT-ACCT-STMT-SUPR-ZERO",
      help: "account_processing/account_control/amrt-acct-stmt-supr-zero",
      control: "",
      type: "RadioButtonGroup",
      reqIndicator: "false",
      maxChars: "1",
      value: "0",
      valueDesc: "Option not used",
      desc:
        "Indicates whether statements are suppressed for accounts with a closing balance of zero and that have had only payments or memo transactions posted during this statement period.",
      valueList: {
        item: [
          {
            code: "0",
            text: "Option not used"
          },
          {
            code: "1",
            text: "Memo only & 0 balance, no statement"
          },
          {
            code: "2",
            text: "Pmt and/or memo & 0 balance, no statement"
          },
          {
            code: "3",
            text: "Pmt and/or memo & bal eq memb fee only; no stmt"
          }
        ]
      },
      label: "Suppress Zero Balance",
      defaultValue: "0"
    }
  }

  onSelectionChange(event) {
    //event.target.value;
  }
}
