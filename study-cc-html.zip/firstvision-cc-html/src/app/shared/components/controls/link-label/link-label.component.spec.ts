import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkLabelComponent } from './link-label.component';

describe('LinkLabelComponent', () => {
  let component: LinkLabelComponent;
  let fixture: ComponentFixture<LinkLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkLabelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
