import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-checkbox",
  template: `<div class="row">
  <div class="{{labelClass}}">
      <span>{{context.label}}</span><span *ngIf="colon">:</span>
  </div>
    <div class="{{valueClass}}">
    <div *ngFor="let checkbox of context.valueList.item">
    <div class="k-form-field">
        <input type="checkbox" id="{{context.id+checkbox.code}}"
        (change)="onSelectionChange($event)"
        [value]="checkbox.code"
        [checked]="checkbox.code == context.value" />
        <label class="" for="{{context.id+checkbox.code}}">{{checkbox.text}}</label>
    </div>
    </div>
  </div>
</div>`
})
export class CheckBoxComponent implements OnInit {
  valueClass: any;
  labelClass: any;
  htmlClass: {};
  conditions: any;
  context:any;
  classObj:any;
  colon: any;

  ngOnInit() {
    this.context={
      text:'checkBox',
      id: this.context.id,
      control: "",
      type: "checkBox",
      reqIndicator: this.context.reqIndicator,
      maxChars: this.context.maxChars,
      value: this.context.value,
      valueDesc: this.context.valueDesc,
      valueList: {
        item: [
          {
            code: "1",
            text: ""
          }
        ]
      },
      label: this.context.label,
      defaultValue: this.context.defaultValue
    }

    if (this.conditions) {
      this.colon = this.conditions.colon || {};
    }
    
    this.classObj = this.htmlClass || {};
    
    if (this.classObj) {
      if (this.classObj.labelClass) {
        this.labelClass = this.classObj.labelClass;
      } else {
        this.labelClass = 'col-sm-6';
      }
    }
    if (this.classObj) {
      if (this.classObj.valueClass) {
        this.valueClass = this.classObj.valueClass;
      } else {
        this.valueClass = 'col-sm-6';
      }
    }
  }

  onSelectionChange(event) {}
}
