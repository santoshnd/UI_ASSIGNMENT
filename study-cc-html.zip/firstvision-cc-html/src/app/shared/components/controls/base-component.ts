export abstract class BaseComponent {
    context: any;
    layout: any;
    htmlClass: any;
    conditions: any;
    hasColon: boolean;
}
