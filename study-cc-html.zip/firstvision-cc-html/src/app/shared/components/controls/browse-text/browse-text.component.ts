import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';

@Component({

  selector: 'app-browse-text',
  template: `
  <div>
    <label for="{{context?.id}}">{{context?.label}}</label>
     <input name="file" type="file"  class="browseInput"/>
    
  </div>
  `,
  styleUrls: ['./browse-text.component.scss']
})
export class BrowseTextComponent extends BaseComponent implements OnInit {

  constructor() {super();
 }

  ngOnInit() {
  }
  // tslint:disable-next-line:member-ordering
 
}
