
import { Component, Input, OnInit } from '@angular/core';
import { AlertService } from '../../../services/alert.service';

@Component({
  selector: 'app-alerts',
  template: `
  <div *ngIf="message" class="modal" tabindex="-1" role="dialog" style="display:block!important">
  <div class="modal-dialog" role="document">
  <div class="modal-content">

<div *ngIf="message?.type == 'confirm'"  class="modal-body">
      <div class="row">
          <div class="col-md-12">
              <h3 class="text-center">{{message.text}}</h3>
          </div>
      </div>
      <div class="row">
          <div class="col-md-12">
              <p class="text-center">
                  <a (click)="message.noFn()">
                      <button class="btn btn-pm">No</button>
                  </a>
                  <a (click)="message.yesFn()">
                      <button  class="btn btn-sc" >Yes</button>
                  </a>
              </p>
          </div>
          </div></div></div>
      </div>
   </div>
  `,
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent implements OnInit {
  message: any;
  constructor(
    private alertService: AlertService
 ) { }
 
 ngOnInit() {
  //this function waits for a message from alert service, it gets 
  //triggered when we call this from any other component
  this.alertService.getMessage().subscribe(message => {
      this.message = message;
  });
}

  
}

