import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-password',
  template: `
  <div class="form-group">
    <label for="{{context?.id}}">{{context?.label}}</label>
    <input type="{{context?.type}}" class="form-control" 
    id="{{context?.id}}" aria-describedby="emailHelp" placeholder="password" value="{{context?.value}}" maxLength="{{context?.maxChars}}"/>
  </div>
  `,
  styleUrls: ['./password.component.scss']
})
export class PasswordComponent extends BaseComponent {


}
