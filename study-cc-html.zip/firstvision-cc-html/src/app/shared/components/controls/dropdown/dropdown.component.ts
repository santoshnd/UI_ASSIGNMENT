/*
* 
 * File :text-box.component.ts
* $Author: pratik_thakare  Created on :
 * @Desc :  Generic Dropdown
*/
import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
// import { Broadcaster } from '../../../services/event.broadcaster';
import { DataService } from '../../../services/data.service';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-dropdown',
  template: `<div class='row'>
    <div class="{{labelClass}}"><label>{{label}}</label></div>
  <div class="{{valueClass}}">
    <select>
    <!--(change)="onSelectionChnage($event)" -->
      <option *ngFor="let item of options" [value]="item.text">{{item.text}}</option>
    </select>
  </div>
</div>`,
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent extends BaseComponent implements OnInit {
  labelClass: any;
  label: any;
  // @Output() onChangeEmitter: EventEmitter<any> = new EventEmitter<any>();
  // private broadcaster: Broadcaster, private dataservice: DataService, private cd: ChangeDetectorRef
  constructor() { super(); }
  colon: any;
  valueClass: string;
  classObj: any;
  options: any;

  ngOnInit() {
    console.log(this.context);
    this.options = this.context.valueList.item;
    this.label = this.context.label || {};
    if (!Array.isArray(this.options)) {
      this.options = [this.options];
    }
    this.classObj = this.htmlClass || {};
    
    if (this.classObj) {
      if (this.classObj.labelClass) {
        this.labelClass = this.classObj.labelClass;
      } else {
        this.labelClass = 'col-sm-6';
      }
    }
    if (this.classObj) {
      if (this.classObj.valueClass) {
        this.valueClass = this.classObj.valueClass;
      } else {
        this.valueClass = 'col-sm-6';
      }
    }
    //   this.dataservice.getClientDropdownJson().subscribe(data => {
    //    this.parseData(data);
    //    this.cd.detectChanges();
    //   },
    //     err => console.error(err));
  }
  // onSelectionChnage(event): void {
  //   this.broadcaster.broadcast('dropdown-change', event.name);
  //  };
}
