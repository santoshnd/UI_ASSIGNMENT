
/*
* 
 * File :text-box.component.ts
* $Author: pratik_thakare  Created on : 27-Feb-2018
 * @Desc :  Generic Input Box
* (C) Copyright 2018 First Data Corporation and/or Its Subsidiary Companies. All Rights Reserved.
*/
import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-text-box',
  template: `
  <div [class]="options?.htmlOuterClass || 'row'" class="pt-1">
     <div [class]="htmlClass? htmlClass.labelClass: 'col-sm-6'">
      <label *ngIf="options?.label"
        [attr.for]="'control' + options?.id"
        [class]="options?.labelHtmlClass || ''"
        [style.display]="options?.nolabel ? 'none' : ''"
        [innerHTML]="this.options.label"></label><span *ngIf="context.hasColon">:</span>
      </div>
      <div [class]="htmlClass? htmlClass.valueClass: 'col-sm-6'">
      <input [attr.maxlength]="options?.maxChars"
        [attr.minlength]="options?.minChars"
        [attr.pattern]="options?.pattern"
        [attr.placeholder]="options?.placeholder"
        [attr.required]="options?.reqIndicator"
        [id]="'control' + options?.id"
        [name]="options?.controlName"
        [type]="options?.controlNewType"
        [value]="this.options.value"
        (input)="updateValue($event)">
        </div>
    </div>
  `,
  styleUrls: ['./text-box.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class TextBoxComponent extends BaseComponent implements OnInit {
  options: any;
  constructor() {
    super();
  }
  updateValue(event) {
    // this.jsf.updateValue(this, event.target.value);
  }

  ngOnInit() {
    this.options = this.context || {};
    this.options.label = this.context.label.text ? this.context.label.text : this.context.label;
    if (!this.options.value.nil) {
      this.options.value = this.context.value.text ? this.context.value.text : this.context.value;
    } else { this.options.value = null; }
    if (this.options.control = 'TextInputField') {
      this.options.controlNewType = 'text';
    }
  }
}
// <div class="form-group">
// <label for="{{context?.id}}">{{context?.label}}</label>
// <input type="{{context?.type}}" required="{{context?.reqIndicator}}" class="form-control" id="{{context?.id}}" aria-describedby="emailHelp" placeholder="Enter email" value="{{context?.value}}" maxLength="{{context?.maxChars}}" minLength="{{context?.minChars}}">
// <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
// </div>