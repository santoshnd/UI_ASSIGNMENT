import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';
import { LabelComponent } from '../label/label.component';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'app-date-range',
  template: `
    <div>
    <label for="{{context?.id}}">{{context?.label}}</label>
    <kendo-datepicker [value]="context?.value" [max]="max"
    [(ngModel)]="currentdate" (valueChange)="getValue($event)"></kendo-datepicker>

    <label for="{{context?.id}}">{{context?.label}}</label>
    <kendo-datepicker [value]="context?.value"  [min]="min"></kendo-datepicker>
    </div>
  `,
  styleUrls: ['./date-range.component.scss']
})
export class DateRangeComponent extends BaseComponent {
  public max: Date = new Date();
  min: any;
  currentdate: any;

  getValue(currentdate) {
    this.min = currentdate;

  }

  public set value(currentdate: string) {
    this.currentdate = currentdate;
  }

}
