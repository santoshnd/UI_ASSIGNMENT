import { Component, OnInit, Input } from '@angular/core';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss']
})

export class DateComponent extends BaseComponent implements OnInit {
  valueClass: string;
  classObj: any;
  labelClass: any;
  options: any;

  @Input() layoutNode: any;
  ngOnInit() {
    this.options = this.context || {};
    this.classObj = this.htmlClass || {};
    if (this.options.label) {
      if (this.options.label.text) {
        this.options.label = this.options.label.text;
      } else {
        this.options.label = this.options.label;
      }
    }
    if (this.options.value) {
      if (this.options.value.text) {
        this.options.value = this.options.value.text;
      } else {
        this.options.value = this.options.value;
      }
    }
    if (this.classObj) {
      if (this.classObj.labelClass) {
        this.labelClass = this.classObj.labelClass;
      } else {
        this.labelClass = 'col-sm-6';
      }
    }
    if (this.classObj) {
      if (this.classObj.valueClass) {
        this.valueClass = this.classObj.valueClass;
      } else {
        this.valueClass = 'col-sm-6';
      }
    }
  }
}
