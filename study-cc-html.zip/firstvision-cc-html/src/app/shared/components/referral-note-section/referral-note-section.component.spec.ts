import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferralNoteSectionComponent } from './referral-note-section.component';

describe('ReferralNoteSectionComponent', () => {
  let component: ReferralNoteSectionComponent;
  let fixture: ComponentFixture<ReferralNoteSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferralNoteSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferralNoteSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
