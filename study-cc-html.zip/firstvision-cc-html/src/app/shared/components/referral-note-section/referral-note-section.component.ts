import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-referral-note-section',
  templateUrl: './referral-note-section.component.html',
  styleUrls: ['./referral-note-section.component.scss']
})
export class ReferralNoteSectionComponent implements OnInit {

  referCheck: any;
  noteText = '';
  showReferralDate: boolean;
  CaseNumber: any;
  accountNumber: any = '0003925000000011524'; // account number will be fatched from model CSState
  public PriorityItems: Array<string> = ['None', 'Low', 'Medium', 'High'];
  @Input() referSection = true;
  /*  @Input() referSection: boolean; */
  @Output() noteTextflag = new EventEmitter<any>();
  @Output() referralFlag = new EventEmitter<any>();
  constructor(private datePipe: DatePipe) { }

  ngOnInit() {
    this.myFunction();
    this.noteTextflag.emit(this.noteText);
  }
  /* tabChanged() {
          this.CaseNumber = this.caseNumberGenerator(this.accountNumber);
  } */
  myFunction() {
    this.CaseNumber = this.caseNumberGenerator(this.accountNumber);
  }
  caseNumberGenerator(accountNumber: String) {
const caseNumberPart01: any = accountNumber.substring(accountNumber.length - 4, accountNumber.length);
const caseNumberPart02: any = this.getCurrentTime();
const caseNumberPart03: any = this.getCurrentDay();
    return caseNumberPart01 + caseNumberPart02 + caseNumberPart03;
  }
  getCurrentTime() {
const currentDateTime: Date = new Date();
const dateTime: any = this.datePipe.transform(currentDateTime , 'yyyyMMddHHmmss' );
    return dateTime.substring(dateTime.length - 6, dateTime.length);
  }
  getCurrentDay(): any {
    const currentDate: Date = new Date();
    return currentDate.getDay().toString();
  }
  updateNoteSection() {
    this.noteText = '';
    if (this.CaseNumber !== '') {
      this.noteText = 'CASE NUMBER' + ' :' + this.CaseNumber + ' ' + this.noteText;
      this.noteTextflag.emit(this.noteText);
    }
  }
referralFlagCheck($event) {
    this.referCheck = $event;
    this.referralFlag.emit(this.referCheck);
  }
}
