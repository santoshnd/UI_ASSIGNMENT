import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-note-section',
  templateUrl: './note-section.component.html',
  styleUrls: ['./note-section.component.scss']
})
export class NoteSectionComponent implements OnInit {
  noteText = 'testdata';
  @Input() showCaseSection = true;
  constructor() { }

  ngOnInit() {
  }

}
