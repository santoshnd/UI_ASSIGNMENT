import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterSectionComponent } from './letter-section.component';

describe('LetterSectionComponent', () => {
  let component: LetterSectionComponent;
  let fixture: ComponentFixture<LetterSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LetterSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
