import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-letter-section',
  templateUrl: './letter-section.component.html',
  styleUrls: ['./letter-section.component.scss']
})
export class LetterSectionComponent implements OnInit {

  toolTipFlag = false;
  constructor() { }

  ngOnInit() {
  }
  letterOptiondialog() {
    this.toolTipFlag = !this.toolTipFlag;
  }
}
