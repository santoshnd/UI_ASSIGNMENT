import { Component, OnInit, Input, ViewContainerRef, ViewChild, ElementRef, OnChanges, SimpleChanges, ChangeDetectorRef, VERSION } from '@angular/core';
import { JsonSchemaFormService } from 'angular2-json-schema-form';
import { AbstractControl, NgForm } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { EventServiceService } from '../../services/event-service.service';
import { Subscription } from 'rxjs/Subscription';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  errorString: any;
  name: string;
  eventValue: any;
  bpSheetData: any;
  myLayout: any;
  @Input() processName: string;
  @Input() configurations: any;
  @Input() layoutNode: any;
  @Input() layoutIndex: number[];
  @Input() widgetJSON: string = "header";


  @ViewChild('appendContext') context: ElementRef;
  constructor(
    private jsf: JsonSchemaFormService,
    private dataService: DataService,
    private cd: ChangeDetectorRef,
    private eventservice: EventServiceService,
    private alertService: AlertService

  ) { }
  subscription: Subscription;

  ngOnInit() {
   
   this.jsf.initializeControl(this);
    this.getBPJSON();
    this.subscribeEventCall();
    //  this.alertConfig(this.errorString);


  }
  ngOnDestroy() {
    // prevent memory leak when component is destroyed
    this.subscription.unsubscribe();
  }

  alertConfig(err) {
   
    
    this.name = `Angular! ${VERSION.full}`;
    let that = this;
    {
        that.alertService.confirmThis(err, function () {
          
      
        //ACTION: Do this If user says YES
        that.name = "ok is clicked";
      }, function () {
        //ACTION: Do this if user says NO
        that.name = "Cancel is clicked";
      })

    }
  }

  subscribeEventCall() {
    this.subscription = this.eventservice.eventRecord$.subscribe((data: any) => {
      this.eventValue = data;
      
      if (this.eventValue.eventType) {
        this[this.eventValue.eventType](this.eventValue);
      }

    }
    );
  }

  headerClick(params: any) {
    
 
    this.dataService.getErrorJson().subscribe((data: any) => {
      if (data !== 'undefined' || data != '' || data != null) {
        this.parseData(data);
        this.cd.detectChanges();
      }   
    },
  error => console.log(error)
);
  }

  parseData(data){
   
      this.errorString = data.vxRoot.header.status.error.message.content;
     
      this.alertConfig(this.errorString);

    }
  

  getLayoutJSON() {
    this.dataService.getTreeJson(this.widgetJSON).subscribe(data => {
      this.renderLayoutOnUI(data);
    },
      err => console.error(err));
  }

  getBPJSON() {
    this.dataService.getBPSheetByProcessName(this.layoutNode.options.processName).subscribe(data => {
      this.bpSheetData = data;
      this.getLayoutJSON();
    },
      err => console.error(err));
  }

  generateLayoutWithBPObject() {
    var index = 0;
    for (let item of this.bpSheetData) {
      this.myLayout[index].bpSheetObj = item;
      index++;
    }
  }
  checkforGroup(bpData) {
    if (Array.isArray(bpData.group) == true) {
      return true;
    } else {
      return false;
    }
  }

  renderLayoutOnUI(configLayoutObj) {
    this.myLayout = configLayoutObj;
    this.generateLayoutWithBPObject();
    this.cd.detectChanges();
 
  }
  onSubmit(f: NgForm) {
   
  }
}