import { Component, OnInit, Input, Output, ChangeDetectorRef } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { templateJitUrl } from '@angular/compiler';

@Component({
  selector: 'app-window-manager',
  templateUrl: 'window-manager.component.html',
  styleUrls: ['window-manager.component.scss']
})
export class WindowManagerComponent implements OnInit {

  buttonType: any;
  window_title: any;
  public windowTop: number = 100;
  public windowLeft: number = 50;
  CompanyName: any;
  selectedRow: any;
  processView: any = false;
  processDetails: any = true;
  //first screen variable
  popupflag: boolean;
  selected: any;
  AddSection: any;
  CopySection: any;
  UpdateSection: any;
  InquirySection: any;
  @Input() gridData: any;
  @Input() opened: boolean;
  @Input() actionData_: any;
  @Input() pageTypeValue: any;
  @Output() messageEvent = new EventEmitter<boolean>();
  constructor(private cd: ChangeDetectorRef) {
    //this.gridData= [] 
  }

  public openClose(isOpened: boolean) {
    this.opened = false;
    this.processView = this.opened;
    this.processDetails = !this.opened;
    this.messageEvent.emit(false);
  }
  onfunctionButtonClick() {
    this.processView = !this.processView;
  }
  ngOnChanges(changes) {
    if (!this.buttonType) {
      return;
    }
    this.setPageType(changes.pageTypeValue.currentValue);

  }
  setPageType(pagetype) {
    this.buttonType = pagetype.type;
    switch (pagetype.type) {
      case "ADD":
        this.AddSection = true;
        this.CopySection = false;
        this.UpdateSection = false;
        this.InquirySection = false;
        this.window_title = pagetype.name;
        break;
      case "COPY":
        this.AddSection = false;
        this.CopySection = true;
        this.UpdateSection = false;
        this.InquirySection = false;
        this.window_title = pagetype.name;
        break;
      case "UPDATE":
        this.AddSection = false;
        this.CopySection = false;
        this.UpdateSection = true;
        this.InquirySection = false;
        this.window_title = pagetype.name;
        break;
      case "INQUIRY":
        this.AddSection = false;
        this.CopySection = false;
        this.UpdateSection = false;
        this.InquirySection = true;
        this.window_title = pagetype.name;
        break;
    }
  }
  ngOnInit() {
    this.cd.detectChanges();
  }

}
