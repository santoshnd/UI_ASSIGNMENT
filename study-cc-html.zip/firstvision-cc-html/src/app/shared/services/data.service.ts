import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class DataService {
  constructor(private http: HttpClient) { }

  // Uses http.get() to load data from a single API endpoint
  getJson() {
    return this.http.get('assets/json/landing-page.json');
  }
  getAnyJson(url) {
    return this.http.get(url);
  }
  getBPSheetByProcessName(processName) {
    return this.http.get('assets/json/' + processName + '.json');
  }
  getConfig() {
    return this.http.get('assets/json/config.json');
  }
  getDropdownJson() {
    return this.http.get('assets/json/PropogationDropDown.json');
  }
  getGridJson() {
    return this.http.get('assets/json/gridData.json');
  }
  getTreeJson(processName) {
    return this.http.get('assets/json/' + processName + '.json');
  }
  getErrorJson() {
    return this.http.get('assets/json/error.json');
  }
  getClientDropdownJson() {
    return this.http.get('assets/json/clientDropdown.json');
  }

  getGridConfig(gridName): any {
    return this.http.get('assets/configs/gridConfig.json')
      .map((config: any) => {
        return config.dataGrid.find(x => x.gridName === gridName);
      });
  }
  getTopicDataJson() {
    return this.http.get('./../../assets/json/dropdown.json');
  }
  getAccountLookupDataJSON() {
    return this.http.get('./../../assets/json/mock/accountLookup.json');
  }
  getReasonCodeJson() {
    return this.http.get('./../../assets/json/ReasonCode.json');
  }
  getQMgrItmListJson() {
    return this.http.get('assets/json/mock/qmanager/qitemlist.json');
  }
  getLayoutJson(url) {
    return this.http.get(url);
}
  getQMgrNoteListJson() {
    return this.http.get('assets/json/mock/qmanager/notelist.json');
  }
}
