import { Injectable} from '@angular/core';
import {RequestOptions, Headers, Request, RequestMethod} from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs/Observable';
import { PUIModelLocator } from '../models/PUIModelLocator';
import { RequestFormat } from './RequestFormat.service';
import { post } from 'selenium-webdriver/http';
import "rxjs/Rx";
import { Subject } from 'rxjs/Subject';
@Injectable()

export class ServerFactory {

    responseData: any;
    options: any;   
    _request: any;
    
    constructor(private http:HttpClient , private request:RequestFormat) {}
    invokeService(serviceName, contentType) : Observable<any>  {
         
      
        let header = new Headers({ 'Content-Type': 'application/json' });
        
        const options = new RequestOptions({
            headers : header,
            method: RequestMethod.Post
          });
          
         return this.http.get('./assets/json/gridData.json')
             .map((response: Response) => {
                return response;
            }) 
            .catch(this.handleError); 
    }
    private extractData(res: Response) {
        let body = res.json();
        return body ;
    } 
    private handleError(error: Response) {
        return Observable.throw(error.statusText); 
    }
          
}
