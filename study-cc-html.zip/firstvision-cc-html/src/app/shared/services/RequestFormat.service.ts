import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs/Observable';
import { PUIModelLocator } from '../models/PUIModelLocator';

@Injectable()

export class RequestFormat {
     _paramObject : any;
    constructor(private http:HttpClient ) {}

    buildRequest(requestName, parameterobj)
    {
        
             if(requestName=="getbpgroup")
             {          
                 this._paramObject= Object.assign({}, parameterobj);
                 this._paramObject.clientId = parameterobj.clientId;
                 this._paramObject.bpName = parameterobj.bpName;
                
            }
    }
    getInstance(){
        return this._paramObject
    }
}