import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { debuglog } from 'util';

@Injectable()
export class EventServiceService {

  constructor() { }
  eventRecorded = new BehaviorSubject<any>({})
  eventRecord$ = this.eventRecorded.asObservable();

  changeEvent(message: any) {
    this.eventRecorded.next(message);
  }



}
