import { Injectable } from '@angular/core';



@Injectable()
export class LangService {
  static data: any;
  static dataCacheLang = {};
  // Events.
  /*[Event(name="configLoaded")]*//*;*/
  constructor(private data: any) { }
  static xml: any;
  // Static event names.
  static CONFIG_LOADED: String = 'configLoaded';
  // Static enumerations for runType.
  static STANDALONE: String = 'standalone';
  static DEBUG: String = 'debug';
  static LIVE: String = 'live';

  // Static enumeration for releaseType.
  public static RELEASE_BARCLAYS: String = 'BARCLAYS';
  public static RELEASE_EMEA: String = 'EMEA';
  public static RELEASE_BASE: String = 'BASE';
  public static RELEASE_LAC_BZ: String = 'LAC-BZ';


  // Instance members.
  _instance: LangService;
  loader: any;

  /**
   * Constructor, because it uses SingletonEnforcer as its only parameter it can't be accidently invoked.
   */
  // constructor(enforcer: SingletonEnforcer) {
  //   //  this.loader = new URLLoader();
  //   //  this.loader.addEventListener(Event.COMPLETE, this.xmlLoaded);
  // }

  /**
   * Provides an means of creating a reference to a valid, instantiated Config object.
   */
  // public static getInstance(): Config {
  //    // check to see if we have already created a config instance, if so return that
  //   // otherwise create a new one and return it.
  //     if (!Config._instance)
  //         Config._instance = new Config(new SingletonEnforcer());

  //     return Config._instance;
  // }

  /**
   * Must be called at least once in order to instruct the object to retrieve config.xml file from hosting server.
   */

  public static loadInstanceLang(jsonFile: string) {

    return new Promise((resolve, reject) => {
      const xobj = new XMLHttpRequest();
      xobj.overrideMimeType('application/json');
      xobj.open('GET', jsonFile, true);
      xobj.onreadystatechange = () => {
        if (xobj.readyState == 4) {
          if (xobj.status == 200) {
            this.dataCacheLang[jsonFile] = new LangService(JSON.parse(xobj.responseText));
            console.log(typeof this.dataCacheLang[jsonFile]);
            this.xml = this.dataCacheLang[jsonFile];
            // console.log(this.xml);
            resolve();
          } else {
            reject(`Could not load file '${jsonFile}': ${xobj.status}`);
          }
        }
      };
      xobj.send(null);
    });

  }

  public static getInstanceLang(jsonFile: string) {
    if (jsonFile in this.dataCacheLang) {
      return this.dataCacheLang[jsonFile];
     } else {
      throw new Error(`Could not find config '${jsonFile}', did you load it?`);
    }
    }
  public get(key: string) {
    if (this.data == null) {
      return null;
    }
    if (key in this.data) {
      return this.data[key];
    }
    return null;
  }
  public static get ssoWSDL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.openSSO.ssoWSDL;
    }
    return result;
  }

  /**
   * Returns value of true/false depending on if they want IDVerify to dosplay additional data
   */
  public static get showTransactionsInIdVerify(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.showTransactionsInIdVerify;
    }
    return result;

  }

  /**
   * Returns url location to WSDL for password change web service.
   */
  public static get pwdWSDL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.openSSO.ssoChangePwd;
    }
    return result;
  }

  public static get language(): any {
    let result: any;
    if (this.xml) {
      result = this.xml.language.item;
    }
    return result;

  }

  public static get suppression(): any {
    let result: any;
    if (this.xml) {
      result = this.xml.suppression.item;
    }
    return result;

  }


  /**
   * Returns url location to WSDL for sso user management service.
   */
  public static get ssoUserAttrWSDL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.openSSO.ssoUserAttrWSDL;
    }
    return result;
  }

  /**
   * Returns url SSO logout web service.
   */
  public static get ssoLogout(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.openSSO.ssoLogout;
    }
    return result;
  }

  public static get pwdExpiryNotifiyLimit(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.openSSO.pwdExpiryNotifiyLimit;
    }
    return result;
  }

  /**
   * Location for all customer server URL service invocations.
   */
  public static get customerServiceURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.custSvc.customerService;
    }

    return result;
  }
  /**
   * Location for all extended ui  server URL service invocations.
   */
  public static get xuiServiceURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.xuiSvc.xuiService;
    }

    return result;
  }
  public static getLogoImage(org: String): String {
    let result: String = '';

    if (this.xml) {
      //   result = this.xml.custSvc.logoImages.logo.(@org == org)[0].@path;
      result = '';
      return result;
    }
  }
  public static get parameterMenuServiceURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.paramMgt.menuService;
    }
    return result;
  }

  public static get parameterPageServiceURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.paramMgt.pageService;
    }

    return result;
  }

  public static get camServiceUrl(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.paramMgt.camService;
    }

    return result;
  }

  public static get camFlowUrl(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.camapp.campService;
    }

    return result;
  }


  public static get parameterHelpServiceURL(): String {
    let helpURL: String = '';
    if (this.xml) {
      helpURL = this.xml.paramMgt.helpService;
    }

    return helpURL;
  }

  public static get custSvcHelpURL(): String {
    let helpURL: String = '';
    if (this.xml) {
      helpURL = this.xml.custSvc.helpService;
    }

    return helpURL;
  }

  public static get datSvcHelpURL(): String {
    let helpURL: String = '';
    if (this.xml) {
      helpURL = this.xml.openSSO.helpService;
    }

    return helpURL;
  }

  public static get webtopHelpURL(): String {
    let helpURL: String = '';
    if (this.xml) {
      helpURL = this.xml.webtop.helpService;
    }

    return helpURL;
  }

  /**
   * Returns list of urls to invoke when cleaning up / logging out of the application.
   */
  public static get cleanUpURLs(): any {
    return this.xml.cleanUpUrls.url;
  }

  /**
   * Returns list of urls to external sites.
   */
  public static get externalURLs(): any {
    return this.xml.externalLinks[0];
  }

  /**
   * Returns list of urls to disputes URL.
   */
  public static get disputesURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.disputesURL.url;
    }
    return result;
  }

  /**
   * Returns list of urls to collections URL.
   */
  public static get collectionsURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.collectionsURL.url;
    }
    return result;
  }

  /**
   * Application running mode
   */
  public static get runType(): String {
    let type: String = this.xml.runType;
    type = type.toLowerCase();
    return type;
  }

  public static get debugSessionToken(): String {
    const token: String = this.xml.debugSessionToken;
    if (this.runType && this.runType === 'debug') {
      return token;
    } else {
      return null;
    }
  }

  public static get releaseType(): String {
    const type: String = this.xml.releaseType;
    if (type) {
      return type;
    }

    return this.RELEASE_BARCLAYS; // default type.
  }

  public static get uiToolkitServiceURL(): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.uiToolKit.uiToolkitService;
    }
    return result;
  }

  public static getAttribute(childName: String): String {
    let result: String = '';

    if (this.xml) {
      result = this.xml.child(childName).url;
    }
    return result;
  }
}
