/**
 * Author: Ashitosh
 * Description: Utility for formatting different data
 */
export class DataFormatter {
    parseGridData(data: any, columns: any): any[] {
        const gridData = [];
        for (let i = 0; i < data.length; i++) {
            const row = data[i];
            if (row.field) {
                let hasnilRows = row.field.filter(x => x.value && x.value.nil);
                if (hasnilRows.length <= columns.length) {
                    const rowObj = [];
                    for (let i = 0; i < columns.length; i++) {
                        const col = columns[i];
                        let val = row.field.find(x => x.id === col.property).value;
                        rowObj[col.field] = val && val.text ? val.text : val;
                    }
                    gridData.push(rowObj);
                }
            }
        }
        return gridData;
    }

    extractColumns(field): any {
        if (field.length) {
            const rowObj = [];
            for (let i = 0; i < field.length; i++) {
                const column = field[i];
                if (column.control === 'GridLabel' || column.control === 'Label') {
                    rowObj.push({ title: column.label, property: column.id, field: column.label.replace(/\s/g, '') });
                }
            }
            return rowObj;
        }
    }
}
