import { CurrencyAttributes } from '../cpSharedLib/currencyAttributes';


export class FormatterUtil {
    public static CURR_SUB_UNITS: string = 'Currency- Sub Units';
    public static CURR_SUB_UNITS_ABBREV: string = 'sub';
    public static CURR_WHOLE_UNITS: string = 'Currency- Whole Units';
    public static WHOLE_MON_UNIT: string = 'Whole Monetary Unit';
    public static PER_ITEM_AMOUNT: string = 'AMT';
    public static PER_S9V99: string = 'Percent-S9V';

    /**
     * To convert given Julian date(YYYYDDD) to Gregorian date(YYYYMMDD)
     *
     * jDate - is the input Julian date.
     * formatString - the expected output format.
     */
    public static formatJulianToGregorianDate(
        jDate: string,
        formatString: string = 'DD/MM/YYYY'
    ): string {
        if (jDate == null || jDate == '0' || jDate == '') {
            return '';
        }

        let year, month, day, l, n, i, j, k;
        l = jDate + 68569;
        n = Math.floor(Math.floor(4 * l) / 146097);
        l = l - Math.floor((146097 * n + 3) / 4);
        i = Math.floor(4000 * (l + 1) / 1461001);
        l = l - Math.floor(1461 * i / 4) + 31;
        j = Math.floor(80 * l / 2447);
        k = l - Math.floor(2447 * j / 80);
        l = Math.floor(j / 11);
        j = j + 2 - 12 * l;
        i = 100 * (n - 49) + i + l;

        year = i;
        month = j;
        day = k;
        const georgianDate = new Date(year, month, day).toDateString();
        if (!georgianDate) {
            return;
        }
        return georgianDate;

    }

    /**
     * Converts GregorianDate to JulianDate.
     * gDate - is the input Gregorian date.
     * formatString - is the input date string format.
     */

    //   public static formatGregorianToJulianDate(
    //     gDate: string,
    //     formatString: string
    //   ): string {
    //     let df: DateFormatter = FormatterUtil.getDateFormatter("YYYYMMDD");

    //     let dt: Date = DateField.stringToDate(gDate, formatString);
    //     //hack: When the date object is exactly 01/01/1970 00:00:00 000+GMT(the user timezone is GMT) which essentially means "0" in
    //     //milisecond terms which results in error when calling DateFormatter.format().
    //     if (dt) { dt.setSeconds(0, 1); } // add "1" milisecond to the date to avoid the above condition.

    //     let date: string = df.format(dt);

    //     /* If there is any Error in formatting return the passed date back
    // 			   else process to Julian date. */
    //     if (df.error != null && df.error.length > 0) {
    //       return gDate;
    //     }

    //     let ymd: number = new Number(date); //yyyymmdd
    //     // get year only
    //     let iyear: number = ymd - ymd % 10000;

    //     //get month only
    //     let imonth: number = ymd - iyear;
    //     imonth = (imonth - imonth % 100) / 100;

    //     iyear = iyear / 10000;

    //     let iday: number = ymd % 100;

    //     if (imonth < 3) {
    //       imonth += 12;
    //       iyear--;
    //     }
    //     imonth++;

    //     let ia: number = (iyear - iyear % 100) / 100;
    //     let ib: number = (ia - ia % 4) / 4;
    //     let ic: number = 2 - ia + ib;
    //     let ie: number = (iyear + 4716) * 1461;
    //     ie = (ie - ie % 4) / 4;

    //     let ig: number = imonth * 306001;
    //     ig = (ig - ig % 10000) / 10000;

    //     let ijd: number = ic + iday + ie + ig - 1524;
    //     return FormatterUtil.formatIntoJulianDate(ijd);
    //   }

    //   public static formatIntoJulianDate(ijd: number): string {
    //     let iyyyy: number;
    //     let iw: number = ijd * 4 - 7468865;
    //     iw = (iw - iw % 146097) / 146097;

    //     let ix: number = (iw - iw % 4) / 4;
    //     let ia: number = iw + ijd + 1 - ix;
    //     let ib: number = ia + 1524;
    //     let ic: number = (ib * 10 - 1221) * 2;
    //     ic = (ic - ic % 5) / 5;
    //     ic = (ic - ic % 1461) / 1461;

    //     let id: number = ic * 1461;
    //     id = (id - id % 4) / 4;

    //     let ig: number = ib - id;
    //     let ie: number = ig * 10000;
    //     ie = (ie - ie % 306001) / 306001;

    //     let idd2: number = ie * 306001;
    //     idd2 = (idd2 - idd2 % 10000) / 10000;

    //     let idd: number = ig - idd2;
    //     let idj: number = ie;

    //     if (ie > 13) {
    //       ie -= 13;
    //       iyyyy = ic - 4715;
    //     } else {
    //       ie--;
    //       iyyyy = ic - 4716;
    //     }

    //     // imj is number of days to 3/1 in adjusted month table
    //     let imj: number = 61;
    //     let idyj2: number;
    //     let idyj: number;
    //     let ileap: number;

    //     if (idj > 13) {
    //       imj = 397;
    //       idyj2 = (idj - 1) * 306001;
    //       idyj2 = (idyj2 - idyj2 % 10000) / 10000;
    //       idyj = idd + idyj2 - imj;
    //     } else {
    //       let irem: number = iyyyy % 4;
    //       if (irem == 0) { ileap = 1; }
    //       else { ileap = 0; }

    //       idyj2 = idj * 306001;
    //       idyj2 = (idyj2 - idyj2 % 10000) / 10000;
    //       idyj = idd + idyj2 - imj - 1 - 1 * (1 - ileap);
    //     }

    //     let idate: number = iyyyy * 1000 + idyj;
    //     return idate.toString();
    //   }

    /**
     * Returns the dateFormatter
     * @return df - DateFormatter.
     */
    public static getDateFormatter(formatString: string): Date {
        return new Date(formatString);
    }

    /**
     * Values for the property currencySymbol, thousandsSeparator, decimalSeparator, precision(NOD)
     */

    public static formatCurrency(
        value: string,
        fieldType: string,
        currencyAttribute: CurrencyAttributes = null
    ): string {
        if (!value || value == '') { return ''; }

        let isNegative: boolean = value.indexOf('-') == 0;
        if (isNegative) { value = value.slice(1); } // Remove the '-' sign

        let valueObject: any;

        switch (fieldType.toLowerCase()) {
            case FormatterUtil.CURR_SUB_UNITS.toLowerCase():
            case FormatterUtil.CURR_SUB_UNITS_ABBREV.toLowerCase():
                if (value.length < currencyAttribute.currencyNOD) {
                    value = FormatterUtil.addTrailingZero(
                        value,
                        currencyAttribute.currencyNOD
                    );
                }
                value =
                    value.substring(0, value.length - currencyAttribute.currencyNOD) +
                    currencyAttribute.decimalSymbol +
                    value.substring(
                        value.length - currencyAttribute.currencyNOD,
                        value.length
                    );
                break;
            case FormatterUtil.CURR_WHOLE_UNITS.toLowerCase():
                if (value.length < currencyAttribute.currencyNOD) {
                    value = FormatterUtil.addTrailingZero(
                        value,
                        currencyAttribute.currencyNOD
                    );
                }
                value = value.substr(0, value.length - currencyAttribute.currencyNOD);
                if (value == '') { value = '0'; }
                valueObject = new Object();
                valueObject.value = value;
                valueObject.type = fieldType.toLowerCase();
                break;
            case FormatterUtil.PER_ITEM_AMOUNT.toLowerCase():
                if (value.length < currencyAttribute.peritemNOD) {
                    value = FormatterUtil.addTrailingZero(
                        value,
                        currencyAttribute.peritemNOD
                    );
                }
                value =
                    value.substring(0, value.length - currencyAttribute.peritemNOD) +
                    currencyAttribute.decimalSymbol +
                    value.substring(
                        value.length - currencyAttribute.peritemNOD,
                        value.length
                    );
                break;
            case FormatterUtil.WHOLE_MON_UNIT.toLowerCase():
                valueObject = new Object();
                valueObject.value = value;
                valueObject.type = fieldType.toLowerCase();
                break;
            default:
                if (value.length < currencyAttribute.currencyNOD) {
                    value = FormatterUtil.addTrailingZero(
                        value,
                        currencyAttribute.currencyNOD
                    );
                }
                value =
                    value.substring(0, value.length - currencyAttribute.currencyNOD) +
                    currencyAttribute.decimalSymbol +
                    value.substring(
                        value.length - currencyAttribute.currencyNOD,
                        value.length
                    );
                break;
        }

        if (isNegative) { value = '-' + value; } // put the "-" sign back.
        // currency formatter routine not handling whole unit types properly when value is zero
        let formatResult: any;
        // if (valueObject) {
        //     formatResult = cur.format(valueObject, {
        //         symbol: currencyAttribute.currSymbol + " ",
        //         decimal: currencyAttribute.decimalSymbol,
        //         thousandsSeparator: currencyAttribute.digitGroupSymbol,
        //         precision: currencyAttribute.currencyNOD,
        //         symbolOnLeft: true,
        //         format: '%v %s' // %s is the symbol and %v is the value
        //     });
        // }
        // else {
        //     formatResult = cur.format(value, {
        //         symbol: currencyAttribute.currSymbol + " ",
        //         decimal: currencyAttribute.decimalSymbol,
        //         thousandsSeparator: currencyAttribute.digitGroupSymbol,
        //         precision: currencyAttribute.currencyNOD,
        //         symbolOnLeft: true,
        //         // format: '%v %s' // %s is the symbol and %v is the value
        //     });
        // }
        return formatResult;
    }

    //   //Used only by the CustomerService Application.
    //   public static amountFormat(
    //     value: string,
    //     currencyAttribute: CurrencyAttributes
    //   ): string {
    //     let finalValue: string = "";
    //     for (let i: number = 0; i < value.length; i++) {
    //       let char: string = value.charAt(i);
    //       if (
    //         FormatterUtil.isCurrSymbol(char, currencyAttribute) ||
    //         char == currencyAttribute.digitGroupSymbol ||
    //         char == currencyAttribute.currSymbol ||
    //         char == "$"
    //       ) {
    //         continue;
    //       }
    //       else { finalValue += char; }
    //     }
    //     finalValue = String.prototype.trim(finalValue);

    //     if (finalValue == "") { finalValue = "0"; }

    //     finalValue = this.CommonUtils.removeLeadingZero(finalValue);
    //     // flex Number class will not deal with a decimal symbol other than '.'
    //     if (currencyAttribute.decimalSymbol != ".") {
    //       finalValue = finalValue.replace(currencyAttribute.decimalSymbol, ".");
    //     }
    //     /*                let num:Number = new Number(finalValue);
    //                   let i:int = Math.round(num *  getNodValue(currencyAttribute.currencyNOD));
    //                   finalValue = i.toString();    */

    //     //Banco SIT QC 683: commented below two lines
    //     /*let num:Number = Number(finalValue) * getNodValue(currencyAttribute.currencyNOD);
    //                   finalValue = num.toString();*/

    //     let valueString: string = finalValue.toString();
    //     let decimalString: string = valueString.slice(
    //       valueString.length - 2,
    //       valueString.length
    //     );
    //     let num: number =
    //       Number(finalValue) *
    //       FormatterUtil.getNodValue(currencyAttribute.currencyNOD);
    //     let numValue: string = num.toString();
    //     if (valueString.indexOf(".") >= 0) {
    //       finalValue = numValue.slice(0, valueString.length - 3) + decimalString;
    //     } else {
    //       finalValue = numValue;
    //     }

    //     //finalValue = correctFloatingPointError(num) + "";

    //     return finalValue;
    //   }

    //   private static isCurrSymbol(
    //     char: string,
    //     currencyAttribute: CurrencyAttributes
    //   ): boolean {
    //     let result: boolean = false;

    //     for (let i: number = 0; i < currencyAttribute.currSymbol.length; i++) {
    //       if (char == currencyAttribute.currSymbol.charAt(i)) {
    //         result = true;
    //         break;
    //       }
    //     }
    //     return result;
    //   }

    //   /**
    //    * Corrects errors caused by floating point math.
    //    */
    //   public static correctFloatingPointError(
    //     number: number,
    //     precision: number = 3
    //   ): number {
    //     let correction: number = Math.pow(10, precision);
    //     return Math.round(correction * number) / correction;
    //   }

    public static addTrailingZero(value: string, count: number): string {
        let pad: number = count - value.length;
        for (let i: number = 0; i < pad; i++) {
            value = '0' + value;
        }
        return value;
    }

    //   /**
    //    * Special process to display S9V99 or explicit percent fields as whole number percentages.
    //    * @param value
    //    * @param mask
    //    */

    //   public static formatExplicitPercent(
    //     value: string,
    //     mask: string = "###",
    //     currencyAttribute: CurrencyAttributes = null
    //   ): string {
    //     let returnVal: string = "";

    //     if (FormatterUtil.hasDecimal(value)) {
    //       let tmp: string = value.replace(currencyAttribute.decimalSymbol, "");
    //       tmp = tmp + FormatterUtil.addTrailingZero("", mask.length - tmp.length);
    //       returnVal = Number(tmp).toString();
    //     } else {
    //       returnVal =
    //         value + FormatterUtil.addTrailingZero("", mask.length - value.length);
    //     }

    //     return returnVal;
    //   }

    //   /**
    //    * Precision(NOD) value should be passed.
    //    * @param value
    //    */

    //   public static formatPercent(
    //     value: string,
    //     percentNOD: number,
    //     decimalSymbol: string = "."
    //   ): string {
    //     let returnVal: string = "";

    //     if (FormatterUtil.hasDecimal(value, decimalSymbol)) {
    //       returnVal = value;
    //     } else {
    //       let num: number = Number(value);

    //       num = num / FormatterUtil.getNodValue(percentNOD);
    //       returnVal = num.toString();
    //       // when dividing value by NOD, normal decimal ('.') is used, replace '.' with 'decimalSymbol' letiable
    //       returnVal = returnVal.replace(".", decimalSymbol);
    //     }

    //     return returnVal;
    //   }

    //   /**
    //    * Returns the status whether the value has decimal or not.
    //    * @param value.
    //    */
    //   private static hasDecimal(
    //     value: string,
    //     decimalSymbol: string = "."
    //   ): boolean {
    //     let hasDecimal: boolean = false;
    //     for (let i: number = 0; i < value.length; i++) {
    //       if (value.charAt(i) == decimalSymbol) {
    //         hasDecimal = true;
    //         break;
    //       } else {
    //         hasDecimal = false;
    //       }
    //     }
    //     return hasDecimal;
    //   }

    //   /**
    //    * Formats 16 digit numbers with dashes.
    //    * @param value
    //    */
    //   public static cardNumber(val: string): string {
    //     // make sure we actually have data to format.
    //     if (!val || val == "") { return ""; }

    //     let prefix: string = val.substr(0, 3);
    //     if (prefix == "000") { val = val.substr(3, 16); }

    //     // let result:String = "****-****-****-" + val.substr(12, 4);
    //     let result: string = val.substr(0, 4);
    //     result += "-" + val.substr(4, 4);
    //     result += "-" + val.substr(8, 4);
    //     result += "-" + val.substr(12, 4);

    //     return result;
    //   }

    //   /**
    //    * Formats a set of address fields into a single address line
    //    */
    //   public static shipAddress(
    //     addr1: string = " ",
    //     addr2: string = " ",
    //     city: string = " ",
    //     postalCode: string = " ",
    //     state: string = " ",
    //     county: string = " "
    //   ): string {
    //     let result: string = "";
    //     result += String.prototype.trim(addr1);
    //     if (String.prototype.trim(addr2).length > 0) {
    //       result += ", " + String.prototype.trim(addr2);
    //     }
    //     result += ", " + String.prototype.trim(city);
    //     if (state != " ") { result += ", " + String.prototype.trim(state); }
    //     if (postalCode != " ") { result += " " + String.prototype.trim(postalCode); }
    //     if (county != " ") { result += ", " + String.prototype.trim(county); }

    //     return result;
    //   }

    //   public static formatJulianToMonthYear(
    //     jDate: string,
    //     formatString: string = "DD/MM/YYYY"
    //   ): string {
    //     if (jDate == null || jDate == "0" || jDate == "") {
    //       return "";
    //     }

    //     let work_date: string = "";
    //     let result: string = "";
    //     work_date = FormatterUtil.formatJulianToGregorianDate(jDate, formatString);

    //     if (formatString == "MM/DD/YYYY") {
    //       result = work_date.substr(0, 3) + work_date.substr(6, 4);
    //     }
    //     else if (formatString == "DD/MM/YYYY") { result = work_date.substr(3, 7); }

    //     return result;
    //   }

    //   public static getNodValue(nod: number): number {
    //     let resultValue: number = 0;
    //     resultValue = Math.pow(10, nod);

    //     return resultValue;
    //   }

    //   //Used only by the CustomerService Application.
    //   public static createCurrencyMask(curAttrib: CurrencyAttributes): string {
    //     let mask: string = curAttrib.currSymbol + " ";
    //     let curNOD: number = curAttrib.currencyNOD;
    //     let maxChar: number = 9 - curNOD;

    //     for (let i: number = 0; i < maxChar; i++) { mask += "#"; }

    //     mask += curAttrib.decimalSymbol;

    //     for (let j: number = 0; j < curNOD; j++) { mask += "#"; }

    //     return mask;
    //   }

    //   /**
    //    * Values for the property thousandsSeparator, decimalSeparator, precision(NOD)
    //    */

    //   public static formatCurrencyWithoutSymbol(
    //     value: string,
    //     fieldType: string,
    //     currencyAttribute: CurrencyAttributes = null
    //   ): string {
    //     if (!value || value == "") { return ""; }

    //     let isNegative: boolean = value.indexOf("-") == 0;
    //     if (isNegative) { value = value.slice(1); } //Remove the '-' sign

    //     let cur: CustomCurrencyFormatter = new CustomCurrencyFormatter();
    //     if (currencyAttribute) {
    //       cur.currencySymbol = " ";
    //       cur.useThousandsSeparator = "true";
    //       cur.thousandsSeparatorTo = currencyAttribute.digitGroupSymbol;
    //       cur.decimalSeparatorTo = currencyAttribute.decimalSymbol;
    //     }

    //     switch (fieldType) {
    //       case FormatterUtil.CURR_SUB_UNITS:
    //         if (value.length < currencyAttribute.currencyNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.currencyNOD
    //           );
    //         }
    //         cur.precision = currencyAttribute.currencyNOD;
    //         value =
    //           value.substring(0, value.length - currencyAttribute.currencyNOD) +
    //           currencyAttribute.decimalSymbol +
    //           value.substring(
    //             value.length - currencyAttribute.currencyNOD,
    //             value.length
    //           );
    //         break;
    //       case FormatterUtil.CURR_WHOLE_UNITS:
    //         if (value.length < currencyAttribute.currencyNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.currencyNOD
    //           );
    //         }
    //         value = value.substr(0, value.length - currencyAttribute.currencyNOD);
    //         if (value == "") { value = "0"; }
    //         break;
    //       case FormatterUtil.PER_ITEM_AMOUNT:
    //         if (value.length < currencyAttribute.peritemNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.peritemNOD
    //           );
    //         }
    //         cur.precision = currencyAttribute.peritemNOD;
    //         value =
    //           value.substring(0, value.length - currencyAttribute.peritemNOD) +
    //           currencyAttribute.decimalSymbol +
    //           value.substring(
    //             value.length - currencyAttribute.peritemNOD,
    //             value.length
    //           );
    //         break;
    //       case FormatterUtil.WHOLE_MON_UNIT:
    //         break;
    //     }

    //     if (isNegative) { value = "-" + value; }

    //     trace("FormatterUtil: [formatCurrency]: " + value);
    //     return value;
    //   }

    //   //QC #50621
    //   public static formatTime(time: string): string {
    //     if (time == null || time == "0" || time == "") {
    //       return "";
    //     }

    //     while (time.length < 6) {
    //       time = "0" + time;
    //     }

    //     return (
    //       time.substr(0, 2) + ":" + time.substr(2, 2) + ":" + time.substr(4, 2)
    //     );
    //   }

    //   /**
    //    * Values for the property currencySymbol, thousandsSeparator, decimalSeparator, precision(NOD)
    //    */

    //   public static formatRewardsCurrency(
    //     value: string,
    //     fieldType: string,
    //     currencyAttribute: CurrencyAttributes = null
    //   ): string {
    //     if (!value || value == "") { return ""; }

    //     let isNegative: boolean = value.indexOf("-") == 0;
    //     if (isNegative) { value = value.slice(1); } //Remove the '-' sign

    //     let cur: CustomCurrencyFormatter = new CustomCurrencyFormatter();
    //     if (currencyAttribute) {
    //       cur.currencySymbol = currencyAttribute.currSymbol + " ";
    //       cur.useThousandsSeparator = "true";
    //       cur.thousandsSeparatorTo = currencyAttribute.digitGroupSymbol;
    //       cur.decimalSeparatorTo = currencyAttribute.decimalSymbol;
    //       cur.thousandsSeparatorFrom = currencyAttribute.digitGroupSymbol;
    //       cur.decimalSeparatorFrom = currencyAttribute.decimalSymbol;
    //       cur.alignSymbol = "left";
    //     }

    //     /*if(value.length < currencyAttribute.currencyNOD)
    // 				value = addTrailingZero(value, currencyAttribute.currencyNOD)*/
    //     let valueObject: Object;

    //     switch (fieldType.toLowerCase()) {
    //       case FormatterUtil.CURR_SUB_UNITS.toLowerCase():
    //       case FormatterUtil.CURR_SUB_UNITS_ABBREV.toLowerCase():
    //         if (value.length < currencyAttribute.rewardsCurrencyNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.rewardsCurrencyNOD
    //           );
    //         }
    //         cur.precision = currencyAttribute.rewardsCurrencyNOD;
    //         value =
    //           value.substring(
    //             0,
    //             value.length - currencyAttribute.rewardsCurrencyNOD
    //           ) +
    //           currencyAttribute.decimalSymbol +
    //           value.substring(
    //             value.length - currencyAttribute.rewardsCurrencyNOD,
    //             value.length
    //           );
    //         break;
    //       case FormatterUtil.CURR_WHOLE_UNITS.toLowerCase():
    //         if (value.length < currencyAttribute.rewardsCurrencyNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.rewardsCurrencyNOD
    //           );
    //         }
    //         value = value.substr(
    //           0,
    //           value.length - currencyAttribute.rewardsCurrencyNOD
    //         );
    //         if (value == "") { value = "0"; }
    //         valueObject = new Object();
    //         valueObject.value = value;
    //         valueObject.type = fieldType.toLowerCase();
    //         break;
    //       case FormatterUtil.PER_ITEM_AMOUNT.toLowerCase():
    //         if (value.length < currencyAttribute.rewardsPerItemNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.rewardsPerItemNOD
    //           );
    //         }
    //         cur.precision = currencyAttribute.rewardsPerItemNOD;
    //         value =
    //           value.substring(
    //             0,
    //             value.length - currencyAttribute.rewardsPerItemNOD
    //           ) +
    //           currencyAttribute.decimalSymbol +
    //           value.substring(
    //             value.length - currencyAttribute.rewardsPerItemNOD,
    //             value.length
    //           );
    //         break;
    //       case FormatterUtil.WHOLE_MON_UNIT.toLowerCase():
    //         valueObject = new Object();
    //         valueObject.value = value;
    //         valueObject.type = fieldType.toLowerCase();
    //         break;
    //       default:
    //         if (value.length < currencyAttribute.rewardsCurrencyNOD) {
    //           value = FormatterUtil.addTrailingZero(
    //             value,
    //             currencyAttribute.rewardsCurrencyNOD
    //           );
    //         }
    //         cur.precision = currencyAttribute.rewardsCurrencyNOD;
    //         value =
    //           value.substring(
    //             0,
    //             value.length - currencyAttribute.rewardsCurrencyNOD
    //           ) +
    //           currencyAttribute.decimalSymbol +
    //           value.substring(
    //             value.length - currencyAttribute.rewardsCurrencyNOD,
    //             value.length
    //           );
    //         break;
    //     }

    //     if (isNegative) { value = "-" + value; } //put the "-" sign back.

    //     trace("FormatterUtil: [formatCurrency]: " + value);

    //     //currency formatter routine not handling whole unit types properly when value is zero
    //     let formatResult: string;
    //     if (valueObject) { formatResult = cur.format(valueObject); }
    //     else { formatResult = cur.format(value); }

    //     return formatResult;
    //   }

    //   public static formatRewardsPoints(
    //     value: string,
    //     currencyAttribute: CurrencyAttributes = null
    //   ): string {
    //     if (!value || value == "") { return ""; }

    //     let isNegative: boolean = value.indexOf("-") == 0;
    //     if (isNegative) { value = value.slice(1); } //Remove the '-' sign

    //     if (value.length < currencyAttribute.rewardsPerItemNOD) {
    //       value = FormatterUtil.addTrailingZero(
    //         value,
    //         currencyAttribute.rewardsPerItemNOD
    //       );
    //     }

    //     value =
    //       value.substring(0, value.length - currencyAttribute.rewardsPerItemNOD) +
    //       currencyAttribute.decimalSymbol +
    //       value.substring(
    //         value.length - currencyAttribute.rewardsPerItemNOD,
    //         value.length
    //       );

    //     if (isNegative) { value = "-" + value; } //put the "-" sign back.

    //     //todo

    //     let decimalSeparatorFrom: string = currencyAttribute.decimalSymbol;
    //     let thousandsSeparatorFrom: string = currencyAttribute.digitGroupSymbol;
    //     let decimalSeparatorTo: string = currencyAttribute.decimalSymbol;
    //     let thousandsSeparatorTo: string = currencyAttribute.digitGroupSymbol;
    //     let precision: number = currencyAttribute.rewardsPerItemNOD;
    //     let rounding: string;
    //     let useThousandsSeparator: Object;

    //     let dataFormatter: CustomNumberBase = new CustomNumberBase(
    //       decimalSeparatorFrom,
    //       thousandsSeparatorFrom,
    //       decimalSeparatorTo,
    //       thousandsSeparatorTo
    //     );

    //     // -- value --
    //     if (value instanceof String) {
    //       value = dataFormatter.parseNumberString(String(value));
    //     }

    //     if (value === null || isNaN(Number(value))) {
    //       return "";
    //     }

    //     // -- format --
    //     let isNegative: boolean = Number(value) < 0;

    //     let numStr: string = value.toString();
    //     //parseNumberString will convert any decimal symbol to '.' in the value letiable.
    //     //split will not work if dec symb is anything other than '.'
    //     //must use '.' in the split, regardless of the actual decimal symbol
    //     let numArrTemp: any[] = numStr.split(".");
    //     let numFraction: number = numArrTemp[1] ? String(numArrTemp[1]).length : 0;

    //     if (precision <= numFraction) {
    //       if (rounding) {
    //         if (rounding != NumberBaseRoundType.NONE) {
    //           numStr = dataFormatter.formatRoundingWithPrecision(
    //             numStr,
    //             rounding,
    //             int(precision)
    //           );
    //         }
    //       }
    //     }

    //     let numValue: number = Number(numStr);
    //     if (Math.abs(numValue) >= 1) {
    //       numArrTemp = numStr.split(".");
    //       let front: string = useThousandsSeparator
    //         ? dataFormatter.formatThousands(String(numArrTemp[0]))
    //         : String(numArrTemp[0]);
    //       if (numArrTemp[1] != null && numArrTemp[1] != "") {
    //         numStr = front + decimalSeparatorTo + numArrTemp[1];
    //       }
    //       else { numStr = front; }
    //     } else if (Math.abs(numValue) > 0) {
    //       if (numStr.indexOf("e") != -1) {
    //         let temp: number = Math.abs(numValue) + 1;
    //         numStr = temp.toString();
    //       }
    //       numStr = decimalSeparatorTo + numStr.substring(numStr.indexOf(".") + 1);
    //     } else {
    //       //must be zero
    //       if (value instanceof String) {
    //         numStr = decimalSeparatorTo + numStr.substring(numStr.indexOf(".") + 1);
    //       }
    //       /*else if(type && type.length>0)
    // 	        	   numStr = numStr.substring(numStr.indexOf(".") + 1);*/
    //     }

    //     numStr = dataFormatter.formatPrecision(numStr, number(precision));

    //     if (Number(value) == 0) {
    //       isNegative = false;
    //     }

    //     if (isNegative) { numStr = dataFormatter.formatNegative(numStr, true); }

    //     return numStr;
    //   }
}
