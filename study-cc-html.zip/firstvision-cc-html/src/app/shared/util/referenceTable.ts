export class ReferenceTable {
  public associationMappings = [
    {
      id: "1",
      label: "Guarantor"
    },
    {
      id: "2",
      label: "Cosigner"
    },
    {
      id: "4",
      label: "Third-party insured"
    },
    {
      id: "5",
      label: "User-defined"
    },
    {
      id: "6",
      label: "User-defined"
    },
    {
      id: "7",
      label: "User-defined"
    },
    {
      id: "8",
      label: "User-defined"
    },
    {
      id: "9",
      label: "User-defined"
    }
  ];
}
