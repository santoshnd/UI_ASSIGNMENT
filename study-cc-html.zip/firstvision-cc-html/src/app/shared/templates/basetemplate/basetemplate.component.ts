
import {
    Component, Input, OnInit, OnDestroy,
    ViewChild, ViewContainerRef,
    ComponentFactoryResolver, ComponentRef, OnChanges, SimpleChanges
} from '@angular/core';
import { TextBoxComponent } from '../../components/controls/text-box/text-box.component';
import { PasswordComponent } from '../../components/controls/password/password.component';
import { ButtonComponent } from '../../components/controls/button/button.component';
import { LabelComponent } from '../../components/controls/label/label.component';
import { BaseComponent } from '../../components/controls/base-component';
import { ImageComponent } from '../../components/controls/image/image.component';
import { AlertsComponent } from '../../components/controls/alerts/alerts.component';
import { LinkLabelComponent } from '../../components/controls/link-label/link-label.component';
import { DropdownComponent } from '../../components/controls/dropdown/dropdown.component';
import { DateComponent } from '../../components/controls/date/date.component';
import { FilterD4Component } from '../../components/controls/filter-d4/filter-d4.component';
import { CheckBoxComponent } from '../../components/controls/checkbox/checkbox.component';


@Component({
    selector: 'app-basetemplate',
    templateUrl: './basetemplate.component.html',
    styleUrls: ['./basetemplate.component.scss']
})
export class BasetemplateComponent implements OnInit, OnDestroy, OnChanges {

    @ViewChild('container', { read: ViewContainerRef })
    container: ViewContainerRef;

    @Input()
    control: string;

    @Input()
    context: any;

    @Input()
    layout: any;
    @Input()
    htmlClass: any;
    @Input()
    conditions: any;

    @Input() hasColon: boolean;

    private mappings = {
        'TextInputField': TextBoxComponent,
        'password': PasswordComponent,
        'button': ButtonComponent,
        'Label': LabelComponent,
        'LinkLabel': LinkLabelComponent,
        'image': ImageComponent,
        'alert': AlertsComponent,
        'Dropdown': DropdownComponent,
        'DateChooser': DateComponent,
        'FilterD4': FilterD4Component,
        'checkBox':CheckBoxComponent
    };

    private componentRef: ComponentRef<any>;

    constructor(
        private componentFactoryResolver: ComponentFactoryResolver) {
    }

    getComponentType(typeName: string) {
        let control = this.mappings[typeName];
        return control;
    }

    ngOnInit() {
        if (this.context.control) {
            const componentType = this.getComponentType(this.context.control);
            if (!componentType) {
                return;
            }

            // note: componentType must be declared within module.entryComponents
            const factory = this.componentFactoryResolver.resolveComponentFactory(componentType);
            this.componentRef = this.container.createComponent(factory);


            // set component context
            let instance = <BaseComponent>this.componentRef.instance;
            instance.context = this.context;
            instance.layout = this.layout;
            instance.htmlClass = this.htmlClass;
            instance.conditions = this.conditions;
            instance.hasColon = this.hasColon;
        }
    }
    ngOnChanges(changes: SimpleChanges) {
        if (!this.componentRef) { return; }
    }
    ngOnDestroy() {
        if (this.componentRef) {
            this.componentRef.destroy();
            this.componentRef = null;
        }
    }


}
