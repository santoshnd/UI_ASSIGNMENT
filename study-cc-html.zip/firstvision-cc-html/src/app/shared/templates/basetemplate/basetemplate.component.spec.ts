import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasetemplateComponent } from './basetemplate.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ButtonComponent } from '../../controls/button/button.component';
import { LabelComponent } from '../../controls/label/label.component';
import { PasswordComponent } from '../../controls/password/password.component';
import { TextBoxComponent } from '../../controls/text-box/text-box.component';

describe('BasetemplateComponent', () => {
  let component: BasetemplateComponent;
  let fixture: ComponentFixture<BasetemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasetemplateComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasetemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  /* it('should create', () => {
    expect(component).toBeTruthy();
  });  */
});
