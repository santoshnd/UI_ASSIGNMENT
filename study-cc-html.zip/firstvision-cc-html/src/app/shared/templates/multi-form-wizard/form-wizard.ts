import { Directive, Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'my-wizard',
  template: ` 
  <ng-content></ng-content>
  <div class="col-sm-12 row container-fluid">
    <div class="col-sm-9">
      <button class="k-button closeButton" (click)="cancel.emit()">
        Cancel
      </button>
    </div>
    <div class="col-sm-1">
      <div *ngIf="enablePrevious" class="col-sm-1">
        <button [style.visibility]="isOnFirstStep() ? 'hidden' : 'visible'" (click)="stepChange.emit(step - 1)"
          class="k-button k-primary blueButton mr-1">
          Previous
        </button>
      </div>
    </div>
    <div *ngIf="!isOnFinalStep()" class="col-sm-1 float-right" style="margin-left:auto;">
      <button (click)="stepChange.emit(step + 1)" class="k-button k-primary blueButton">
        Next
      </button>
    </div>
    <div *ngIf="isOnFinalStep()" class="col-sm-1 float-right" style="margin-left: auto;">
      <button *ngIf="isOnFinalStep()" (click)="finish.emit(step + 1)" class="k-button k-primary blueButton">
        {{finishText}}
      </button>
    </div>
  </div>
  `,
})
export class MyWizardComponent {
  @Input() finishText;
  @Input() step = 1;
  @Input() enablePrevious;
  @Output() finish = new EventEmitter();
  @Output() stepChange = new EventEmitter();
  @Output() cancel = new EventEmitter();
  private steps = 0;
  private isOnFinalStep = () => this.step === this.steps;
  private isOnFirstStep = () => this.step === 1;

  public addStep() {
    const newSteps = this.steps + 1;
    this.steps = newSteps;
    return newSteps;
  }
}
