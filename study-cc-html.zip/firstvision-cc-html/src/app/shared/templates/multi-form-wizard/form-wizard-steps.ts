import { Component, Input } from '@angular/core';
import { MyWizardComponent } from './form-wizard';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
    selector: 'my-wizard-step',
    host: {
        '[style.display]': 'isCurrent ? "flex" : "none"',
    },
    template: `
    <ng-content></ng-content>
  `,
})
export class MyWizardStepComponent implements OnInit {
    private isCurrent;
    private step;

    constructor(
        private parent: MyWizardComponent
    ) { }

    ngOnInit() {
        this.step = this.parent.addStep();

        this.isCurrent = this.step === this.parent.step;

        this.parent.stepChange.subscribe(step => {
            this.isCurrent = this.step === step;
        });
    }
}
