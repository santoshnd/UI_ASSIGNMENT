import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyWizardComponent } from './form-wizard';
import { MyWizardStepComponent } from './form-wizard-steps';

@NgModule({
    declarations: [MyWizardStepComponent, MyWizardComponent],
    imports: [CommonModule],
    exports: [MyWizardStepComponent, MyWizardComponent],
    providers: [],
})
export class FormsWizardModule { }