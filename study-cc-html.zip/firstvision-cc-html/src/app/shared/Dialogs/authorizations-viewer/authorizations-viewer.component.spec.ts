import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorizationsViewerComponent } from './authorizations-viewer.component';

describe('AuthorizationsViewerComponent', () => {
  let component: AuthorizationsViewerComponent;
  let fixture: ComponentFixture<AuthorizationsViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthorizationsViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorizationsViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
