import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../../services/data.service';
import { config } from '../../../../environments/config/config';
import { DataFormatter } from '../../util/data.formatter';

@Component({
  selector: 'app-authorizations-viewer',
  templateUrl: './authorizations-viewer.component.html',
  styleUrls: ['./authorizations-viewer.component.scss']
})
export class AuthorizationsViewerComponent implements OnInit {
  @Input() data: any;
  @Output() event: EventEmitter<any>;

  private approvedTabData: any;
  private declinedTabData: any;
  private refferrdTabData: any;
  private approvedTabColumn: any;
  private refferrdTabColumn: any;
  private declinedTabColumn: any;
  mockPath: any = config.mockPath;
  recordUrl = this.mockPath + 'records.json';
  dataFormatter = new DataFormatter();


  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.getApprovedData();
  }

  getApprovedData() {
    this.dataService.getGridConfig('notesAndHistory').
      subscribe(gridConfig => {
        this.declinedTabColumn = gridConfig.columns;
        this.dataService.getAnyJson(this.recordUrl).subscribe((data: any) => {
          this.manageData(data.vxRoot.group[0].rows.row, gridConfig.columns);
        });
      });
  }

  manageData(data, columns) {
    this.declinedTabData = this.dataFormatter.parseGridData(data, columns);
    this.refferrdTabData = this.dataFormatter.parseGridData(data, columns);
    this.approvedTabData = this.dataFormatter.parseGridData(data, columns);
  }

  setOriginatorIcon(data: any): string {
    let source = '';
    if (data.originator === 'LJP') {
      source = 'assets/images/icons/large-computer.gif';
    } else {
      source = 'assets/images/icons/iconDetails.png';
    }

    return source;
  }
}
