import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-redeem-points',
  templateUrl: './redeem-points.component.html',
})
export class RedeemPointsComponent implements OnInit {

  @Input() redeemPointsFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();

  constructor(private accountFolderService: AccountFolderService) { }
  fieldValue: any; schemeData:any; pointAccountData: any; rewardItemsData: any;
  pointsToRedemtion: any; totalPoints: any;
  recordUrl = 'assets/json/mock/accountFolderTransaction.json';
  header: { [k: string]: any } = {};
  
  ngOnInit() {
    this.getData();
  }
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
  }

  getData() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.recordUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((data: any) => { 
      this.bindData(data);     
    });
  }

  bindData(data){
    this.pointAccountData = ['0000015215454614', '00000212411454154', '00000154541574199'];
    this.schemeData = ['Cab Scheme', 'Insurance', 'PPF'];
    this.rewardItemsData = ['CC', 'Amex', 'Visa'];
    this.totalPoints = 1250;
    this.pointsToRedemtion = 312;
  }
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
}
