import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-block-account',
  templateUrl: './block-account.component.html',
  styleUrls: ['./block-account.component.scss']
})
export class BlockAccountComponent implements OnInit {
  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  // end here
  htmlClass: { 'valueClass': string; };
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }
  ngOnInit() {
    this.httpurl = 'assets/json/mock/';
    this.htmlClass = {
      'valueClass': 'col-sm-3'
    };
    // this.sendInsuranceDetails();
  }

  sendBlockDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data) {
    this.cd.detectChanges();
    // console.log('>>>>' + JSON.stringify(data));
  }
}
