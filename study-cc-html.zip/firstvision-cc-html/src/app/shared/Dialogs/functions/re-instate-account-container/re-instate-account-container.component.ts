import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';
@Component({
  selector: 'app-re-instate-account-container',
  templateUrl: './re-instate-account-container.component.html',
  styleUrls: ['./re-instate-account-container.component.scss']
})
export class ReInstateAccountContainerComponent implements OnInit {

  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  htmlClass: any;
  accountLayoutdata: any;
  referSection = true;
  @Input() reInstateAccountFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) {
    this.htmlClass = {
      'labelClass': 'col-4 labelclass px-0',
      'valueClass': 'col-5 py-1 px-0'
    };
  }

  ngOnInit() {
    this.reInstateAccountData();
  }
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  reInstateAccountData() {
    this.httpurl = 'assets/json/mock/InstateAccountMock.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindInstateAccountData(data));
  }
  bindInstateAccountData(data) {
    this.accountLayoutdata = data.vxRoot.group.field;
  }
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
}
}
