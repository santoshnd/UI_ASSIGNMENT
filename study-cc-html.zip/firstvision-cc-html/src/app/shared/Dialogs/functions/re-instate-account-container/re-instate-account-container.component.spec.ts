import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReInstateAccountContainerComponent } from './re-instate-account-container.component';

describe('ReInstateAccountContainerComponent', () => {
  let component: ReInstateAccountContainerComponent;
  let fixture: ComponentFixture<ReInstateAccountContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReInstateAccountContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReInstateAccountContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
