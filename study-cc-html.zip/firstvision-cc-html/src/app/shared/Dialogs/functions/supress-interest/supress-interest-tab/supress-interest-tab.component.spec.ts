import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressInterestTabComponent } from './supress-interest-tab.component';

describe('SupressInterestTabComponent', () => {
  let component: SupressInterestTabComponent;
  let fixture: ComponentFixture<SupressInterestTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressInterestTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressInterestTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
