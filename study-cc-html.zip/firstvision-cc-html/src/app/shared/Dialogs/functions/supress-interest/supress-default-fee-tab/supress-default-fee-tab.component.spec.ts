import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressInterestComponent } from './supress-interest.component';

describe('SupressInterestComponent', () => {
  let component: SupressInterestComponent;
  let fixture: ComponentFixture<SupressInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
