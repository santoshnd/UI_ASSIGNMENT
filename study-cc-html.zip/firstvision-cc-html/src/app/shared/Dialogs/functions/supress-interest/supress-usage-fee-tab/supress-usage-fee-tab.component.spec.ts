import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressUsageFeeTabComponent } from './supress-usage-fee-tab.component';

describe('SupressUsageFeeTabComponent', () => {
  let component: SupressUsageFeeTabComponent;
  let fixture: ComponentFixture<SupressUsageFeeTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressUsageFeeTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressUsageFeeTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
