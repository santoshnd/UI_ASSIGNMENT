import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressCardTabComponent } from './supress-card-tab.component';

describe('SupressCardTabComponent', () => {
  let component: SupressCardTabComponent;
  let fixture: ComponentFixture<SupressCardTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressCardTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressCardTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
