import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressMiscTabComponent } from './supress-misc-tab.component';

describe('SupressMiscTabComponent', () => {
  let component: SupressMiscTabComponent;
  let fixture: ComponentFixture<SupressMiscTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressMiscTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressMiscTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
