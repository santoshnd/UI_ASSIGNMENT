import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SupressDefaultFeeTabComponent } from './supress-default-fee-tab/supress-default-fee-tab.component';

@Component({
  selector: 'app-supress-interest',
  templateUrl: './supress-interest.component.html',
})
export class SupressInterestComponent implements OnInit {
  
  constructor() { }
  
  @Input() supressInterestFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();

  ngOnInit() { }

  public close(isOpened) {
   this.windowCloseFlag.emit(isOpened);
  }

}
