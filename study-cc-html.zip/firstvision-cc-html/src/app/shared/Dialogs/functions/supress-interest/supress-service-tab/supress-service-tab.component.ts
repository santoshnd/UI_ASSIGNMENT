import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { config } from '../../../../../../environments/config/config';
import { AccountFolderService } from '../../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-supress-service-tab',
  templateUrl: './supress-service-tab.component.html',
})
export class SupressServiceTabComponent implements OnInit {
  
  allConditions: { 'colon': string; };
  constructor(private accountFolderService: AccountFolderService) { }

  @Input() supressInterestFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  //@ViewChild("supressInterestComponent") supressInterestComponent: SupressInterestComponent;

  renderData: any;
  fieldValue: any;
  header: { [k: string]: any } = {};
  recordUrl = 'assets/json/mock/SuppressServiceCharges.json';
  htmlClass: { 'labelClass': string; 'valueClass': string; };

  ngOnInit() {
    this.onServiceCall();
   }

   onServiceCall(): any {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.recordUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((data: any) => {
      this.bindData(data);
    });    
  }

  bindData(arg0) {
    this.renderData = arg0.group.field;
    this.htmlClass = {
      'labelClass': 'col-sm-6',
      'valueClass': 'col-sm-6'
    };
    this.allConditions = {
      'colon':'true'
    }
  }
  
  setComponentReqHeader() {
    this.header['name'] = 'Fee Suppression';
    this.header['page_action'] = 'ReqInput';
    this.header['process_processName'] = 'Suppress Service Charges Function';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'PAGE';
  }
  
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
   }
}
