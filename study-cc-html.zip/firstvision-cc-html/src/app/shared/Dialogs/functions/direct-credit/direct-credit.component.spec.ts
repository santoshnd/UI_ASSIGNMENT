import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectCreditComponent } from './direct-credit.component';

describe('DirectCreditComponent', () => {
  let component: DirectCreditComponent;
  let fixture: ComponentFixture<DirectCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DirectCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
