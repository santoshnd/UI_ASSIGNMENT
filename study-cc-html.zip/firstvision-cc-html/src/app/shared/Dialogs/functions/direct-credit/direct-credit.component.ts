import { Component, OnInit } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-direct-credit',
  templateUrl: './direct-credit.component.html',
  styleUrls: ['./direct-credit.component.scss']
})
export class DirectCreditComponent implements OnInit {
  directCreditList: any;
  onDemandDirectCreditList: any;
  constructor(private accountFolderService: AccountFolderService) { }

  ngOnInit() {
    this.directCreditDetails();
    this.onDemandDirectDetails();
   }
  directCreditDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    const directCreditUrl = config.mockPath + 'directCreditDetails.json';
    this.accountFolderService.getAnyJson(directCreditUrl).subscribe(data => {
      this.binddirectCreditData(data);
    });
  }
  binddirectCreditData(arg0) {
    this.directCreditList = arg0.group;
  }
  onDemandDirectDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    const onDemandDirectUrl = config.mockPath + 'onDemandDirectCredit.json';
    this.accountFolderService.getAnyJson(onDemandDirectUrl).subscribe(data => {
      this.bindonDemandDirectData(data);
    });
  }
  bindonDemandDirectData(arg0) {
    this.onDemandDirectCreditList = arg0.group.field;
  }
}
