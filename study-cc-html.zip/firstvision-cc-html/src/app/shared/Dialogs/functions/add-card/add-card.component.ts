import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../../../services/data.service';
import { DataFormatter } from '../../../util/data.formatter';

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.scss']
})
export class AddCardComponent implements OnInit {
  cardHolderDetails: any[];
  addNewCardColumns: any;
  @Input() data: any;
  @Input() open: boolean = false;
  @Output() close = new EventEmitter<boolean>();

  dataFormatter = new DataFormatter;
  step = 1;
  isAddressDisabled: boolean;
  isWorkContactDisabled = true;
  isHomeContactDisabled = true;
  isMobileContactDisabled = true;
  isEmailContactDisabled = true;
  showCardTechnology = false;

  windowTitle = 'Add new card';
  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.getAddNewCardDetails();
    this.isAddressDisabled = true;
  }

  getAddNewCardDetails() {
    this.dataService.getGridConfig('addNewCard')
      .subscribe(gridConfig => {
        this.addNewCardColumns = gridConfig.columns;
        this.dataService.getAnyJson('assets/json/mock/addNewCard.json')
          .subscribe((res: any) => {
            this.cardHolderDetails = this.dataFormatter.parseGridData(
              res.group[1].rows.row, gridConfig.columns);
          });
      });
  }

  onPrimaryAddressCheck(checked) {
    if (checked) {
      this.isAddressDisabled = true;
    } else {
      this.isAddressDisabled = false;
    }
  }

  onContactHomeChange(event) {
    if (event.value === 'true') {
      this.isHomeContactDisabled = false;
    } else { this.isHomeContactDisabled = true; }
  }

  onContactWorkChnage(event) {
    this.isWorkContactDisabled = event.value === 'true' ? false : true;
  }

  onContactEmailChange(event) {
    this.isEmailContactDisabled = event.value === 'true' ? false : true;
  }

  onContactMobileChange(event) {
    this.isMobileContactDisabled = event.value === 'true' ? false : true;
  }



  public onClose() {
    this.close.emit();
    this.step = 1;
  }

}
