import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendLetterOptionDialogComponent } from './send-letter-option-dialog.component';

describe('SendLetterOptionDialogComponent', () => {
  let component: SendLetterOptionDialogComponent;
  let fixture: ComponentFixture<SendLetterOptionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendLetterOptionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendLetterOptionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
