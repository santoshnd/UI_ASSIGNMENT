import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-letter-option-dialog',
  templateUrl: './send-letter-option-dialog.component.html',
  styleUrls: ['./send-letter-option-dialog.component.scss']
})
export class SendLetterOptionDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
