import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';
import { DataFormatter } from '../../../util/data.formatter';

@Component({
  selector: 'app-fee-adjustment',
  templateUrl: './fee-adjustment.component.html',
  styleUrls: ['./fee-adjustment.component.scss']
})
export class FeeAdjustmentComponent implements OnInit {

  transcationColumns: any;
  transcationsList: any;
  dataFormatter = new DataFormatter();
  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  labelList = [
    { 'label': 'Fee Transactions' },
    { 'label': 'Please select the fee that you would like to update' },
    { 'label': 'Fee Detail' },
    { 'label': 'Fee Adjustment' },
  ];
  feeList =
   [{'label': 'Fee Description:', 'value': 'CASH ADVANCE FEE' },
    {'label': 'Amount: ', 'value': '15' },
    {'label': 'Plan Number:', 'value': '1001' },
    {'label': 'Sequence Number', 'value': '2' }];
  // end here

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.httpurl = 'assets/json/mock/transactionDetails.json';
    this.transcationsDetails();
  }
  transcationsDetails(): any {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];
    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data) {
    this.cd.detectChanges();
    // console.log(data.group[0].rows);
    this.transcationColumns = this.dataFormatter.extractColumns(data.group[0].rows.row[1].field);
    this.transcationsList = this.dataFormatter.parseGridData(
      data.group[0].rows.row, this.transcationColumns);
    this.transcationsList = [];
  }

}
