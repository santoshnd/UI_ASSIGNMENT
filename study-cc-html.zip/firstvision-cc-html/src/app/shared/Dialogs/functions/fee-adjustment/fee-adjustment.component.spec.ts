import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeeAdjustmentComponent } from './fee-adjustment.component';

describe('FeeAdjustmentComponent', () => {
  let component: FeeAdjustmentComponent;
  let fixture: ComponentFixture<FeeAdjustmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeeAdjustmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeeAdjustmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
