import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorisationRequestComponent } from './authorization-request.component';

describe('AuthorizationRequestComponent', () => {
  let component: AuthorisationRequestComponent;
  let fixture: ComponentFixture<AuthorisationRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthorisationRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorisationRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
