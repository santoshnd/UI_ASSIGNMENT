import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { DataService } from '../../../services/data.service';
import { DataFormatter } from '../../../util/data.formatter';
import { Observable } from 'rxjs/Observable';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-authorization-request',
  templateUrl: './authorization-request.component.html',
})
export class AuthorizationRequestComponent implements OnInit {
  creditPlanList: any;
  requestFieldGroup2: Observable<any>;
  requestFieldGroup1: Observable<any>;
  authorizationRequestData: any;
  authRequestColumns: any;
  fieldValue: any;
  header: { [k: string]: any } = {};
  htmlClass = {
    'labelClass': 'col-sm-6 text-blue',
    'valueClass': 'col-sm-6 pl-0'
  };
  dataFormatter = new DataFormatter();
  @Input() windowOpenFlag;
  @Output() windowCloseEmitter = new EventEmitter<any>();
  constructor(private accountFolderService: AccountFolderService) { }

  ngOnInit() {
    this.setComponentReqHeader();
    this.getAuthorizationGridData();
    this.getAuthorizationRequestData();
  }

  onClose() {
    // Currently handaled in child, need to handle in prarent.
    this.windowOpenFlag = !this.windowOpenFlag;
    this.windowCloseEmitter.emit();
  }

  getAuthorizationGridData() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.accountFolderService.getServiceData('assets/json/mock/authorizationRequestData.json', this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((res: any) => {
      this.authRequestColumns = this.dataFormatter.extractColumns(res.group[0].rows.row[0].field);
      this.authorizationRequestData = this.dataFormatter.parseGridData(
        res.group[0].rows.row, this.authRequestColumns);
      this.requestFieldGroup1 = res.group[1].rows.row[0].field;
    });
  }

  getAuthorizationRequestData() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.accountFolderService.getServiceData('assets/json/mock/authorizationRequest.json', this.fieldValue, this.header);
    this.accountFolderService.rewardData$
      .subscribe((res: any) => {
        this.requestFieldGroup2 = res.group.field;
      });
  }


  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

}

