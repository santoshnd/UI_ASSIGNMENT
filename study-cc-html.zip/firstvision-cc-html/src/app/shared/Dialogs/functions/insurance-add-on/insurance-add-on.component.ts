import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-insurance-add-on',
  templateUrl: './insurance-add-on.component.html',
  styleUrls: ['./insurance-add-on.component.scss']
})
export class InsuranceAddOnComponent implements OnInit {
  htmlClass: { 'valueClass': string; };
 // service inte var
 fieldValue: any;
 header: { [k: string]: any } = {};
 httpurl: string;
 // end here
  insuranceProductListList: any;
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  labelList = [
    { 'label': 'Insurance /Add on' },
    { 'label': 'Please Select a product that you want to enroll' },
    { 'label': 'Update details for the product to be enrolled' }];
  autoRenderLableList =
    [
      {
        'label': 'Enroll Age ',
        'control': 'Label',
        'value': '65'
      },
      {
        'label': 'Expire Age ',
        'control': 'Label',
        'value': '65'
      },
      {
        'label': 'Minimum Age ',
        'control': 'Label',
        'value': '18'
      },
      {
        'label': 'Product Party ',
        'control': 'Label',
        'value': '65'
      },
      {
        'label': 'Age ',
        'control': 'Label',
        'value': '37'
      },
      {
        'label': 'Effective Date ',
        'control': 'DateChooser',
        'value': '22/02/2013'
      },
      {
        'label': 'Mail Statement',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Do not send'
            },
            {
              'code': '1',
              'text': 'Always send'
            }
          ]
        }
      }, {
        'label': 'Mail Letter',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Do not send'
            },
            {
              'code': '1',
              'text': 'Always send'
            }
          ]
        }
      },
      {
        'label': 'Mail Letter Fee',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Charge letter fee '
            },
            {
              'code': '1',
              'text': ' Do not charge fee'
            }
          ]
        }
      },
      {
        'label': 'Sales Date ',
        'control': 'DateChooser',
        'value': '22/02/2013'
      },
      {
        'label': 'Source Code',
        'control': 'TextInputField',
        'value': '65'
      },
      {
        'label': 'Send letter',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Owner'
            },
            {
              'code': '1',
              'text': 'CoOwner'
            },
            {
              'code': '1',
              'text': 'Third'
            }
          ]
        }
      }
    ];
  ngOnInit() {
    this.htmlClass = {
      'valueClass': 'col-sm-3'
  };
  this.httpurl = 'assets/json/mock/insuranceProductList.json';
    this.insuranceProductListDetails();
  }

  insuranceProductListDetails(): any {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindinsuranceProductListData(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  bindinsuranceProductListData(data) {
    this.cd.detectChanges();
    this.insuranceProductListList = data.group.rows.row;
    // console.log('>>>>' + JSON.stringify(this.listOfActivationCardsList));
  }

}

