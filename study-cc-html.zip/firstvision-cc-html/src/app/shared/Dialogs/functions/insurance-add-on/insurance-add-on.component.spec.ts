import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuranceAddOnComponent } from './insurance-add-on.component';

describe('InsuranceAddOnComponent', () => {
  let component: InsuranceAddOnComponent;
  let fixture: ComponentFixture<InsuranceAddOnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsuranceAddOnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsuranceAddOnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
