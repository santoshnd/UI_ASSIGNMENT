import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-amend-insurance',
  templateUrl: './amend-insurance.component.html',
  styleUrls: ['./amend-insurance.component.scss']
})
export class AmendInsuranceComponent implements OnInit {
  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  // end here
  htmlClass: { 'valueClass': string; };
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }
  labelList = [
    { 'label': 'Insurance /Add-on' },
    { 'label': 'View and Update the information for enrolled product' }
  ];
  autoRenderLableList =
    [
      {
        'label': 'Mail Statement',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Active'
            },
            {
              'code': '1',
              'text': 'Inactive'
            },
            {
              'code': '1',
              'text': 'Cancelled'
            }
          ]
        }
      },
      {
        'label': 'Effective Date ',
        'control': 'DateChooser',
        'value': '22/02/2013'
      },
      {
        'label': 'Cancel Reason',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            { 'code': 'D', 'text': 'Delinquency' },
            { 'code': 'R', 'text': 'Manually Canceled at request of product party or customer' },
            { 'code': 'U', 'text': 'Manually canceled at request of Underwriter' },
            { 'code': 'A', 'text': 'Canceled as product party reached the policy expiration age' },
            { 'code': 'P', 'text': 'Manually canceled because the credit line or account was closed' },
            { 'code': 'T', 'text': 'TRUNC' },
            { 'code': 'X', 'text': 'Manually canceled for a miscellaneous reason' },
            { 'code': 'I', 'text': 'Canceled as product partys DOB does not meet min age' },
            { 'code': 'G', 'text': 'Canceled as product partys DOB does not meet enrollment age' }
          ]
        }
      },
      {
        'label': 'Source Code',
        'control': 'TextInputField',
        'value': 'N/A'
      },
      {
        'label': 'Product Party',
        'control': 'Label',
        'value': 'Owner'
      },
      {
        'label': 'Send letter',
        'control': 'Dropdown',
        'valueList': {
          'item': [
            {
              'code': '0',
              'text': 'Owner'
            },
            {
              'code': '1',
              'text': 'CoOwner'
            },
            {
              'code': '1',
              'text': 'Third'
            }
          ]
        }
      }
    ];

  ngOnInit() {
    this.httpurl = 'assets/json/mock/';
    this.htmlClass = {
      'valueClass': 'col-sm-3',
    };
    // this.sendInsuranceDetails();
  }

  sendInsuranceDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data) {
    this.cd.detectChanges();
    // console.log('>>>>' + JSON.stringify(data));
  }
}
