import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-balance-transfer',
  templateUrl: './balance-transfer.component.html',
  styleUrls: ['./balance-transfer.component.scss']
})
export class BalanceTransferComponent implements OnInit {
  channelList = [];
  creditPlanList: any;
  offerCodesList: any;
  header: { [k: string]: any } = {};
  credlitListUrl = 'assets/json/mock/creditCardPlanListing.json';
  offerCodeList = 'assets/json/mock/cMSOfferCodeMasterListing.json';
  fieldValue: { 'fieldName': string; 'isModified': string; 'value': string; }[];
  @Input() showWindow;
  @Output() windowCloseEmitter = new EventEmitter<any>();
  windowTitle = 'Balance Transfer';
  step = 1;
  constructor(private accountFolderService: AccountFolderService) { }

  ngOnInit() {
    this.setComponentReqHeader();
    this.getCreditPlanList();
    this.getOfferCodesList();
    this.createChannelList();
  }

  onClose() {
    // Currently handaled in child, need to handle in prarent.
    this.showWindow = !this.showWindow;
    this.windowCloseEmitter.emit();
  }

  getCreditPlanList() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.accountFolderService.getServiceData(this.credlitListUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$
      .subscribe((res: any) => {
        this.creditPlanList = res.group.rows.row;
      });
  }

  getOfferCodesList() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.accountFolderService.getServiceData(this.offerCodeList, this.fieldValue, this.header);
    this.accountFolderService.rewardData$
      .subscribe((res: any) => {
        this.offerCodesList = res.group.rows.row;
      });
  }

  onCancel() {
    this.onClose();
  }

  createChannelList() {
    this.channelList.push({ text: '01 - Internet', value: '01' });
    this.channelList.push({ text: '02 - Branch', value: '02' });
    this.channelList.push({ text: '03 - New accounts', value: '03' });
    this.channelList.push({ text: '04 - Telephone', value: '04' });
    this.channelList.push({ text: '05 - Paper', value: '05' });
  }


  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

}
