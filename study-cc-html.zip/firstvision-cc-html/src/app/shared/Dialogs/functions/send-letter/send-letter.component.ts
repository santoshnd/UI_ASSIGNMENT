import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-send-letter',
  templateUrl: './send-letter.component.html',
  styleUrls: ['./send-letter.component.scss']
})
export class SendLetterComponent implements OnInit {

  @Input() sendLetterFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
}
}
