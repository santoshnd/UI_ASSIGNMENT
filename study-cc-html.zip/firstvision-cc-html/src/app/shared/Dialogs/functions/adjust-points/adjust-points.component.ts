import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-adjust-points',
  templateUrl: './adjust-points.component.html',
})
export class AdjustPointsComponent implements OnInit {

  @Input() adjustPointsFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();

  constructor(private accountFolderService: AccountFolderService) { }

  fieldValue: any; schemeData:any; pointAccountData: any; transactionTypeData: any;
  accountGroupData: any; planTypeData: any;  planPriorityData: any; storeData: any;
  recordUrl = 'assets/json/mock/accountFolderTransaction.json';
  header: { [k: string]: any } = {};
  totalAdjustPoints: any;
  
  ngOnInit() {
    this.getData();
  }
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
  }

  getData() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.recordUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((data: any) => { 
      this.bindData(data);     
    });
  }

  bindData(data){
    this.pointAccountData = ['0000015215454614', '00000212411454154', '00000154541574199'];
    this.schemeData = ['Cab Scheme', 'Insurance', 'PPF'];
    this.transactionTypeData = ['CC', 'Amex', 'Visa'];
    this.accountGroupData = ['25', '63', '44'];
    this.planTypeData = ['plan1', 'plan2', 'plan3'];
    this.planPriorityData = ['teste', 'teste', 'teste'];
    this.storeData = ['store1', 'store1', 'store1'];
    this.totalAdjustPoints = 2514;
  }
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
}
