import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustPointsComponent } from './adjust-points.component';

describe('AdjustPointsComponent', () => {
  let component: AdjustPointsComponent;
  let fixture: ComponentFixture<AdjustPointsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdjustPointsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustPointsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
