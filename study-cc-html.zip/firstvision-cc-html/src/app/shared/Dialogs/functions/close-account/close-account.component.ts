import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-close-account',
  templateUrl: './close-account.component.html',
  styleUrls: ['./close-account.component.scss']
})
export class CloseAccountComponent implements OnInit {

  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  reasonCode = [];
  @Input() WindowOpenFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  referSection = true;
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
      this.closeAccountGetData();
  }
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
  closeAccountGetData() {
    this.httpurl = 'assets/json/ReasonCode.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];
    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.closeAccountData(data));
  }
  closeAccountData(data) {
    for (let i = 0; i <= data.vxRoot.group[1].field[0].valueList.item.length; i++) {
      this.reasonCode.push(data.vxRoot.group[1].field[0].valueList.item[i].text);
    }
  }
  public close(isOpened) {
    this.windowCloseFlag.emit(isOpened);
  }

}
