import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';
import { DataFormatter } from '../../../util/data.formatter';

@Component({
  selector: 'app-card-replacement',
  templateUrl: './card-replacement.component.html',
  styleUrls: ['./card-replacement.component.scss']
})
export class CardReplacementComponent implements OnInit {
  replaceCardList: any[];
  replaceCardColumns: any;
  replaceCardsList: any;
  dataFormatter = new DataFormatter();
  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  labelList = [
    { 'label': 'Replace Card(s)' },
    { 'label': 'Please select the card that you would like to replace' }
  ];
  // end here

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.httpurl = 'assets/json/mock/cardReplacement.json';
    this.replaceCardsDetails();
  }
  replaceCardsDetails(): any {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];
    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data) {
    this.cd.detectChanges();
    this.replaceCardColumns = this.dataFormatter.extractColumns(data.group.rows.row[0].field);
    this.replaceCardList = this.dataFormatter.parseGridData(
      data.group.rows.row, this.replaceCardColumns);
  }

}
