import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SupressLettersComponent } from './supress-letters.component';

describe('SupressLettersComponent', () => {
  let component: SupressLettersComponent;
  let fixture: ComponentFixture<SupressLettersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupressLettersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressLettersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
