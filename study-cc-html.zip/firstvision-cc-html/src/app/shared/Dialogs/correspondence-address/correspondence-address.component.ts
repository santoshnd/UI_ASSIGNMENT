import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-correspondence-address',
  templateUrl: './correspondence-address.component.html',
  styleUrls: ['./correspondence-address.component.scss']
})
export class CorrespondenceAddressComponent implements OnInit {

  private manageStatement;
  private country;
  @Output() openLookup = new EventEmitter<any>();
  referSection = true;
    constructor() { 
      this.country = ['India','UK','US','MP'];
      this.manageStatement =   ['No action; disregard alternate address', 'Active; send stmt to alt address until exp date',
      'Active; send stmt to both address until exp date', 'Rltnshp cust active; send stmt to alt address'];
    }
  

  ngOnInit() {
  }
  openLookupPopup(command){
    debugger
    this.openLookup.emit(command);
  }
}
