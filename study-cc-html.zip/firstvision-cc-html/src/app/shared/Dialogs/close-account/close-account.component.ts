import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-close-account',
  templateUrl: './close-account.component.html',
  styleUrls: ['./close-account.component.scss']
})
export class CloseAccountComponent implements OnInit {
  @Input() WindowOpenFlag: boolean ;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  referSection = true;
  constructor() { }

  ngOnInit() {
  }
  public close(isOpened: boolean) {
    this.windowCloseFlag.emit(isOpened);
}
}
