import { Component, OnInit, Input, EventEmitter, Output, SimpleChanges } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormatterUtil } from '../../util/formatterUtil';
import { OnChanges } from '@angular/core';
import { DataFormatter } from '../../util/data.formatter';
import { EventServiceService } from '../../services/event-service.service';

@Component({
  selector: 'app-statement-viewer',
  templateUrl: './statement-viewer.component.html',
  styleUrls: ['./statement-viewer.component.scss']
})
export class StatementViewerComponent implements OnInit, OnChanges {
  htmlClass: { 'labelClass': string; 'valueClass': string; };
  statementFooterDetails: any;
  statementHeaderDetails: any;
  statementHeaderColumns: any;
  statementFooterColumns: any;
  transactionsColumns: any;
  transactionsDetail: any;

  dataFormatter = new DataFormatter();
  @Input() data: any;
  @Input() open: boolean = false;
  @Output() close = new EventEmitter<boolean>();

  statementClosingDates = [];
  selectedClosingDate: any;
  constructor(private dataService: DataService, private eventservice: EventServiceService) {
  }

  ngOnInit() {
    this.htmlClass = {
      'labelClass': 'col-sm-5 text-blue',
      'valueClass': 'col-sm-4 text-right pl-0'
    };
    this.getStatementHeaderDetails();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.open.currentValue) {
      this.getStatementClosingDates();
      this.getStatementFooterDetails();
      this.getStatementTransactions();
    }
  }

  getStatementClosingDates() {
    this.dataService.getAnyJson('assets/json/mock/statementViewer.json')
      .subscribe((res: any) => {
        this.statementClosingDates = res.group.rows.row;
        // for (let i = 0; i < res.group.rows.row.length; i++) {
        //   const row = res.group.rows.row[i];
        //   const text = FormatterUtil.formatJulianToGregorianDate(row.formattedValue, 'DD/MM/YYYY');
        //   this.statementClosingDates.push({ text: text, value: row.formattedValue });
        // }
      });
  }


  getStatementHeaderDetails() {
    this.dataService.getAnyJson('assets/json/mock/statementHeader.json')
      .subscribe((res: any) => {
        this.statementHeaderDetails = res.group;
      });
  }

  getStatementTransactions() {
    this.dataService.getGridConfig('statementTransactions')
      .subscribe(gridConfig => {
        this.transactionsColumns = gridConfig.columns;
        this.dataService.getAnyJson('assets/json/mock/statementTransactions.json')
          .subscribe((res: any) => {
            const hasEmptyRows = this.checkEmptyTransactions(res.group[0].rows.row[0].field);
            if (!hasEmptyRows) {
              this.transactionsDetail = this.dataFormatter.parseGridData(
                res.group[0].rows.row, gridConfig.columns);
            } else {
              this.transactionsDetail = [];
            }
          });
      });
  }

  checkEmptyTransactions(field): boolean {
    let hasEmptyRows = false;
    if (field.find(x => x.value === 0 || x.value === null)) {
      hasEmptyRows = true;
    }
    return hasEmptyRows;
  }


  getStatementFooterDetails() {
    this.dataService.getAnyJson('assets/json/mock/statementFooter.json')
      .subscribe((res: any) => {
        this.statementFooterColumns = this.dataFormatter.extractColumns(res.group[0].rows.row[0].field);
        this.statementFooterDetails = this.dataFormatter.parseGridData(
          res.group[0].rows.row, this.statementFooterColumns);
      });
  }

  onClosingDateChange(event) {

  }


  onFunctionClick(event, functionName) {
    switch (functionName) {
      case 'verifyCard':
        this.eventservice.changeEvent({ verificationOpened: true, data: event });
        break;
      case 'blockCard':
        this.eventservice.changeEvent({ blockCard: true, data: event });
        break;
      case 'updateNumber':
        this.eventservice.changeEvent({ updateNumber: true, data: event });
        break;
      case 'addNote':
        this.eventservice.changeEvent({ addNote: true, data: event });
        break;
      default:
        alert('Sorry, that is not the correct selection');
    }
    //   this.eventservice.changeEvent({ verificationOpened:true, data: event });
  }

  public onClose() {
    this.close.emit();
  }

}
