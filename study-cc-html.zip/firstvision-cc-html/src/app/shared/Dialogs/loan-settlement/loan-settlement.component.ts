import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-loan-settlement',
  templateUrl: './loan-settlement.component.html',
  styleUrls: ['./loan-settlement.component.scss']
})
export class LoanSettlementComponent implements OnInit {
  @Input() inputData: any;
  @Input() WindowFlag: boolean = true;
  @Output() messageEvent = new EventEmitter<boolean>();
  constructor(private dataService: DataService) { }

  ngOnInit() {
  }
  public close(isOpened: boolean) {
    this.messageEvent.emit(isOpened);
  }
}
