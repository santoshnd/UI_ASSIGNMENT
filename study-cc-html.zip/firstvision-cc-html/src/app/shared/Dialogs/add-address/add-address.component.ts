import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.scss']
})
export class AddAddressComponent implements OnInit {
  @Output() openLookup = new EventEmitter<boolean>();
   @Input() WindowOpenFlag: boolean;
  @Output() messageEvent = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  public close(isOpened: boolean) {
    this.messageEvent.emit(isOpened);
}
openLookupFunction(command){
  debugger
  this.openLookup.emit(command);
}
}
