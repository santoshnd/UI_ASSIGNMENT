import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../../../modules/account-folder/account-folder.service';


@Component({
  selector: 'app-add-notes',
  templateUrl: './add-notes.component.html',
  styleUrls: ['./add-notes.component.scss']
})
export class AddNotesComponent implements OnInit {
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  addNoteLabel = 'Add Note';
  referSection = true;
  TopicItems: any = [
    {
      'code': '',
      'desc': '',
      'type': ''
    }
  ];
  topicData: any;
  buttonFlag = false;
  // Static function name.
  public FUNCTION_NAME: String = 'Add Note';
  private hasCustomNote: Boolean = false;
  public PriorityItems: Array<string> = ['None', 'Low', 'Medium', 'High']; // this variable will come from model
  @Input() WindowFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {

    this.addNotesGetData();
    /* this.dataService.getTopicDataJson()
        .subscribe(
        data => {
          this.bindTree(data);
        },
        err => console.error(err)
        ); */
  }
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
  addNotesGetData() {
    this.httpurl = 'assets/json/addNotesMock.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.addNotesData(data));
  }
  addNotesData(data: any) {
    this.topicData = data.vxRoot.group.rows.row;
    for (let i = 0; i <= this.topicData.length; i++) {
      if (data.vxRoot.group.rows.row[i].field[2].value === 'I' || data.vxRoot.group.rows.row[i].field[2].value === 'N') {
        this.TopicItems.push({
          'code': data.vxRoot.group.rows.row[i].field[0].value,
          'desc': data.vxRoot.group.rows.row[i].field[1].value,
          'type': data.vxRoot.group.rows.row[i].field[2].value,
        });
      }
    }
    // this.setNoteText(true);
    // this.updateRefer(value);
    this.cd.detectChanges();
  }
  /* setNoteText(setBySystem: Boolean = false) {
  
  } */
  updateRefer(value) {
    if (value.type === 'N') {
      this.referSection = true;
    } else {
      this.referSection = false;
    }
  }
  addNote_onClick(pageData) {
    console.log(pageData);
  }
  public close(isOpened: boolean) {
    this.windowCloseFlag.emit(isOpened);
  }
  receiveNoteText($event) {
    if ($event !== '') {
      this.buttonFlag = false;
    } else {
      this.buttonFlag = true;
    }
  }
  referralFlagCheck($event) {
    const referralFlaf = $event;
    if (referralFlaf === true) {
      this.addNoteLabel = 'Refer';
    } else {
      this.addNoteLabel = 'Add Note';
    }
  }
}
