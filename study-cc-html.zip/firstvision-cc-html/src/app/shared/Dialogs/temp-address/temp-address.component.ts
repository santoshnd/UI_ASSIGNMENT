import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TempAddress } from './tempAddress';

@Component({
  selector: 'app-temp-address',
  templateUrl: './temp-address.component.html',
  styleUrls: ['./temp-address.component.scss']
})
export class TempAddressComponent implements OnInit {
  private manageStatement;
  private country;
  private buttonFlag;
  private addNoteLabel;
  private addressModal;
  referSection = true;
  @Output() openLookup = new EventEmitter<any>();
  constructor() {
    this.addressModal = new TempAddress('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
    this.country = ['India', 'UK', 'US', 'MP'];
    this.manageStatement = ['No action; disregard alternate address', 'Active; send stmt to alt address until exp date',
      'Active; send stmt to both address until exp date', 'Rltnshp cust active; send stmt to alt address'];

    this.addressModal.country = this.country;
    this.addressModal.manageStatement = this.manageStatement;
  }



  ngOnInit() {
  }


  openLookupPopup(command) {
    debugger
    this.openLookup.emit(command);
  }
}

  // Add button function







