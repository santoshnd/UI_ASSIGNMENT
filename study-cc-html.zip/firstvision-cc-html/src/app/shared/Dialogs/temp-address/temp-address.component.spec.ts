import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempAddressComponent } from './temp-address.component';

describe('TempAddressComponent', () => {
  let component: TempAddressComponent;
  let fixture: ComponentFixture<TempAddressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempAddressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
