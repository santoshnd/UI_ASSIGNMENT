export class TempAddress {
    constructor(
        public firstName,
        public lastName,
        housename, housenumber, address1, address2, address3, address4, city, county, state,
        country, postalCode, manageStatement, startDate, endDate, postcodelookup
    ) {
    }
}
