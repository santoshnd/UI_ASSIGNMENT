import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-postcode-lookup',
  templateUrl: './postcode-lookup.component.html',
  styleUrls: ['./postcode-lookup.component.scss']
})
export class PostcodeLookupComponent implements OnInit {

  @Input() WindowLookupFlag : boolean;
  @Output() messageEvent = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  close(isOpened: boolean){
    this.messageEvent.emit(isOpened);
  }
}
