export class VxInputRoot {

    'VxInputRoot' = {
        'xmlns': 'http://com/fd/firstvision/vx/input',
        'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
        'targetNamespace': 'http://visionx.firstdata.com/test/VX.PRES.PROCESSOPTIONS.V001',
        'header': {
            'page': {
                'action': 'string',
                'name': 'string',
                'sequence': 'no',
                'copySequence': 'false'
            },
            'process': { 'processName': 'string' },
            'request': {
                'id': 'string',
                'type': 'string',
                'minimumData': 'string'
            },
            'nextprocess': {},
            'nextpage': {}
        },
        'msgOut': {
            'field': []
        }

    };
}

