import { TestBed, inject } from '@angular/core/testing';

import { HttpServletService } from './http-servlet.service';

describe('HttpServletService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpServletService]
    });
  });

  it('should be created', inject([HttpServletService], (service: HttpServletService) => {
    expect(service).toBeTruthy();
  }));
});
