import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

@Injectable()
export class HttpServletService {

  constructor(private _http: HttpClient) {
  }


  getHttp(url, param): Observable<any> {
    return this._http
      .get<any>(url)
      .do(data => this.responseData(data))
      .catch(this.handleError);
  }

  private responseData(data_) {
    return data_;
  }

  private handleError(error: HttpErrorResponse) {
    // console.log(error);
    let errorMessage = '';
    if (error.error instanceof Error) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${error.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${error.status}, error message is: ${error.message}`;
    }
    console.log(errorMessage);
    return Observable.throw(errorMessage);
  }

}
