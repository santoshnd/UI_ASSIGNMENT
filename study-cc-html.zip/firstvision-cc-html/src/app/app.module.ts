import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { BasetemplateComponent } from './shared/templates/basetemplate/basetemplate.component';
import { LabelComponent } from './shared/components/controls/label/label.component';
import { CsConfigService } from './shared/services/csConfig.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ServiceInterceptor } from './shared/services/service-interceptor';
import { Config } from './shared/config/config.service';
import { HomeModule } from './modules/home/home.module';
import { LangService } from './shared/services/lang-service';
// import {PopoverModule} from 'ngx-popover';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    HomeModule,
    //    PopoverModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: ServiceInterceptor,
    multi: true,
  }, { provide: CsConfigService, useFactory: () => CsConfigService.getInstance('assets/configs/csConfig.json') },
  { provide: Config, useFactory: () => Config.getInstance('assets/configs/appConfig.json') },
    { provide: LangService, useFactory: () => LangService.getInstanceLang('assets/json/mock/lang/customerCare_EN.json') }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
