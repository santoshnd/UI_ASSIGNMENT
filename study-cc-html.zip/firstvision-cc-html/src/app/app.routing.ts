import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountLookupModule } from './modules/account-lookup/account-lookup.module';
import { AccountFolderModule } from './modules/account-folder/account-folder.module';
import { HomeModule } from './modules/home/home.module';

const routes: Routes = [
  { path: 'home', loadChildren: () => HomeModule },
  { path: 'account-folder', loadChildren: () => AccountFolderModule },
  { path: '', redirectTo: 'home', pathMatch: 'full'}
  //  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
