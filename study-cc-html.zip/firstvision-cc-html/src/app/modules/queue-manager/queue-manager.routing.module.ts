import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QManagerComponent } from './queue-manager/queue-manager.component';
import { AccountFolderModule } from '../account-folder/account-folder.module';

const routes: Routes = [
  {
    path: '', component: QManagerComponent,
    children: [{
      path: 'account-folder', loadChildren: () => AccountFolderModule
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QManagerRoutingModule { }
