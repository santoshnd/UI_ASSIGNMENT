import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QManagerComponent } from './queue-manager/queue-manager.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { QManagerRoutingModule } from './queue-manager.routing.module';
import { DataService } from '../../shared/services/data.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    GridModule,
    DatePickerModule,
    FormsModule,
    QManagerRoutingModule
  ],
  declarations: [QManagerComponent],
  providers: [DataService]
})
export class QManagerModule { }
