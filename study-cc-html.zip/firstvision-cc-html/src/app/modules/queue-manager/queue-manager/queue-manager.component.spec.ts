import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QManagerComponent } from './queue-manager.component';

describe('QManagerComponent', () => {
  let component: QManagerComponent;
  let fixture: ComponentFixture<QManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
