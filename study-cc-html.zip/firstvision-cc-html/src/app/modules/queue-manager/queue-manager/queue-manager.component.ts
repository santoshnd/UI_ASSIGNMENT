import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { DataService } from '../../../shared/services/data.service';

@Component({
  selector: 'app-queue-manager',
  templateUrl: './queue-manager.component.html',
  styleUrls: ['./queue-manager.component.scss']
})
export class QManagerComponent implements OnInit {

  public gridData: any;
  public qTypeList: Array<string> = ['ALL', 'PENDING', 'REFERRAL'];
  public qItmTypeList: Array<string> = ['ALL', 'MONETARY-TYPE', 'NON-MONETARY-TYPE'];
  public gridQItmList: any[];
  public gridNoteList: any[];
  public bzUnit: string;
  public bzUnits: string[];
  public action: string;
  public actions: string[];

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.setBUDropdownData();
    this.setActionsDropdownData();
    this.getQItemListData();
    this.getQNoteListData();

  }

  getQItemListData() {
    this.dataService.getQMgrItmListJson()
    .subscribe(
      data => {
        this.setQItmData(data);
      },
      err => {
        console.log(err);
      }
    );
  }

  getQNoteListData() {
    this.dataService.getQMgrNoteListJson()
    .subscribe(
      data => {
        this.setQNoteData(data);
      },
      err => {
        console.log(err);
      }
    );
  }

  setQItmData(data) {
    this.gridQItmList = data.vxRoot.group[0].rows.row;
  }
  setQNoteData(data) {
    this.gridNoteList = data.vxRoot.group[0].rows.row;
  }

  setBUDropdownData() {
    // todo: remove the mock data
    this.bzUnits = ['Please Select...', 'BANK OF EMEA'];
    this.bzUnit = 'Please Select...';
  }
  setActionsDropdownData() {
    // todo: remove the mock data
    this.actions = ['Please Select', 'EMAIL ADDR CHANGE'];
    this.action = 'Please Select';
  }
}

