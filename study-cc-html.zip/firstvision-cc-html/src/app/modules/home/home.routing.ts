import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { HomeComponent } from './home.component';
import { AccountLookupModule } from '../account-lookup/account-lookup.module';
import { QManagerModule } from '../queue-manager/queue-manager.module';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [{
      path: '', redirectTo: 'account-lookup', pathMatch: 'full'
    },
    {
      path: 'account-lookup', loadChildren: () => AccountLookupModule
    },
    {
      path: 'queue-manager', loadChildren: () => QManagerModule
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }

