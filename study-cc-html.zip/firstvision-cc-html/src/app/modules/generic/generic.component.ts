import { Component, OnInit } from "@angular/core";
import { WidgetLibraryService } from "angular2-json-schema-form";
import { DataService } from "../../shared/services/data.service";

import { DropdownComponent } from "../../shared/components/controls/dropdown/dropdown.component";
import { HeaderComponent } from "../../shared/widgets/header/header.component";
import {
  Ng4LoadingSpinnerModule,
  Ng4LoadingSpinnerService
} from "ng4-loading-spinner";
import { AccountLookupComponent } from "../account-lookup/account-lookup.component";

@Component({
  selector: "app-generic",
  templateUrl: "./generic.component.html",
  styleUrls: ["./generic.component.scss"]
})
export class GenericComponent implements OnInit {
  exampleSchema: { type: string; properties: {} };
  exampleData: { type: string; properties: {} };
  exampleLayout: any;
  configurations: any;

  ngOnInit(): void {
    this.spinnerService.show();

    setTimeout(() => {
      this.dataservice.getConfig().subscribe((data: any) => {
        //this.dataMapping(data);
        this.spinnerService.hide();
      });
    }, 1000);

    this.exampleSchema = {
      type: "object",
      properties: {}
    };
  }

  constructor(
    private widgetLibrary: WidgetLibraryService,
    private dataservice: DataService,
    private spinnerService: Ng4LoadingSpinnerService
  ) {
    widgetLibrary.registerWidget("app-header", HeaderComponent);
    widgetLibrary.registerWidget("app-account-lookup", AccountLookupComponent);
    widgetLibrary.getAllWidgets();
  }
  // dataMapping(data) {
  //   this.configurations = data;
  //   for (
  //     let i = 0;
  //     i < this.configurations.ParameterManagement.widgets.length;
  //     i++
  //   ) {
  //     if (
  //       this.configurations.ParameterManagement.widgets[i].component ===
  //       "HeaderComponent"
  //     ) {
  //       this.configurations.ParameterManagement.widgets[i].type = "app-header";
  //     }
  //   }

  //   this.exampleLayout = this.configurations.ParameterManagement.widgets;
  // }
}
