import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  JsonSchemaFormModule,
  Bootstrap4FrameworkModule,
  JsonSchemaFormService,
  FrameworkLibraryService,
  WidgetLibraryService,
  Framework,
  Bootstrap4Framework
} from 'angular2-json-schema-form';
import { DropdownComponent } from '../../shared/components/controls/dropdown/dropdown.component';
import { TextBoxComponent } from '../../shared/components/controls/text-box/text-box.component';
import { PasswordComponent } from '../../shared/components/controls/password/password.component';
import { BrowseTextComponent } from '../../shared/components/controls/browse-text/browse-text.component';
import { LabelComponent } from '../../shared/components/controls/label/label.component';
import { GenericComponent } from './generic.component';
import { HttpClientModule } from '@angular/common/http';
import { BasetemplateComponent } from '../../shared/templates/basetemplate/basetemplate.component';
import { ImageComponent } from '../../shared/components/controls/image/image.component';
import { Broadcaster } from '../../shared/services/event.broadcaster';
import { DataService } from '../../shared/services/data.service';
import { HeaderComponent } from '../../shared/widgets/header/header.component';
import { EventServiceService } from '../../shared/services/event-service.service';
import { ButtonComponent } from '../../shared/components/controls/button/button.component';
import { AlertService } from '../../shared/services/alert.service';
import { AlertsComponent } from '../../shared/components/controls/alerts/alerts.component';
import { CheckBoxComponent } from '../../shared/components/controls/checkbox/checkbox.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PUIModelLocator } from '../../shared/models/PUIModelLocator';
import { RequestVO } from '../../shared/models/VO/RequestVO';
import { FieldVO } from '../../shared/models/VO/FieldVO';
import { RequestFormat } from '../../shared/services/RequestFormat.service';
import { ServerFactory } from '../../shared/services/serverFactor.service';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule, DialogsModule } from '@progress/kendo-angular-dialog';

import { GridModule } from '@progress/kendo-angular-grid';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridComponent } from '../../shared/components/controls/grid/grid.component';
import { WindowManagerComponent } from '../../shared/widgets/window-manager/window-manager.component';
import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DateRangeComponent } from '../../shared/components/controls/date-range/date-range.component';
import { RadioGroupComponent } from '../../shared/components/controls/radio-group/radio-group.component';

@NgModule({
  imports: [
    CommonModule,
    Bootstrap4FrameworkModule,
    ButtonsModule,
    DialogsModule,
    HttpClientModule,
    {
      ngModule: JsonSchemaFormModule,
      providers: [
        JsonSchemaFormService,
        FrameworkLibraryService,
        WidgetLibraryService,
        { provide: Framework, useClass: Bootstrap4Framework, multi: true }
      ]
    },
    FormsModule,
    ReactiveFormsModule,
    GridModule,
    DatePickerModule,
    DropDownsModule,
    Ng4LoadingSpinnerModule.forRoot(),

  ],
  declarations: [
    DropdownComponent,
    WindowManagerComponent,
    HeaderComponent,
    TextBoxComponent,
    PasswordComponent,
    BrowseTextComponent,
    DateRangeComponent,
    RadioGroupComponent,
    LabelComponent,
    BasetemplateComponent,
    ImageComponent,
    ButtonComponent,
    AlertsComponent,
    CheckBoxComponent,
    GridComponent,
  ],

  entryComponents: [
    DropdownComponent,
    AlertsComponent,
    HeaderComponent,
    TextBoxComponent,
    PasswordComponent,
    BrowseTextComponent,
    DateRangeComponent,
    RadioGroupComponent,
    LabelComponent,
    BasetemplateComponent,
    ImageComponent,
    ButtonComponent,
    CheckBoxComponent,
  ],
  providers: [
    Broadcaster,
    DataService,
    EventServiceService,
    AlertService,
    PUIModelLocator,
    RequestVO,
    FieldVO,
    RequestFormat,
    ServerFactory,
    Ng4LoadingSpinnerService
  ]

})
export class GenericModule {

}
