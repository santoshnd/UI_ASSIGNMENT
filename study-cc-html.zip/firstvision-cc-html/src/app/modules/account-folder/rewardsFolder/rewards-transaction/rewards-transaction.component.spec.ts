import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardsTransactionComponent } from './rewards-transaction.component';

describe('RewardsTransactionComponent', () => {
  let component: RewardsTransactionComponent;
  let fixture: ComponentFixture<RewardsTransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardsTransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardsTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
