import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rewards-transaction',
  templateUrl: './rewards-transaction.component.html',
  styleUrls: ['./rewards-transaction.component.scss']
})
export class RewardsTransactionComponent implements OnInit {

  recenttransactionData = [];
  constructor() { }

  ngOnInit() {
  }

}
