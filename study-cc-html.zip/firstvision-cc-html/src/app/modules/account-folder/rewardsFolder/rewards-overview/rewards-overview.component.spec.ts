import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardsOverviewComponent } from './rewards-overview.component';

describe('RewardsOverviewComponent', () => {
  let component: RewardsOverviewComponent;
  let fixture: ComponentFixture<RewardsOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardsOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardsOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
