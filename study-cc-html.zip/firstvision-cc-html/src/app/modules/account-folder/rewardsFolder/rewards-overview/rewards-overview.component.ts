import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-rewards-overview',
  templateUrl: './rewards-overview.component.html',
  styleUrls: ['./rewards-overview.component.scss']
})
export class RewardsOverviewComponent implements OnInit {

  redeemPointsFlag: boolean;
  adjustPointsFlag: boolean;
  balanceSummeryData: any;
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  componenetData: any;
  htmlClass: any;
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) {
    this.htmlClass = {
      'labelClass': 'col-sm-7 labelclass pl-3 px-0',
      'valueClass': 'col-sm-5 grayFormItemLabel'
    };

  }

  ngOnInit() {
    this.balanceSummeryDetails();
  }

  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  balanceSummeryDetails(): any {
    this.httpurl = 'assets/json/mock/balanceSummery.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindBalanceSummeryData(data));
  }

  bindBalanceSummeryData(data) {
    this.componenetData = data.group.field;
  }

  linkfunction(functionName) {
    switch (functionName) {
        case 'adjustPoints':
            this.adjustPointsFlag = !this.adjustPointsFlag;
            break;  
        case 'redeemPoints':
            this.redeemPointsFlag = !this.redeemPointsFlag;
            break;     
        default:
          alert('Sorry, that is not the correct selection');
      }
  }
  
  // componenetData.vxRoot.group.field
}
