import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountFolderComponent } from './account-folder.component';
import { AccountFolderRoutingModule } from './account-folder.routing';
import { FormsModule } from '@angular/forms';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { GridModule } from '@progress/kendo-angular-grid';
import { DataService } from '../../shared/services/data.service';
import { AccountFolderService } from './account-folder.service';
import { NotesAndHistoryComponent } from './notes-and-history/notes-and-history.component';
import { OverviewComponent } from './overview/overview.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { LoanSettlementComponent } from '../../shared/Dialogs/loan-settlement/loan-settlement.component';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DemographicsComponent } from './demographics/demographics.component';
import { BasetemplateComponent } from '../../shared/templates/basetemplate/basetemplate.component';
import { LinkLabelComponent } from '../../shared/components/controls/link-label/link-label.component';
import { RewardsComponent } from './rewards/rewards.component';
import { RewardsOverviewComponent } from './rewardsFolder/rewards-overview/rewards-overview.component';
import { RewardsTransactionComponent } from './rewardsFolder/rewards-transaction/rewards-transaction.component';
import { LabelComponent } from '../../shared/components/controls/label/label.component';
import { OffersComponent } from './offers/offers.component';
import { AmendBillingCycleComponent } from './relationship/amend-billing-cycle/amend-billing-cycle.component';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropdownComponent } from '../../shared/components/controls/dropdown/dropdown.component';
import { ReferralNoteSectionComponent } from '../../shared/components/referral-note-section/referral-note-section.component';
import { ManualReferralSectionComponent } from '../../shared/components/manual-referral-section/manual-referral-section.component';
// import { DatePickerComponent } from '@progress/kendo-angular-dateinputs/dist/es2015/datepicker/datepicker.component';
import { DatePipe } from '@angular/common';
import { EventServiceService } from '../../shared/services/event-service.service';
import { FormsWizardModule } from '../../shared/templates/multi-form-wizard/form-wizard.module';
import { AddCardComponent } from '../../shared/Dialogs/functions/add-card/add-card.component';
import { CardViewerComponent } from './dialogs/card-viewer/card-viewer.component';
import { StatementViewerComponent } from './dialogs/statement-viewer/statement-viewer.component';
import { CardActivationComponent } from './dialogs/card-activation/card-activation.component';
// import { DatePickerModule } from '@progress/kendo-angular-dateinputs/dist/es2015/datepicker/datepicker.module';
import { DirectCreditComponent } from '../../shared/Dialogs/functions/direct-credit/direct-credit.component';
import { TextBoxComponent } from '../../shared/components/controls/text-box/text-box.component';
import { ApplyBlockComponent } from './relationship/apply-block/apply-block.component';

import { PinManangementComponent } from './overview/dialogues/pin-manangement/pin-manangement.component';
import { PinRequestComponent } from './overview/dialogues/pin-request/pin-request.component';
import { PinCountResetComponent } from './overview/dialogues/pin-count-reset/pin-count-reset.component';
import { PostcodeLookupComponent } from '../../shared/Dialogs/postcode-lookup/postcode-lookup.component';
import { CloseAccountComponent } from '../../shared/Dialogs/functions/close-account/close-account.component';
import { SendLetterComponent } from '../../shared/Dialogs/functions/send-letter/send-letter.component';
// tslint:disable-next-line:max-line-length
import { SendLetterOptionDialogComponent } from '../../shared/Dialogs/functions/send-letter-option-dialog/send-letter-option-dialog.component';
// tslint:disable-next-line:max-line-length
import { ReInstateAccountContainerComponent } from '../../shared/Dialogs/functions/re-instate-account-container/re-instate-account-container.component';
// import { SkipPaymentComponent } from '../../shared/Dialogs/functions/skip-payment/skip-payment.component';
import { LetterSectionComponent } from '../../shared/components/letter-section/letter-section.component';
import { AddNotesComponent } from '../../shared/Dialogs/add-notes/add-notes.component';
import { PopoverModule } from 'ngx-popover';
import { AddAddressComponent } from '../../shared/Dialogs/add-address/add-address.component';
import { TempAddressComponent } from '../../shared/Dialogs/temp-address/temp-address.component';
import { CorrespondenceAddressComponent } from '../../shared/Dialogs/correspondence-address/correspondence-address.component';
import { VxInputRoot } from '../../shared/servlet/shared-object';
import { HttpServletService } from '../../shared/servlet/http-servlet.service';
import { RewardStatementComponent } from './dialogs/reward-statement/reward-statement.component';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { NoteSectionComponent } from '../../shared/components/note-section/note-section.component';
import { AuthorizationRequestComponent } from '../../shared/Dialogs/functions/authorization-request/authorization-request.component';
// import { AccountHistoryViewerComponent } from './dialogs/account-history-viewer/account-history-viewer.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { InsuranceAddOnComponent } from '../../shared/Dialogs/functions/insurance-add-on/insurance-add-on.component';
import { DateComponent } from '../../shared/components/controls/date/date.component';
import { AmendInsuranceComponent } from '../../shared/Dialogs/functions/amend-insurance/amend-insurance.component';
import { CardReplacementComponent } from '../../shared/Dialogs/functions/card-replacement/card-replacement.component';
import { FeeAdjustmentComponent } from '../../shared/Dialogs/functions/fee-adjustment/fee-adjustment.component';
import { BlockAccountComponent } from '../../shared/Dialogs/functions/block-account/block-account.component';
import { FilterD4Component } from '../../shared/components/controls/filter-d4/filter-d4.component';
import { BalanceTransferComponent } from '../../shared/Dialogs/functions/balance-transfer/balance-transfer.component';
import { MoneyTransferComponent } from '../../shared/Dialogs/functions/money-transfer/money-transfer.component';
import { SupressInterestComponent } from '../../shared/Dialogs/functions/supress-interest/supress-interest.component';
import { SupressInterestTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-interest-tab/supress-interest-tab.component';
import { SupressDefaultFeeTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-default-fee-tab/supress-default-fee-tab.component'; 
import { SupressUsageFeeTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-usage-fee-tab/supress-usage-fee-tab.component';
import { SupressCardTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-card-tab/supress-card-tab.component';
import { SupressServiceTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-service-tab/supress-service-tab.component';
import { SupressMiscTabComponent } from '../../shared/Dialogs/functions/supress-interest/supress-misc-tab/supress-misc-tab.component';
import { SupressLettersComponent } from '../../shared/Dialogs/functions/supress-letters/supress-letters.component';
import { CheckBoxComponent } from '../../shared/components/controls/checkbox/checkbox.component';
//import { CreditAdjustmentComponent } from '../../shared/Dialogs/functions/credit-adjustment/credit-adjustment.component';
//import { CADebitReversalComponent } from '../../shared/Dialogs/functions/credit-adjustment/debit-reversal/ca-debit-reversal.component';
import { RedeemPointsComponent } from '../../shared/Dialogs/functions/redeem-points/redeem-points.component';
import { AdjustPointsComponent } from '../../shared/Dialogs/functions/adjust-points/adjust-points.component';


@NgModule({
  imports: [
    CommonModule,
    AccountFolderRoutingModule,
    FormsModule,
    LayoutModule,
    GridModule,
    DialogsModule,
    WindowModule,
    DatePickerModule, PopoverModule,
    FormsWizardModule
  ],
  declarations: [AccountFolderComponent, OverviewComponent, NotesAndHistoryComponent, RelationshipComponent,
    BasetemplateComponent, LinkLabelComponent, RelationshipComponent, LoanSettlementComponent, LabelComponent,
    CardViewerComponent, StatementViewerComponent, CardActivationComponent, ReferralNoteSectionComponent,
    AddAddressComponent, PostcodeLookupComponent, TempAddressComponent, CorrespondenceAddressComponent,
    PostcodeLookupComponent, ApplyBlockComponent, PinManangementComponent, OffersComponent, AmendInsuranceComponent,
    DirectCreditComponent, TextBoxComponent, DropdownComponent, PinRequestComponent, PinCountResetComponent,
    ReferralNoteSectionComponent, DropdownComponent, DemographicsComponent, InsuranceAddOnComponent, DateComponent,
    ManualReferralSectionComponent, RewardsOverviewComponent, RewardsTransactionComponent, SendLetterOptionDialogComponent
    , LetterSectionComponent, CloseAccountComponent, SendLetterComponent, AddNotesComponent, CardReplacementComponent,
    AuthorizationRequestComponent, FilterD4Component, AddCardComponent, MoneyTransferComponent, NoteSectionComponent,
    // SkipPaymentComponent
    RewardsComponent, ReInstateAccountContainerComponent, RewardStatementComponent, FeeAdjustmentComponent,
    BalanceTransferComponent,
    // AccountHistoryViewerComponent
    TransactionsComponent, BlockAccountComponent,
    SupressMiscTabComponent,SupressServiceTabComponent,SupressCardTabComponent,SupressUsageFeeTabComponent,SupressDefaultFeeTabComponent,SupressInterestTabComponent,SupressInterestComponent,
    SupressLettersComponent, AdjustPointsComponent, RedeemPointsComponent, CheckBoxComponent],

  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [AccountFolderService, DataService, DatePipe, VxInputRoot, HttpServletService, EventServiceService],
  entryComponents: [LinkLabelComponent, LabelComponent, TextBoxComponent, DropdownComponent,
    DateComponent, FeeAdjustmentComponent, FilterD4Component, CheckBoxComponent]
})
export class AccountFolderModule { }
