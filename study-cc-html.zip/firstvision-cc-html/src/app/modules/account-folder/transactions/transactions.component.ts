import { Component, OnInit } from '@angular/core';
import { DataFormatter } from '../../../shared/util/data.formatter';
import { AccountFolderService } from '../account-folder.service';
import { HttpServletService } from '../../../shared/servlet/http-servlet.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit {

  dataFormatter = new DataFormatter();
  gridData: any;
  gridPopupContent: any;
  fieldValue: any;
  transactionsColumns: any;
  header: { [k: string]: any } = {};
  recordUrl = 'assets/json/mock/accountFolderTransaction.json';
  popupUrl = 'assets/json/mock/account-folder-transaction-details.json';
  constructor(private accountFolderService: AccountFolderService, ) {
  }

  ngOnInit() {
    this.getRecentTransaction();
  }

  getRecentTransaction() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.recordUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((data: any) => {
      this.transactionsColumns = this.dataFormatter.extractColumns(data.group[0].rows.row[0].field);
      this.bindRecentTransaction(data.group[0].rows.row, this.transactionsColumns);
    });
  }

  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  bindRecentTransaction(data, columns) {
    this.gridData = this.dataFormatter.parseGridData(data, columns);
  }

  setDetailsIcon(data: any): string {
    let source = '';
    if (data.field === 'TransactionDetails') {
      source = 'assets/images/icons/credit.gif';
    }
    else {
      source = 'assets/images/icons/debit.gif';
    }
    return source;
  }

  getPopupContent(data: any) {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.popupUrl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe((data: any) => {
      this.gridPopupContent = data.group.field;
    });
  }
}
