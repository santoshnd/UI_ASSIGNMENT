import { Component, OnInit } from '@angular/core';
import { config } from '../../../environments/config/config';
import { AccountFolderService } from './account-folder.service';
import { DataService } from '../../shared/services/data.service';
import { CSState } from '../../shared/models/CSState';
import { Config } from '../../shared/config/config.service';
import { Router } from '@angular/router';

// import { CurrencyAttributes } from '../../shared/util/currencyAttributes';

@Component({
    selector: 'app-account-folder',
    templateUrl: './account-folder.component.html',
    styleUrls: ['./account-folder.component.scss']
})
export class AccountFolderComponent implements OnInit {
    amendInsuranceWindowOC: any;
    statementWindowOC: any;
    isResizable: Boolean = false;
    windowOpened: Boolean;
    windowOpenedReward: Boolean;
    RELEASE_EMEA: String;
    RELEASE_BARCLAYS: String;
    RELEASE_BASE: String;
    currentState: string;
    // header fields that get set by IDV when window is created.
    callerName: String;
    callerAssociation: String;
    cardName: String;
    cardAssociation: String;
    cardNumber: String;

    // required fields, these are also set by IDV but are used throughout the account
    // folder and all of its child windows.
    orgDescription: String = '';

    // global account folder level flags set typically by child windows to alter default behaviour
    verifiedLevel: Number = 1;
    overviewData: any;
    statementData: any;
    authorizedTabs: any;
    _orgNumber: String;
    _accountNumber: String;
    isFunctionsLoaded: Boolean = false;
    _logoNumber: String;
    availableCredit: String;
    showOverlimit: Boolean = false;
    overviewDataModel: any;
    block_codeDetail: any;
    block_dates: String = '';
    dateCreditLimitExp: any = 0;
    availableFunds: String = '';
    dateFundsUpdated: String = '';
    timeFundsUpdated: String = '';
    // Flag to show account overview data or debit account overview data
    showOverview: Boolean = true;
    showCreditLimit: Boolean = false;
    isVisible: Boolean;
    showAccountFolder = true;
    translationUtil: any;
    // To capture the account status for card lost stolen requirement
    accountStatus: any = '';
    gridData: any;
    releaseType: any;

    // currencySymbol: string = CurrencyAttributes.currSymbol();
    constructor(private accountFolderService: AccountFolderService, private router: Router) {
        this.releaseType = Config.releaseType;
        this.RELEASE_BASE = Config.RELEASE_BASE;
        this.RELEASE_EMEA = Config.RELEASE_EMEA;
        this.RELEASE_BARCLAYS = Config.RELEASE_BARCLAYS;
    }

    ngOnInit() {
        //  this.gridData = this.sampleProducts;
        // const accountOverviewUrl = config.mockPath + 'accountSummery.json';
        // this.accountFolderService.getAnyJson(accountOverviewUrl).subscribe(overviewData => {
        //     this.extractField(overviewData);
        // },
        //     err => console.error(err));
    }
    extractField(overviewData) {
        // console.log(overviewData);
    }

    showDefaultTab(id: string): void {
        // if (CSState.showDefaultTab.length > 0 && CSState.showDefaultTab == id) {
        //  const defaultTabIndex: Number = tabs.getChildIndex(tabs.getChildByName(CSState.showDefaultTab)); // Loan Tab or Relationship tab
        //     if (defaultTabIndex && defaultTabIndex > -1) {
        //         if (tabs.contains(tabs.getChildByName(CSState.showDefaultTab)) && tabs.getChildAt(defaultTabIndex).visible) {
        //             // this will ensure Entitlment check is not voilated
        //             tabs.selectedIndex = defaultTabIndex;
        //         }
        //     }
        // }
    }

    onCloseWindow() {
        this.showAccountFolder = !this.showAccountFolder;
        this.router.navigateByUrl('/home/account-lookup');

    }

    getHelpLink() {
        // return ConfigService.getInstance().custSvcHelpURL + CSHelpURLUtility.getHelpLink('PageLabel', 'AccountFolder') + ".htm";
    }

    load(): void {
        this._orgNumber = CSState.accountOrgNumber;
        this._accountNumber = CSState.accountNumber;
        this._logoNumber = CSState.accountLogo;

        // load function to successfully launch the functions from IDVerify. ashitosh help
        /** temp comment remove once u resume code
        loadFunctions();
        */
        // load function limits
        /** temp comment remove once u resume code
        loadFunctionsLimits();
        */
        // future use
        // load dynamic properties to CSDynamicParameters class
        // loadParameters();
    }
    onCreationComplete(): void {
        // load the account statements.
        /** temp comment remove once u resume code
        loadStatement();
        */
        // disable the accounts and account lookup windows.
        switch (this.releaseType) {
            case this.RELEASE_BASE: {
                this.currentState = 'baseOverviewEnabled';
                // overviewDataModel = new StandardOverviewDataModel();
                break;
            }
            case this.RELEASE_BARCLAYS:
                this.currentState = 'overviewEnabled';
                break;
            case this.RELEASE_EMEA:
                this.currentState = 'overviewEnabled';
                break;
            default:
                this.currentState = 'overviewEnabled';
        }
        if (this.showOverview) {
            // this.currentState = "overviewEnabled";
            /** temp comment remove once u resume code
            this.overviewDataModel = new StandardOverviewDataModel();
            */
            // overview.setDisplayedFunctions();
        } else if (!this.showOverview && CSState.logoCardType == 'D') {
            // debitoverview.setDisplayedFunctions();
            this.currentState = 'debitOverviewEnabled';
            /** temp comment remove once u resume code
            this.overviewDataModel = new DebitOverviewDataModel();
            */
        } else if (!this.showOverview && CSState.logoCardType == 'Y') {
            this.currentState = 'prepaidOverviewEnabled';
            /** temp comment remove once u resume code
            currency.y = 22;
            currencyVal.y = 22;
            // change
            /** temp comment remove once u resume code
            this.overviewDataModel = new PrepaidOverviewDataModel();
            **/
        }

    }


    // overviewDataModel.addEventListener(OverviewDataModel.OVERVIEW_LOADED, overviewLoaded);
    // load overviewData to successfully launch the functions from IDVerify.
    // overviewDataModel.loadOverviewData(overview.communicator);
    // overview.loadOverviewFunctionProcess();

    // CSDynamicParameters.instance.setVariable("fromIDVScreen", "false");


    openCloseCardViewer() {
        this.windowOpened = !this.windowOpened;
    }
    openCloseCardStatement() {
        this.statementWindowOC = !this.statementWindowOC;
    }
    openCloseReward() {
        this.windowOpened = !this.windowOpened;
    }
    openCloseCardRewardViewer() {
        this.windowOpenedReward = !this.windowOpenedReward;
    }
    openCloseAmendInsuranceWindowOC() {
        this.amendInsuranceWindowOC = !this.amendInsuranceWindowOC;
    }
}
