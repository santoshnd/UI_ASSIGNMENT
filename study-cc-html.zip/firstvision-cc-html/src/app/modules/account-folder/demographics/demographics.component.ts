import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../account-folder.service';
import { config } from '../../../../environments/config/config';

@Component({
  selector: 'app-demographics',
  templateUrl: './demographics.component.html',
  styleUrls: ['./demographics.component.scss']
})
export class DemographicsComponent implements OnInit {
  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  // end here
  additionalDetailsData: any;
  contactDetailsData: any;
  addressDetailsData: any;
  htmlClass: { 'labelClass': string; 'valueClass': string; };
  allConditions: any;

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.httpurl = 'assets/json/mock/demographics.json';
    this.demographicsDetails();
    this.htmlClass = {
      'labelClass': 'col-sm-7 text-blue',
      'valueClass': 'col-sm-5 text-right pl-0'
    };
    this.allConditions = {
      'colon': 'true'
    };
  }
  demographicsDetails() {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindDemographicsDetailsData(data));
  }
  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
  bindDemographicsDetailsData(data) {
    this.cd.detectChanges();
    this.addressDetailsData = data.group[2].rows.row[0].field;
    this.contactDetailsData = data.group[3].rows.row[0].field;
    this.additionalDetailsData = data.group[4].rows.row[0].field;
  }
}
