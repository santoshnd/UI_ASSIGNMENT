import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pin-count-reset',
  templateUrl: './pin-count-reset.component.html',
  styleUrls: ['./pin-count-reset.component.scss']
})
export class PinCountResetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
