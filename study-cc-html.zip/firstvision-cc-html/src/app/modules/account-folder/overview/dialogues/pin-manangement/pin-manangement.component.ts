import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { Output } from '@angular/core';


@Component({
  selector: 'app-pin-manangement',
  templateUrl: './pin-manangement.component.html',
  styleUrls: ['./pin-manangement.component.scss']
})
export class PinManangementComponent implements OnInit {
@Input() WindowPinFlag : boolean;
@Output() messagePinEvent = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
closePinManager(){
  this.messagePinEvent.emit(false);
}
}
