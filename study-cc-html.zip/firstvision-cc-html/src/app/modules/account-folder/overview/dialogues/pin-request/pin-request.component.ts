import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pin-request',
  templateUrl: './pin-request.component.html',
  styleUrls: ['./pin-request.component.scss']
})
export class PinRequestComponent implements OnInit {
referSection=true;
  constructor() { }

  ngOnInit() {
  }

}
