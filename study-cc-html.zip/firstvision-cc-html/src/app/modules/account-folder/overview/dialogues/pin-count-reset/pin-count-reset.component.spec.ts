import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinCountResetComponent } from './pin-count-reset.component';

describe('PinCountResetComponent', () => {
  let component: PinCountResetComponent;
  let fixture: ComponentFixture<PinCountResetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinCountResetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinCountResetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
