import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinManangementComponent } from './pin-manangement.component';

describe('PinManangementComponent', () => {
  let component: PinManangementComponent;
  let fixture: ComponentFixture<PinManangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinManangementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinManangementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
