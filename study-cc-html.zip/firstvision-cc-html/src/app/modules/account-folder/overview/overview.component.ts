import { Component, OnInit } from '@angular/core';
import { AccountFolderService } from '../account-folder.service';
import { config } from '../../../../environments/config/config';


@Component({
    selector: 'app-overview',
    templateUrl: './overview.component.html',
    styleUrls: ['./overview.component.scss']
})
export class OverviewComponent implements OnInit {
    supressLettersFlag: boolean;
    creditAdjustmentFlag: boolean;
    supressInterestFlag: boolean;
    blockAccountWindowOC: boolean;
    feeAdjustmentWindowOC: boolean;
    moneyTransferFlag: boolean;
    balanceTransferFlag: boolean;
    cardReplacementWindowOC: any;
    insuranceWindowOC: boolean;
    directCreditWindowOC: boolean;
    cardActivationWindowOC: boolean;
    messagePinEvent: any;
    openLookup: any;
    reInstateAccountFlag = false;
    blockCardFlag = false;
    skipPaymentFlag = false;
    sendLetterFlag = false;
    closeAccountFlag = false;
    accountStatementData: any;
    balanceSummeryData: Object;
    accountSummeryData: Object;
    htmlClass: any;
    openStatementPopup = false;
    addcardPopupOpen = false;
    authorisationRequestFlag = false;
    sampleProducts: any = [];
    constructor(private accountFolderService: AccountFolderService) { }

    ngOnInit() {
        this.balanceSummeryDetails();
        this.accountSummeryDetails();
        this.statementSummeryDetails();
        this.htmlClass = {
            'labelClass': 'col-sm-7 text-blue',
            'valueClass': 'col-sm-5 text-right pl-0'
        };
    }
    balanceSummeryDetails(): any {
        const balanceSummeryUrl = config.mockPath + 'balanceSummery.json';
        this.accountFolderService.getAnyJson(balanceSummeryUrl).subscribe(data => {
            this.bindBalanceSummeryData(data);
        });
    }
    bindBalanceSummeryData(data) {
        this.balanceSummeryData = data.group.field;
    }
    accountSummeryDetails(): any {
        const accountSummeryUrl = config.mockPath + 'accountSummery.json';
        this.accountFolderService.getAnyJson(accountSummeryUrl).subscribe(data => {
            this.bindAccountSummeryData(data);
        });
    }
    bindAccountSummeryData(data) {
        this.accountSummeryData = data.group.field;
    }
    statementSummeryDetails(): any {
        const accountStatementUrl = config.mockPath + 'statementSummary.json';
        this.accountFolderService.getAnyJson(accountStatementUrl).subscribe(data => {
            this.bindAccountStatementData(data);
        });
    }
    bindAccountStatementData(data) {
        this.accountStatementData = data.group.field;
    }
    openLookupFunction($event) {
        this.openLookup = $event;
    }
    close($event) {
        this.openLookup = $event;
        this.messagePinEvent = $event;
    }
    linkfunction(functionName) {
        switch (functionName) {
            case 'closeAccount':
                this.closeAccountFlag = !this.closeAccountFlag;
                break;
            case 'sendLetter':
                this.sendLetterFlag = !this.sendLetterFlag;
                break;
            case 'skipPayment':
                this.skipPaymentFlag = !this.skipPaymentFlag;
                break;
            case 'blockCard':
                this.blockCardFlag = !this.blockCardFlag;
                break;
            case 'reInstateAccount':
                this.reInstateAccountFlag = !this.reInstateAccountFlag;
                break;
            case 'authorisationRequest':
                this.authorisationRequestFlag = !this.authorisationRequestFlag;
                break;
            case 'balanceTransfer':
                this.balanceTransferFlag = !this.balanceTransferFlag;
                break;
            case 'moneyTransfer':
                this.moneyTransferFlag = !this.moneyTransferFlag;
                break;
            case 'supressInterest':
                this.supressInterestFlag = !this.supressInterestFlag;
                break;
            case 'supressLetters':
                this.supressLettersFlag = !this.supressLettersFlag;
                break;
            case 'creditAdjustment':
                this.creditAdjustmentFlag = !this.creditAdjustmentFlag;
                break;  
            default:
                alert('This function is yet under development !');
        }
    }

    viewAccountSummary(event) {
        this.openStatementPopup = !this.openStatementPopup;
    }

    closeStatementPopup(event) {
        this.openStatementPopup = !this.openStatementPopup;
    }

    closeAddCardPopup(event) {
        this.addcardPopupOpen = !this.addcardPopupOpen;
    }

    onAddNewCardClick(event) {
        this.addcardPopupOpen = !this.addcardPopupOpen;
    }
    openCloseCardActivation() {
        this.cardActivationWindowOC = !this.cardActivationWindowOC;
    }
    openCloseDirectCredit() {
        this.directCreditWindowOC = !this.directCreditWindowOC;
    }
    openCloseInsuranceWindow() {
        this.insuranceWindowOC = !this.insuranceWindowOC;
    }
    openClosecardReplacementWindow() {
        this.cardReplacementWindowOC = !this.cardReplacementWindowOC;
    }
    openCloseFeeAdjustmentWindow() {
        this.feeAdjustmentWindowOC = !this.feeAdjustmentWindowOC;
    }
    openCloseBlockAccountWindow() {
        this.blockAccountWindowOC = !this.blockAccountWindowOC;
    }
}
