import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { VxInputRoot } from '../../shared/servlet/shared-object';
import { Observable } from 'rxjs/Observable';
import { HttpServletService } from '../../shared/servlet/http-servlet.service';

@Injectable()
export class AccountFolderService {
    headerParam: any;
    httpurl: any;
    constructor(private http: HttpClient, public vxinput: VxInputRoot, public ser: HttpServletService) {
        this.headerParam = this.vxinput.VxInputRoot;
    }

    public rewardData$: Observable<any>;

    // Uses http.get() to load data from a single API endpoint
    getAnyJson(url) {
        return this.http.get(url);
    }

    // get Service Data Component Service
    getServiceData(httpurl, feildData, header) {
        this.manageInputParameter(feildData, header);
        this.rewardData$ = this.ser.getHttp(httpurl, this.headerParam);
    }

    // get Manage input param for service
    manageInputParameter(feildData, header) {
        this.headerParam.header.page.name = header.name;
        this.headerParam.header.page.action = header.page_action;
        this.headerParam.header.process.processName = header.process_processName;
        this.headerParam.header.request.id = header.request_id;
        this.headerParam.header.request.minimumData = header.request_minimumData;
        this.headerParam.header.request.type = header.request_type;
        this.headerParam.msgOut.field = feildData;
    }


}
