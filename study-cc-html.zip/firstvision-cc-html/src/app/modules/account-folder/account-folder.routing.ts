import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { AccountFolderComponent } from './account-folder.component';


const routes: Routes = [
  { path: '', component: AccountFolderComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountFolderRoutingModule {}

