import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountFolderComponent } from './account-folder.component';

describe('AccountFolderComponent', () => {
  let component: AccountFolderComponent;
  let fixture: ComponentFixture<AccountFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
