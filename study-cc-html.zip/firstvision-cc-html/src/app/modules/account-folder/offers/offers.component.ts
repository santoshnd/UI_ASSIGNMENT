import { Component, OnInit } from '@angular/core';
import { config } from '../../../../environments/config/config';
import { AccountFolderService } from '../account-folder.service';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.scss']
})
export class OffersComponent implements OnInit {
  dropdownArray: any;
  offersDetailsDropdown: any;
  allConditions: any;
  offerDetailsDataCol3: any;
  offerDetailsDataCol2: any;
  offerDetailsDataCol1: any;
  htmlClass: { 'labelClass': string; 'valueClass': string; };
  offerDetailsDataWithCSR: any;
  offerDetailsData: any;
 

  constructor(private accountFolderService : AccountFolderService) { }

  ngOnInit() {   
    this.offerDetails();
    this.offerDetailsSummaryWithCSR();
    this.htmlClass = {
      'labelClass': 'col-sm-4 text-blue',
      'valueClass': 'col-sm-8  pl-0'
    };
    this.allConditions = {
      'colon': 'true'
    };
  }
  offerDetails(): any {
    const offerUrl =  config.jsonPath+'offerDetails.json';
    this.accountFolderService.getAnyJson(offerUrl).subscribe(data => {
      this.bindOfferDetailsData(data);
    });
  }

  bindOfferDetailsData(data){
    this.offerDetailsDataCol1 = data.vxRoot.group[0].field;
    this.offerDetailsDataCol2 = data.vxRoot.group[1].field;
    this.offerDetailsDataCol3 = data.vxRoot.group[2].field;
  }
  offerDetailsSummaryWithCSR(): any {
    const offerUrlCSR =  config.jsonPath+'offerdetailsWithCSR.json';
    this.accountFolderService.getAnyJson(offerUrlCSR).subscribe(data => {
      this.bindOfferDetailsSummaryWithCSR(data);
    });
  }
  bindOfferDetailsSummaryWithCSR(data){
    this.offerDetailsDataWithCSR = data.vxRoot.group[1].field;
  }
  offerDetailsDropdown(){
    const offersDropdownUrl =  config.jsonPath+'offersDropdown.json';
    this.accountFolderService.getAnyJson(offersDropdownUrl).subscribe(data => {
      this.bindOfferDetailsDropdown(data);
    });
  }
  bindOfferDetailsDropdown(data: any): any {
    for(let i =0; i<data.vxRoot.group.rows.row.length;i++){
      this.dropdownArray.push (data.vxRoot.group.rows.row[0].field[i].value)
    }
    this.offersDetailsDropdown = data.vxRoot.group.rows
  }
}
