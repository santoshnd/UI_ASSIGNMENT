import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-amend-billing-cycle',
  templateUrl: './amend-billing-cycle.component.html',
  styleUrls: ['./amend-billing-cycle.component.scss']
})
export class AmendBillingCycleComponent implements OnInit {

  @Input() amendCycle: boolean;
 referSection = true;
@Output() amendCycleClose  = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  onAmendCycleClose(event){
    
   // this[event+'Opened'] = false;
    this.amendCycleClose.emit(false);
  }
}
