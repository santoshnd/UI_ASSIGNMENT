import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmendBillingCycleComponent } from './amend-billing-cycle.component';

describe('AmendBillingCycleComponent', () => {
  let component: AmendBillingCycleComponent;
  let fixture: ComponentFixture<AmendBillingCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmendBillingCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmendBillingCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
