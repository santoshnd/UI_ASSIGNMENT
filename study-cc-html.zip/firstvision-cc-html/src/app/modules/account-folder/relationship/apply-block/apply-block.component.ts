import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-apply-block',
  templateUrl: './apply-block.component.html',
  styleUrls: ['./apply-block.component.scss']
})
export class ApplyBlockComponent implements OnInit {

  @Input() applyBlock :boolean;
  referSection = true;
 @Output() blockCycleClose = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  
  onBlockCycleClose(data){
    this.blockCycleClose.emit(false);
  }
}
