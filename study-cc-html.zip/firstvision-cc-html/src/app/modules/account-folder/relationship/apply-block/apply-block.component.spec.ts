import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyBlockComponent } from './apply-block.component';

describe('ApplyBlockComponent', () => {
  let component: ApplyBlockComponent;
  let fixture: ComponentFixture<ApplyBlockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyBlockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
