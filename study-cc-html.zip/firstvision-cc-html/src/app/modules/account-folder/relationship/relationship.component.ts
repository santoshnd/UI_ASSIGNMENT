import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AccountFolderService } from '../account-folder.service';
import { DataService } from '../../../shared/services/data.service';

@Component({
  selector: 'app-relationship',
  templateUrl: './relationship.component.html',
  styleUrls: ['./relationship.component.scss']
})
export class RelationshipComponent implements OnInit {
  amendCycle: any;
  applyBlock: any;
  componenetData: any;
  htmlClass: any;

  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) {
    this.htmlClass = {
      'labelClass': 'col-sm-7 text-blue',
      'valueClass': 'col-sm-5 text-right pl-0'
    };

  }

  ngOnInit() {
    this.httpurl = 'assets/json/mock/balanceSummery.json';
    this.onPointSelected('');
  }

  closeCycle($event) {
    this.amendCycle = $event;
  }

  closeBlockCycle($event) {
    this.applyBlock = $event;
  }

  onPointSelected(eve: any) {
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data__) {
    this.cd.detectChanges();
    // tslint:disable-next-line:no-debugger
    debugger;
    this.componenetData = data__['group'].field;
    // console.log('>>>>' + JSON.stringify(data__['group'].field));
  }
}
