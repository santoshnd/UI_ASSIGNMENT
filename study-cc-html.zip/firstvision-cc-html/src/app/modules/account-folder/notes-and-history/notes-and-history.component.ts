import { Component, OnInit } from '@angular/core';
import { DataService } from '../../../shared/services/data.service';
import { config } from '../../../../environments/config/config';
import { DataFormatter } from '../../../shared/util/data.formatter';

@Component({
  selector: 'app-notes-and-history',
  templateUrl: './notes-and-history.component.html',
  styleUrls: ['./notes-and-history.component.scss']
})
export class NotesAndHistoryComponent implements OnInit {
  noteAndHistoryOptions: any = ['Customer Service', 'Collection', 'All'];
  noteAndHistorySelected: any = 'Customer Service';
  actionOptions: any = ['Customer Service', 'Collection', 'All'];
  actionSelected: any = 'Customer Service';
  dataFormatter = new DataFormatter();
  gridData: any;
  mockPath: any = config.mockPath;
  actionUrl = this.mockPath + 'action.json';
  recordUrl = this.mockPath + 'records.json';
  notesHistoryColumns: any;
  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    this.getNotesHistoryDetails();
    this.getActionList();
  }

  getNotesHistoryDetails() {
    this.dataService.getGridConfig('notesAndHistory').
      subscribe(gridConfig => {
        this.notesHistoryColumns = gridConfig.columns;
        this.dataService.getAnyJson(this.recordUrl).subscribe((data: any) => {
          this.bindNotesHistoryList(data.vxRoot.group[0].rows.row, gridConfig.columns);
        });
      });
  }

  getActionList() {
    this.dataService.getAnyJson(this.actionUrl).subscribe(data => {
      this.bindActionList(data);
    });
  }

  bindActionList(data) {
    this.actionOptions = data.vxRoot.group.rows.row;
  }

  bindNotesHistoryList(data, columns) {
    this.gridData = this.dataFormatter.parseGridData(data, columns);
  }

  setOriginatorIcon(data: any): string {
    let source = '';
    if (data.originator === 'LJP') {
      source = 'assets/images/icons/large-computer.gif';
    }
    else {
      source = 'assets/images/icons/large-user-yellow.png';
    }

    return source;
  }

  bindGridData(data) {

  }
  onNoteAndHistorySelected(event) {
    console.log(event);
  }
  onActionSelected(event) {
    console.log(event);
  }
}
