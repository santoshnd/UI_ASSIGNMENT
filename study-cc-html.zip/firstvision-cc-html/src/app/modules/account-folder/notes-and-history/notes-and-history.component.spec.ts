import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotesAndHistoryComponent } from './notes-and-history.component';

describe('NotesAndHistoryComponent', () => {
  let component: NotesAndHistoryComponent;
  let fixture: ComponentFixture<NotesAndHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotesAndHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesAndHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
