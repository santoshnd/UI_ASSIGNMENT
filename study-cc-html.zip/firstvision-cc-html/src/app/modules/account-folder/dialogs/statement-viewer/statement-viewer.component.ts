import { Component, OnInit } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../account-folder.service';
import { DataFormatter } from '../../../../shared/util/data.formatter';

@Component({
  selector: 'app-statement-viewer',
  templateUrl: './statement-viewer.component.html',
  styleUrls: ['./statement-viewer.component.scss']
})
export class StatementViewerComponent implements OnInit {
  statementFooterColumns: any;
  allConditions: { 'colon': string; };
  statementFooterList: any;
  statementHeaderList4: any;
  statementHeaderList3: any;
  statementHeaderList2: any;
  statementHeaderList1: any;
  htmlClass: { 'labelClass': string; 'valueClass': string; };
  statementDateList: any = [{ 'formattedValue': 'Select value' }];
  dataFormatter = new DataFormatter();
  constructor(private accountFolderService: AccountFolderService) { }
  ngOnInit() {
    this.htmlClass = {
      'labelClass': 'col-sm-7 text-blue',
      'valueClass': 'col-sm-5 text-right pl-0'
    };
    this.allConditions = {
      'colon': 'true'
    };
    this.statementDateDetails();
    this.statementHeaderDetails();
    this.statementFooterDetails();
  }
  statementDateDetails(): any {
    // statementDatesDirectory.json will replace with process id which will come dynamically
    const statementDateUrl = config.mockPath + 'statementDatesDirectory.json';
    this.accountFolderService.getAnyJson(statementDateUrl).subscribe(data => {
      this.bindstatementDateData(data);
    });
  }
  bindstatementDateData(arg0) {
    this.statementDateList = arg0.group.rows.row;
  }
  statementHeaderDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    const statementHeaderUrl = config.mockPath + 'statementHeader.json';
    this.accountFolderService.getAnyJson(statementHeaderUrl).subscribe(data => {
      this.bindstatementHeaderData(data);
    });
  }
  bindstatementHeaderData(arg0) {
    this.statementHeaderList1 = arg0.group[0].field;
    this.statementHeaderList2 = arg0.group[1].field;
    this.statementHeaderList3 = arg0.group[2].field;
    this.statementHeaderList4 = arg0.group[3].field;
  }
  statementFooterDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    const statementFooterUrl = config.mockPath + 'statementFooter.json';
    this.accountFolderService.getAnyJson(statementFooterUrl).subscribe(data => {
      this.bindstatementFooterData(data);
    });
  }
  bindstatementFooterData(arg0) {
    this.statementFooterColumns = this.dataFormatter.extractColumns(arg0.group[0].rows.row[0].field);
    this.statementFooterList = this.dataFormatter.parseGridData(
      arg0.group[0].rows.row, this.statementFooterColumns);
  }
}
