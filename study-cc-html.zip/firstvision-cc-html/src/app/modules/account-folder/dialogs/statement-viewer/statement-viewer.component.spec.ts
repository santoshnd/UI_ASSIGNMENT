import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementViewerComponent } from './statement-viewer.component';

describe('StatementViewerComponent', () => {
  let component: StatementViewerComponent;
  let fixture: ComponentFixture<StatementViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatementViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
