import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../account-folder.service';

@Component({
  selector: 'app-card-activation',
  templateUrl: './card-activation.component.html',
  styleUrls: ['./card-activation.component.scss']
})
export class CardActivationComponent implements OnInit {

  // service inte var
  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  // end here

  priorityList: string[] = ['None'];
  listOfActivationCardsList: any;
  priority: any;

  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.httpurl = 'assets/json/mock/listOfActivationCards.json';
    this.listOfActivationCardsDetails();
  }
  listOfActivationCardsDetails(): any {
    // statementHeader.json will replace with process id which will come dynamically
    /* const listOfActivationCardsUrl = config.mockPath + 'listOfActivationCards.json';
    this.accountFolderService.getAnyJson(listOfActivationCardsUrl).subscribe(data => {
      this.bindlistOfActivationCardsData(data);
    }); */

    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.getdata(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getdata(data) {
    this.cd.detectChanges();
    this.listOfActivationCardsList = data.group.rows.row;
    // console.log('>>>>' + JSON.stringify(this.listOfActivationCardsList));
  }

  // bindlistOfActivationCardsData(arg0) {
  //   this.listOfActivationCardsList = arg0.group.rows.row;
  // }
}
