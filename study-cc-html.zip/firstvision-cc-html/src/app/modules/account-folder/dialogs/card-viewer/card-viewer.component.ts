import { Component, OnInit } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../account-folder.service';
import { DataFormatter } from '../../../../shared/util/data.formatter';
import { DataService } from '../../../../shared/services/data.service';

@Component({
  selector: 'app-card-viewer',
  templateUrl: './card-viewer.component.html',
  styleUrls: ['./card-viewer.component.scss']
})
export class CardViewerComponent implements OnInit {
   // service inte var
   fieldValue: any;
   header: { [k: string]: any } = {};
   httpurl: string;
   // end here
  unblockCardColumns: any;
  blockCardDetails: any;
  allCardsDetails: any;
  unblockCardDetails: any;
  dataFormatter = new DataFormatter();
  constructor(private accountFolderService: AccountFolderService,
              private dataService: DataService) { }

  ngOnInit() {
   this.httpurl = 'assets/json/mock/cardViewer.json';
   this.cardDetails();
  }
  cardDetails(): any {
    // this.dataService.getGridConfig('cardViewerDetails')
    // .subscribe(gridConfig => {
    //   this.accountFolderService.getAnyJson(cardDetailsUrl).subscribe((res: any) => {
    //     const blockCardData = res.group[0].rows.row.field;
    //     this.blockCardDetails = this.dataFormatter.parseGridData(
    //       blockCardData , gridConfig.columns);
    //   });
    // });
    // this.accountFolderService.getAnyJson(cardDetailsUrl).subscribe(data => {
    //   this.bindCardsDetailsData(data);
    // });
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1', 'isModified': 'true', 'value': 'ok' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindCardsDetailsData(data));
  }

  // set business process name,id,action
  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }
  bindCardsDetailsData(arg0) {
    //  this.unblockCardDetails = arg0.group[0].rows.row.field;
    //  this.allCardsDetails = arg0.group[1].rows.row.field;
    //  this.blockCardDetails = arg0.group[2].rows.row.field;
    // console.log(arg0);
    this.unblockCardColumns = this.dataFormatter.extractColumns(arg0.group[0].rows.row.field);
    this.unblockCardDetails = this.dataFormatter.parseGridData(
      arg0.group[0].rows.row.field, this.unblockCardColumns);

     this.unblockCardDetails = [];
     this.allCardsDetails = [];
     this.blockCardDetails = [];
    }
}
