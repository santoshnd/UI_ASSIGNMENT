import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardStatementComponent } from './reward-statement.component';

describe('RewardStatementComponent', () => {
  let component: RewardStatementComponent;
  let fixture: ComponentFixture<RewardStatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardStatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
