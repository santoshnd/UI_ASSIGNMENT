import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockLostCardComponent } from './block-lost-card.component';

describe('BlockLostCardComponent', () => {
  let component: BlockLostCardComponent;
  let fixture: ComponentFixture<BlockLostCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockLostCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockLostCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
