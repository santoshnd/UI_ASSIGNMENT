import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-block-lost-card',
  templateUrl: './block-lost-card.component.html',
  styleUrls: ['./block-lost-card.component.scss']
})
export class BlockLostCardComponent implements OnInit {
  @Input() blockCard: any;
  @Input() referSection = true;
  @Output() blockCardClose = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }
  onBlockCardClose(event) {

    this[event + 'Card'] = false;
    this.blockCardClose.emit(false);
  }
}
