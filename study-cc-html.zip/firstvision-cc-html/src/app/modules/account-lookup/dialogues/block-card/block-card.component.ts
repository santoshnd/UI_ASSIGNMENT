import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { config } from '../../../../../environments/config/config';
import { AccountFolderService } from '../../../../modules/account-folder/account-folder.service';

@Component({
  selector: 'app-block-card',
  templateUrl: './block-card.component.html',
  styleUrls: ['./block-card.component.scss']
})
export class BlockCardComponent implements OnInit {

  fieldValue: any;
  header: { [k: string]: any } = {};
  httpurl: string;
  gridRow: any = [ {
    CardNumber : '',
    CardholderName: '',
    Type: '',
    BlockStatus: '',
    BlockPriority: ''
  }];
  cardDropdown = [];
  htmlClass: { 'labelClass': string; 'valueClass': string; };
  @Input() blockCardFlag: boolean;
  @Output() windowCloseFlag = new EventEmitter<boolean>();
  constructor(private accountFolderService: AccountFolderService, private cd: ChangeDetectorRef) {
    this.htmlClass = {
      'labelClass': 'col-4 labelclass pl-2 px-0',
      'valueClass': 'col-5 py-1 px-0'
    };
  }

  ngOnInit() {
    this.getblockcarddata();
    this.getblockcardgriddata();
  }

  setComponentReqHeader() {
    this.header['name'] = 'Pin';
    this.header['page_action'] = 'PIN Request';
    this.header['process_processName'] = 'PIN Request Inquiry';
    this.header['request_id'] = '005';
    this.header['request_minimumData'] = 'true';
    this.header['request_type'] = 'SERVICE';
  }

  getblockcarddata() {
    this.httpurl = 'assets/json/mock/BlockCodeMock.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindCardDropdownData(data));
  }
  getblockcardgriddata() {
    this.httpurl = 'assets/json/mock/blockCardGridMock.json';
    this.fieldValue = [{ 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' },
    { 'fieldName': '1212', 'isModified': 'true', 'value': 'ddsss' }];

    this.setComponentReqHeader();
    this.accountFolderService.getServiceData(this.httpurl, this.fieldValue, this.header);
    this.accountFolderService.rewardData$.subscribe(data => this.bindCardGridData(data));
  }
  bindCardDropdownData(data) {
    for (let i = 0 ; i <= data.vxRoot.group.rows.row.length; i++) {
    if (data.vxRoot.group.rows.row[i].formattedValue !== undefined) {
      this.cardDropdown.push(data.vxRoot.group.rows.row[i].formattedValue);
    }
  }
  }
  bindCardGridData(data) {
    for (let i = 0 ; i <= data.vxRoot.group.rows.row.length; i++) {
      const rowData = data.vxRoot.group.rows.row[i];
      if (typeof(rowData.field[0].value) !== 'object') {
        this.gridRow.push({
          'CardNumber' : rowData.field[0].value,
          'CardholderName': rowData.field[1].value,
          'Type': rowData.field[2].value,
          'BlockStatus': rowData.field[3].value,
          'BlockPriority': rowData.field[4].value
        });
      }
    }
  }
  close(popUp) {
    this.windowCloseFlag.emit(popUp);
  }
}
