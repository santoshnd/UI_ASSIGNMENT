import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-block-code-failed-verification',
  templateUrl: './block-code-failed-verification.component.html',
  styleUrls: ['./block-code-failed-verification.component.scss']
})
export class BlockCodeFailedVerificationComponent implements OnInit {
  @Input() verificationOpened: any;
 referSection = true;
  @Output() verificationClose = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }

   // this[event+'Opened'] = false;
  onFailedVerificationClose(event) {
    this[event + 'Opened'] = false;
    this.verificationClose.emit(false);
  }
}
