import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockCodeFailedVerificationComponent } from './block-code-failed-verification.component';

describe('BlockCodeFailedVerificationComponent', () => {
  let component: BlockCodeFailedVerificationComponent;
  let fixture: ComponentFixture<BlockCodeFailedVerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockCodeFailedVerificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockCodeFailedVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
