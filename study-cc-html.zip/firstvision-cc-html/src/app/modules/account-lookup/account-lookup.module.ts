import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { IdVerifyComponent } from './id-verify/id-verify.component';
import { AccountLookupComponent } from './account-lookup.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AccountLookupRoutingModule } from './account-lookup.routing';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { FormsModule } from '@angular/forms';
import { VerifyService } from './id-verify/verify.service';
import { BasetemplateComponent } from '../../shared/templates/basetemplate/basetemplate.component';
import { LabelComponent } from '../../shared/components/controls/label/label.component';
import { CookieService } from 'ngx-cookie-service';
import { GridModule } from '@progress/kendo-angular-grid';
import { DataService } from '../../shared/services/data.service';
import { EventServiceService } from '../../shared/services/event-service.service';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { BlockCodeFailedVerificationComponent } from './dialogues/block-code-failed-verification/block-code-failed-verification.component';
import { BlockLostCardComponent } from './dialogues/block-lost-card/block-lost-card.component';
import { AddNotesComponent } from '../../shared/Dialogs/add-notes/add-notes.component';
import { ManualReferralSectionComponent } from '../../shared/components/manual-referral-section/manual-referral-section.component';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { LetterSectionComponent } from '../../shared/components/letter-section/letter-section.component';
import { ReferralNoteSectionComponent } from '../../shared/components/referral-note-section/referral-note-section.component';
import { AddAddressComponent } from '../../shared/Dialogs/add-address/add-address.component';
import { TempAddressComponent } from '../../shared/Dialogs/temp-address/temp-address.component';
import { CorrespondenceAddressComponent } from '../../shared/Dialogs/correspondence-address/correspondence-address.component';
import { NoteSectionComponent } from '../../shared/components/note-section/note-section.component';
import { PopoverModule } from 'ngx-popover';
import { BlockCardComponent } from './dialogues/block-card/block-card.component';
import { DropdownComponent } from '../../shared/components/controls/dropdown/dropdown.component';
import { LinkLabelComponent } from '../../shared/components/controls/link-label/link-label.component';
import { AccountFolderService } from '../account-folder/account-folder.service';
import { VxInputRoot } from '../../shared/servlet/shared-object';
import { HttpServletService } from '../../shared/servlet/http-servlet.service';

@NgModule({
  imports: [
    CommonModule,
    AccountLookupRoutingModule,
    FormsModule,
    DialogsModule,
    DropDownsModule,
    LayoutModule,
    GridModule,
    WindowModule,
    DatePickerModule, PopoverModule
  ],
  declarations: [
    IdVerifyComponent,
    AccountLookupComponent,
    LabelComponent, DropdownComponent,
    LinkLabelComponent,
    BasetemplateComponent,
    BlockCodeFailedVerificationComponent,
    BlockLostCardComponent,
    AddNotesComponent, ReferralNoteSectionComponent, ManualReferralSectionComponent
    , NoteSectionComponent,
    AddAddressComponent
    , BlockCardComponent,
    TempAddressComponent,
    CorrespondenceAddressComponent
  ],
  entryComponents: [LabelComponent, DropdownComponent, LinkLabelComponent],
  // tslint:disable-next-line:max-line-length
  providers: [VerifyService, CookieService, DataService, DatePipe, EventServiceService, AccountFolderService, VxInputRoot, HttpServletService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AccountLookupModule { }
