import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { AccountLookupComponent } from './account-lookup.component';
import { AccountFolderModule } from '../account-folder/account-folder.module';

const routes: Routes = [
  {
    path: '', component: AccountLookupComponent,
    children: [{
      path: 'account-folder', loadChildren: () => AccountFolderModule
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountLookupRoutingModule { }

