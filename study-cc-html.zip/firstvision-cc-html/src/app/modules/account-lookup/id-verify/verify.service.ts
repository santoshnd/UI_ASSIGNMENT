import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class VerifyService {
  constructor(private http: HttpClient) { }

  getCardNameDirectory() {
    return this.http.get('assets/json/cardNameDirectory.json');
  }

  getValidationData() {
    return this.http.get('assets/json/validationData.json');
  }

  getAdditionalValidationData() {
    return this.http.get('assets/json/additionalValidationData.json');
  }

  getTransactionDetails() {
    return this.http.get('assets/json/transactionDetails.json');
  }

  getExactShinDevURL() {
    let requestObject = {

      "jsonInput": {
        vxInputRoot: {

          "targetNamespace": "http://visionx.firstdata.com/test/VX.PRES.PROCESSOPTIONS.V001",
          "xsi:schemaLocation": "http://www.w3.org/2001/XMLSchema-instance",
          "xmlns": "http://com/fd/firstvision/vx/input",
          "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",

          "header": {

            "page": {

              "action": "ReqInput",

              "name": "Account Inquiry"

            },

            "process": {

              "processName": "Account Inquiry"

            },

            "request": {

              "id": "005",

              "minimumData": "false",
              "type": "SERVICE"

            }

          },

          "msgOut": null,
          "field": {
            "fieldName": "ARXAOI-ACCT",
            "value": "0003925000000011524",
            "isModified": "true"
          }

        }
      },
      "xmlInput": '<vxInputRoot targetNamespace="http://visionx.firstdata.com/test/VX.PRES.PROCESSOPTIONS.V001" xmlns="http://com/fd/firstvision/vx/input" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">      <header>        <page action="ReqInput" name="Account Inquiry"/>        <process processName="Account Inquiry"/>        <request id="005" type="SERVICE" minimumData="false"/>      </header>      <msgOut>        <field>          <fieldName>ARXAOI-ACCT</fieldName>          <value>0003925000000011524</value>          <isModified>true</isModified>        </field>      </msgOut>    </vxInputRoot>'
    };
    return this.http.post('http://shinedev1zb.fdi.1dc.com:2080/emea-design-C-CC/servlet/', requestObject);
  }

  getPriorQuestions() {

  }
}

