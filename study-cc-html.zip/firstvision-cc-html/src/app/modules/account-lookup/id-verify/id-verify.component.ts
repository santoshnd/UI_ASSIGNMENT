import { Component, OnInit, Input, Output, EventEmitter, NgZone } from '@angular/core';
import { VerifyService } from './verify.service';
import { ChangeDetectorRef } from '@angular/core';
import { ReferenceTable } from '../../../shared/util/referenceTable';
import { ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { CsConfigService } from '../../../shared/services/csConfig.service';
import { FormatterUtil } from '../../../shared/util/formatterUtil';
import { CSState } from '../../../shared/models/cSState.model';
import { CurrencyAttributes } from '../../../shared/cpSharedLib/currencyAttributes';
import { CSDynamicParameters } from '../../../shared/models/csDynamicParameters.model';
import { EventServiceService } from '../../../shared/services/event-service.service';
import { DataFormatter } from '../../../shared/util/data.formatter';
import { DataService } from '../../../shared/services/data.service';
import { AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-id-verify',
  templateUrl: './id-verify.component.html',
  styleUrls: ['./id-verify.component.scss']
})
export class IdVerifyComponent implements OnInit, AfterViewInit {
  CSDynamicParameters = new CSDynamicParameters();

  @Input() windowWidth: number;
  @Output() showAdditionalDataEmitter = new EventEmitter();
  @ViewChild('verifyForm') verifyForm: NgForm;

  cardDirectory: Object;
  currencyAttributes: any;
  cardList: any = [];
  priorMailDate: any;
  validationData: any;
  additionalValidationData: any;
  referenceTable = new ReferenceTable();
  dataFormatter = new DataFormatter();
  asocText = '';
  defaultCardName = '';
  callerDetails = [];

  splitterSize = '50%';
  validationPageName: string;
  additionalValidationPageName: string;
  customerNumber: String;
  customerOrg: String;
  accountNumber: String;
  accountOrg: String;
  enteredValue: String;
  blkCode1: String;
  blkCode2: String;
  ENABLE_VERIFY: String = 'verifyEnabled';
  QUESTIONS_COMPLETE: String = 'questionsComplete';
  blkValue: String;
  accountFolder: any;
  prepaidAccount: String = '';
  transactionGridColumns: any;
  // enforcer: Enforcer = EnforcerFactory.currentEnforcer;

  tier2Enabled: Boolean = false;
  showAuthorizedUsers: Boolean = false;
  enableVerify: Boolean = false;
  entitlementVerify: Boolean = true;
  hideAdditionalData: boolean;
  verifyQuestionsComplete: Boolean = false;
  verifyBaseQuestionsComplete: Boolean = false;
  skipVerify: Boolean = false;
  correspondenceCustNbr: String = '';
  hasCorrespondenceCust: Boolean = false;
  CSState = new CSState();
  idVerifyXml: any;
  memo2Text: any;
  memo1Text: any;
  transactionDetails: any[];

  preferences: any;
  OptInOptOut1: String = '1';
  OptInOptOut2: String = '1';
  LoanVisible: String = '0';
  FUNCTION_NAME: String = 'Verification Questions';
  // --------Memorable word-------//
  MEMORABLE_WORD_FIELD1: String = 'AZXMWI-MEM-WORD-CHAR-1';
  MEMORABLE_WORD_FIELD2: String = 'AZXMWI-MEM-WORD-CHAR-2';
  MEMORABLE_CHAR_POS1: String = 'AZXMWO-MEM-WORD-POS-1';
  MEMORABLE_CHAR_POS3: String = 'AZXMWI-MEM-WORD-POS-1';
  MEMORABLE_CHAR_POS4: String = 'AZXMWI-MEM-WORD-POS-2';

  MEMORABLE_CHAR_POS2: String = 'AZXMWO-MEM-WORD-POS-2';
  MEMORABLE_OUT_CHAR1 = 'ARXMDO-OUTPUT-FLAG-1';
  MEMORABLE_OUT_CHAR2 = 'ARXMDO-OUTPUT-FLAG-2';

  fieldList: any;
  PAGE_NAME: String;
  PROCESS_NAME: String;


  constructor(
    private verifyService: VerifyService,
    private dataService: DataService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private zone: NgZone,
    private csConfig: CsConfigService,
    private eventservice: EventServiceService,
  ) { }

  ngOnInit() {
    this.zone.runOutsideAngular(() => {
      this.getTransactionDetails();
    });
    this.getCardNameDirectory();
    this.getValidationData();
    this.idVerifyXml = this.csConfig.get('functionButton').find(x => x.id === 'IDVerify');
    this.hideAdditionalData = true;
  }

  ngAfterViewInit() {

  }

  getFunctionList() {

  }

  onVerifyClick() {
    this.router.navigateByUrl('/account-lookup/account-folder');
  }

  onFunctionClick(event, functionName) {
    switch (functionName) {
      case 'verifyCard':
        this.eventservice.changeEvent({ verificationOpened: true, data: event });
        break;
      case 'blockCard':
        this.eventservice.changeEvent({ blockCard: true, data: event });
        break;
      case 'updateNumber':
        this.eventservice.changeEvent({ updateNumber: true, data: event });
        break;
      case 'addNote':
        this.eventservice.changeEvent({ addNote: true, data: event });
        break;
      default:
        alert('Sorry, that is not the correct selection');
    }
    //   this.eventservice.changeEvent({ verificationOpened:true, data: event });
  }

  getCardNameDirectory() {
    this.verifyService.getCardNameDirectory().subscribe((res: any) => {
      this.cardDirectory = res;
      this.priorMailDate = res.group[0].rows.row.field.find(
        x => x.id === 'ARXELO-ACCT-PRIOR-MAIL-DATE'
      ).value;
      this.applyCardHolderTypeFilter(res);
    });
  }

  getValidationData() {
    this.verifyService.getValidationData().subscribe((res: any) => {
      this.validationData = res.group[1].field;
      this.validationPageName = res.header.page.name;
      // this.afterQuestionResult(res);
    });
  }

  getAdditionalValidationData() {
    this.verifyService.getAdditionalValidationData().subscribe((res: any) => {
      this.additionalValidationData = res.group.field;
      this.additionalValidationPageName = res.header.page.name;
      this.currencyAttributes = new CurrencyAttributes(res.header.currencyAttrib);
      // this.afterAdditionalQuestionsResult(res);
    });
  }

  getTransactionDetails() {
    this.dataService.getGridConfig('transactionDetails')
      .subscribe(gridConfig => {
        this.verifyService.getTransactionDetails().subscribe((res: any) => {
          this.transactionDetails = this.dataFormatter.parseGridData(
            res.group[0].rows.row, gridConfig.columns);
          this.getAdditionalValidationData();
        });
      });
  }

  afterQuestionResult(result: any): void {
    // let char1 = (x => x.id === this.MEMORABLE_OUT_CHAR1);
    // let char2 = (x => x.id === this.MEMORABLE_OUT_CHAR2);
    // check result message for error codes, communicator will check for
    // and display error message all at the same time.  if error exit.
    // **** Need to create component for this yet

    // extract memo / authorized user data.
    const fieldMemo1 = result.group[0].field.find(x => x.id === 'AMNA-MEMO-1(1)')[0];
    if (fieldMemo1) {
      this.memo1Text = fieldMemo1.value.toString();
    }

    const fieldMemo2 = result.group[0].field.find(x => x.id === 'AMNA-MEMO-2(1)')[0];
    if (fieldMemo2) {
      this.memo2Text = fieldMemo2.value.toString();
    }

    // Added for defect 49523 - 15.10
    if (this.idVerifyXml != null) {
      const csletiable: String = this.idVerifyXml.item.find(x => x.letiable).toString();
      if (result.group.field.find(x => x.id == csletiable)[0] != null) {
        this.blkValue = result.group.field.find(x => x.id == csletiable)[0].value.toString();
      }
    }


    // letter org field
    const letterOrg = result.group[0].field.find(x => x.id === 'AMCR-LB-PCF-LTR-ORG');
    if (letterOrg) {
      this.CSState.letterOrg = letterOrg.value;
    }

    // Orbitall Praduct Graduation and Transfer letiable
    // no need for config setting, as either the field will be there or it wont. allows us to not have to use releaseType
    if (result.group[0].field.find(x => x.id == 'AMCR-O-DUE-DAY-PROC-IND')) {
      this.CSState.pendingDueDateIndicator = result.group[0].field.find(x => x.id == 'AMCR-O-DUE-DAY-PROC-IND')[0].value.text;
    } else {
      this.CSState.pendingDueDateIndicator = 0;
    }

    // logo card type d=Debit Card, Y=Prepaid Cards
    this.CSState.logoCardType = result.group[0].field.find(x => x.id == 'AMCR-LB-CARD-TYPE').value.text;

    // setting SDP flag for Card Lost stolen functionality
    let sdpFlag: any;
    if (result.group.field.find(x => x.id == 'AMCR-LB-SDP-FLAG')) {
      sdpFlag = result.group.field.find(x => x.id == 'AMCR-LB-SDP-FLAG').value.text;
    }
    if (sdpFlag === '1') {
      this.CSDynamicParameters.setVariable('SDP-FLAG', sdpFlag);
    }

    // adaptive control system (ACS) flag
    this.CSState.ACSFlag = result.group[0].field.find(x => x.id == 'AMCR-O-ACS-INTERFACE-FLAG')[0].value;
    // skip payment flag - will not be there in EMEA as of now
    const skipPayment = result.group.field.find(x => x.id == 'AMCR-LB-PMT-SKIP-ALLOWED').value.text;

    if (skipPayment.toLowerCase() === 'y') {
      this.CSState.isSkipPaymentAllowed = true;
    } else {
      this.CSState.isSkipPaymentAllowed = false;
    }

    const fieldOpt1 = result.group[0].field.find(x => x.id == 'AMCR-LB-AUTH-OTB-MSG-IND').value;
    if (fieldOpt1) {
      this.OptInOptOut1 = fieldOpt1.value.toString();
    }

    // set letters interface flag. used to be done in systemRecordInquiry_onResult
    const field = result.group[0].field.find(x => x.id == 'AMCR-S-LTS-INTERFACE-FLAG')[0];
    if (field) {
      if (field.value.toString().toLowerCase() === 'n') {
        this.CSState.isLTSActive = false;
      } else {
        this.CSState.isLTSActive = true;
      }
    }

    // set LMS active flag.
    // 1406 UAT Defect # 40713 - LMS-INACTIVE  VALUE '0' 'N'
    const lms = result.group.field.find(x => x.id == 'AMCR-LB-LMS-ACTIVE-FLAG')[0];
    if (lms) {
      if (lms.value.toString() == '0' || lms.value.toString() == 'N') {
        this.CSState.isLMSActive = false;
      } else {
        this.CSState.isLMSActive = true;
      }
    }

    const oms = result.group.field.find(x => x.id == 'AMCR-S-OMS-INTERFACE-FLAG')[0];
    if (oms) {
      if (oms.value.toString() == '0' || oms.value.toString() == 'N') {
        this.CSState.isOMSActive = false;
      } else {
        this.CSState.isOMSActive = true;
      }
    }
    // EPP Eligiblity check
    const eppOrg = result.group.field.find(x => x.id == 'AMCR-O-EPP-ACTIVE-IND')[0];
    const eppLogo = result.group.field.find(x => x.id == 'AMCR-LB-EPP-ACTIVE')[0];
    const loanActive = result.group.field.find(x => x.id == 'AMCR-LB-INSTALL-LOAN-FLAG')[0];
    // let loanActive:XML = result.group.field.find(x=>x.id=="AMCR-LB-INSTALL-LOAN-FLAG")[0];

    if (eppOrg && eppLogo && loanActive) {
      if (eppOrg.value.toString() == '1' && eppLogo.value.toString() == '1' && loanActive.value.toString() == '1') {
        this.CSDynamicParameters.setVariable('isEPPActive', 'true');
      } else {
        this.CSDynamicParameters.setVariable('isEPPActive', 'false');
      }
    }

    // check to make sure that at least some data was entered into the memo fields,
    // if not then hide the "authorized users" section all toghether
    if (this.memo1Text !== '' || this.memo2Text !== '') {
      this.showAuthorizedUsers = true;
    } else {
      this.showAuthorizedUsers = false;
    }

    this.verifyQuestionsComplete = true;

    if (!this.skipVerify) {
      // loadPriorQuestions();
    }
  }

  afterAdditionalQuestionsResult(result: any): void {

    // enable the verify Button
    // check result message for error codes, communicator will check for
    // and display error message all at the same time.  if error exit.

    const OptInOptOut2 = result.group[0].field.some(x => x.id === 'AMBS-AUTH-OTB-MSG-IND')[0];
    if (OptInOptOut2) {
      this.OptInOptOut2 = OptInOptOut2.value.text;
    }
    // Code added to get Number of Loan Plans


    const dateNextStatement = result.group[0].field.find(x => x.id == 'AMBS-DATE-NEXT-STMT')[0];
    if (result.group[0].field.some(x => x.id == 'AMBS-CUST-NBR')[0]) {
      const custNbr = result.group[0].field.find(x => x.id == 'AMBS-CUST-NBR')[0];
      if (custNbr) {
        this.CSDynamicParameters.setVariable('CustomerNumber', custNbr.value);
      }
    }
    const planCount = result.group[0].field.find(x => x.id == 'AMBS-NBR-PLANS')[0];
    // The Account has less than 95 plans attached to it then EPP flag is turn off
    if (planCount && planCount.value >= 95) {
      this.CSDynamicParameters.setVariable('isEPPActive', 'false');
    }
    // Below Condition is EPP Transaction.
    if (dateNextStatement && dateNextStatement.value) {
      this.CSDynamicParameters.setVariable('NextStatementDate', dateNextStatement.value);
    }

    this.CSState.showDefaultTab = ''; // EMPTY will ensure that default tab is Overview Tab.

    const loanPlanCount = result.group[0].field.find(x => x.id === 'AMBS-NBR-LOAN-PLANS')[0];
    if (loanPlanCount) {
      this.LoanVisible = loanPlanCount.value.toString();
      // FVsn00013748 -- The Account have only Loan will open opening as default
      if (loanPlanCount.value > 0 && planCount && loanPlanCount.value == planCount.value) {
        this.CSState.showDefaultTab = 'loans'; // this should match with tab child ID.
        // Note - this check will get override if tab is not Entitlements
      }
    }
    // Disable Enable the Relationship tab based on AMBS-REL-NBR field.
    this.CSState.isRelationshipActive = result.group.field.some(x => x.id === 'AMBS-REL-NBR')[0].value;

    // Below condition are for checking visiblity of Relationship tab and default landing page

    const type = this.CSDynamicParameters.getVariableAsString(x => x === 'REL-ACCT-FLAG');
    const relationship = this.CSDynamicParameters.getVariableAsString(x => x === 'REL-NBR');

    // In case Rel number is not set then read it from AMBS
    if (!relationship) {
      const relNbr = result.group[0].field.find(x => x.id === 'AMBS-REL-NBR')[0];
      if (relNbr && relNbr.hasOwnProperty('value')) {
        this.CSDynamicParameters.setVariable('REL-NBR', relNbr.value.text);
      }
    }

    // Logic for showing default tab
    if (relationship && type) {
      if (relationship.length > 0 && type === 'R') {
        this.CSState.showDefaultTab = 'relationship';
      }
    }

    // Code to retrive the commercial flag and set it in for Corporate Detail tab in Amend Demografics Screen.
    const commrclFlag = result.group[0].field.find(x => x.id === 'AMBS-COMMRCL-FLAG')[0];
    if (commrclFlag.value) {
      this.CSDynamicParameters.setVariable('COMMRCL-FLAG', commrclFlag.value);

    }

    // Code added to get the account status for Card Lost Stolen
    const accountIntStatus = result.group[0].field.find(x => x.id === 'AMBS-INT-STATUS')[0];
    if (accountIntStatus) {
      this.accountFolder.accountStatus = accountIntStatus.value;
    }

    // for suppress letter
    const suppressLetter = result.group.field.find(x => x.id === 'AMBS-SUPP-LTR')[0];
    let suppLtrValue = true;
    if (suppressLetter && suppressLetter.value) {
      suppLtrValue = suppressLetter.value === '1' ? false : true;
    }
    this.CSDynamicParameters.setVariable('EnableSendLetter', suppLtrValue);


    // for prepaid Cards

    this.CSDynamicParameters.loadParameters(result);
  }

  loadPriorQuestions(): void {
    // prior mailer questions come from a new business process
    if (this.priorMailDate === '' || this.priorMailDate === '0') {
      return;
    }

    // let priorquestions: CSMessage = new CSMessage("Prior Mailer Verification Questions", "Prior Mailer Verification Questions");
    // priorquestions.requestType = CSMessage.PAGE;
    // priorquestions.minimumData = "false";
    // priorquestions.addParameter("AMPM-ORG", this.customerOrg);
    // if (caller.selectedItem) {
    //   if (caller.selectedItem.custNbr != '')
    //     priorquestions.addParameter("AMPM-ACCT", caller.selectedItem.custNbr);
    //   else
    //     priorquestions.addParameter("AMPM-ACCT", this.customerNumber);
    // }
    // else
    //   priorquestions.addParameter("AMPM-ACCT", this.customerNumber);

    // //The follwoing line is only for EMEA region
    // priorquestions.addParameter("AMPM-OWN-COOWN-IND", "1");
    // priorquestions.addParameter("AMPM-DATE", this.priorMailDate);
  }

  priorQuestions_onResult(result: any): void {
    if (result.header.status.error.message === 'Requested data not found null') {
      return;
    }
    // check result message for error codes, communicator will check for
    // and display error message all at the same time.  if error exit.
    // result = DirectoryHelper.trimEmptyRows(result);

    // extract and create dynamic questions / labels for the data in 4th group
    const field: any = result.group[0].field.find(x => x.id === 'AMPM-ADDR-1')[0];
    this.additionalValidationData.push(field);

  }

  formatAnswer(field: any, val: any): String {
    const id: String = field.id;
    switch (id) {
      case 'AMNA-DOB(1)': return FormatterUtil.formatJulianToGregorianDate(val, this.CSState.dateFormat);
      case 'AMNA-DATE-LAST-ADDR-CHANGE': return FormatterUtil.formatJulianToGregorianDate(val, this.CSState.dateFormat);
      case 'AMBS-DATE-OPENED': return FormatterUtil.formatJulianToGregorianDate(val, this.CSState.dateFormat);
      case 'AMBS-CRLIM': return FormatterUtil.formatCurrency(val, FormatterUtil.CURR_SUB_UNITS, this.currencyAttributes);
    }

    if (field.type === 'Date') {
      return FormatterUtil.formatJulianToGregorianDate(val, this.CSState.dateFormat);
    }

    if (field.type === FormatterUtil.CURR_SUB_UNITS ||
      field.type === FormatterUtil.CURR_WHOLE_UNITS ||
      field.type === FormatterUtil.WHOLE_MON_UNIT || field.type === FormatterUtil.PER_ITEM_AMOUNT) {
      return FormatterUtil.formatCurrency(val, field.type, this.currencyAttributes);
    }

    return val;
  }



  additionalVerifyCheck(checked) {
    if (checked) {
      this.hideAdditionalData = true;
      this.splitterSize = '50%';
    } else {
      this.hideAdditionalData = false;
      this.splitterSize = '0%';
    }
    this.cd.detectChanges();
    this.showAdditionalDataEmitter.emit(checked);
  }

  /**
   * This function filter on ARXELO-CARDHOLDER-TYPE parameter if this value contains 0,1,2
   * then add this into list else skip the record.
   */
  applyCardHolderTypeFilter(result: any) {
    for (let i = 0; i < result.group[1].rows.row.length; i++) {
      const row = result.group[1].rows.row[i];
      const cardHolderType = row.field.find(
        x => x.id === 'ARXELO-CARDHOLDER-TYPE'
      ).value;
      if (
        cardHolderType === '0' ||
        cardHolderType === '1' ||
        cardHolderType === '2'
      ) {
        this.callerDetails.push({
          name: row.field.find(x => x.id === 'ARXELO-EMBOSSED-NAME-1').value,
          value: row.field.find(x => x.id === 'ARXELO-EMBOSSED-NAME-1').id
        });
        const cardDetail = {
          name: row.field.find(x => x.id === 'ARXELO-EMBOSSED-NAME-1').value,
          number: row.field.find(x => x.id === 'ARXELO-CARD-NBR').value,
          seq: row.field.find(x => x.id === 'ARXELO-CARD-SEQ').value,
          type: row.field.find(x => x.id === 'ARXELO-CARDHOLDER-TYPE').value,
          custNbr: row.field.find(x => x.id === 'ARXELO-CUST-NBR').value,
          priorMail: this.priorMailDate,
          assocType: row.field.find(x => x.id === 'ARXELO-ASSOC-TYPE').value,
          status: row.field.find(x => x.id === 'ARXELO-CURR-FIRST-USAGE-FLAG')
            .value
        };
        this.cardList.push(cardDetail);
      }
    }
    this.defaultCardName = this.callerDetails[0].value;
    // this.cd.detectChanges();
  }

  onFormSubmit() { }
}
