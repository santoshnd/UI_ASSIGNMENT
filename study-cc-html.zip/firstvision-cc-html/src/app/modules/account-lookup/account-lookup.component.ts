import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { EventServiceService } from '../../shared/services/event-service.service';
import { Subscription } from 'rxjs/rx';
import { DataService } from '../../shared/services/data.service';
import { DataFormatter } from '../../shared/util/data.formatter';
import { LangService } from '../../shared/services/lang-service';

@Component({
  selector: 'app-account-lookup',
  templateUrl: './account-lookup.component.html',
  styleUrls: ['./account-lookup.component.scss']
})
export class AccountLookupComponent implements OnInit {
  locale: any;
  windowFlag: any;
  closeAccountOpened: any;
  updateNumber: any;
  blockCard: any;
  addNotesOpened: any;
  verificationOpened: any;
  eventValue: any;
  transactionDetails: any[];
  dataFormatter = new DataFormatter();
  public listItems: Array<string> = ['Relationship', 'Customer'];
  public clientList: Array<string> = [
    'Please select',
    'SAV credit',
    'silicon vally bank',
    'LTSB CREDIT CARDS',
    'Bank of IreLand'];
  public BuisnessList: Array<string> = ['All'];
  public windowOpened = false;
  showAdditional = false;
  windowWidth = 500;
  constructor(private cookieService: CookieService , private lang: LangService, private eventservice: EventServiceService,
    private dataService: DataService, private cd: ChangeDetectorRef) { }
  cookieValue = 'UNKNOWN';
  subscription: Subscription;
  ngOnInit() {
    this.cookieService.set('Test', 'Hello World');
    this.cookieService.set('iPlanetDirectoryPro', 'AQIC5wM2LY4Sfcx0WGpoud3KrIzyApfiuJQpZPzT6LvhoVc.*AAJTSQACMDE.*');
    this.cookieService.set('JSESSIONID', '3129a1818aee502664376ee2e09a');
    this.cookieService.set('amlbcookie', '01');
    this.cookieValue = this.cookieService.get('Test');
    this.subscribeEventCall();
    this.getAccountLookupDetails();
    this.locale = this.lang.get('accountLookup');
  }
  subscribeEventCall() {
    this.subscription = this.eventservice.eventRecord$.subscribe((data: any) => {
      this.eventValue = data;

      if (this.eventValue.verificationOpened) {
        this.verificationOpened = this.eventValue.verificationOpened;
      } else if (this.eventValue.blockCard) {
        this.blockCard = this.eventValue.blockCard;
      } else if (this.eventValue.updateNumber) {
        this.updateNumber = this.eventValue.updateNumber;
      } else {
        this.addNotesOpened = this.eventValue.addNote;
      }
      if (this.eventValue.closeAccountOpened) {
        this.closeAccountOpened = this.eventValue.closeAccountOpened;
      }
    }
    );
  }
  getAccountLookupDetails() {
    this.dataService.getGridConfig('accountLookUpDetails')
      .subscribe(gridConfig => {
        this.dataService.getAccountLookupDataJSON().subscribe((res: any) => {
          this.transactionDetails = this.dataFormatter.parseGridData(res.vxRoot.group[0].rows.row, gridConfig.columns);
        });
      });
  }
  receiveMessage($event) {
    this.addNotesOpened = $event;
  }
  closeAccount($event) {
    this.closeAccountOpened = $event;
  }
  onButtonClick() {
    this.windowOpened = !this.windowOpened;
  }
  verificationClose1($event) {

    this.verificationOpened = $event;
  }
  blockCardClose($event) {
    this.blockCard = $event;
  }

  onShowAdditionalData(checked) {
    this.windowWidth = checked ? 1000 : 500;
    this.cd.detectChanges();
  }
  windowCloseFlag($event) {
    this.windowFlag = $event;
  }
  onFormSubmit() { }
}
