import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AccountLookupComponent } from './account-lookup.component';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns/dist/es/dropdowns.module';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LayoutModule } from '@progress/kendo-angular-layout/dist/es/layout.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('AccountLookupComponent', () => {
  let component: AccountLookupComponent;
  let fixture: ComponentFixture<AccountLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountLookupComponent ],
      imports : [
        LayoutModule ,
        ButtonsModule ,
        DropDownsModule,
        BrowserAnimationsModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
});
