export let config = {
    loginApi: 'http://shinedev1zb.fdi.1dc.com:2080/opensso/identity/getCookieNameForToken',
    jsonPath: 'assets/json/',
    mockPath: 'assets/json/mock/'
 };
